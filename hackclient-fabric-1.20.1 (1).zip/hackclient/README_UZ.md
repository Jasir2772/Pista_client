# HackClient 2.0 (Fabric 1.20.1)

ClickGUI (5 panel: Combat, Movement, Render, Player, Utils) va 19 modul.
Hali hech qayerda kompilyatsiya qilinmagan. Birinchi build xato bersa, log'ni yuboring.

## .jar ni telefonda yig'ish (kompyutersiz, GitHub Actions)
1. github.com'da hisob oching va yangi repository yarating.
2. "Add file" -> "Upload files": shu zip faylni (hackclient-fabric-1.20.1.zip) O'ZGARTIRMASDAN yuklang, "Commit".
3. "Add file" -> "Create new file": nomiga `.github/workflows/build.yml` yozing,
   ichiga `build.yml` faylining matnini qo'ying, "Commit".
4. "Actions" bo'limida "build" ishlaydi (3-6 daqiqa). Yashil bo'lgach, ichiga kirib
   pastdagi "Artifacts" -> `hackclient-jar` ni yuklab oling, zip ichidan `hackclient-2.0.0.jar` chiqadi.

## O'yinga o'rnatish (PojavLauncher / MojoLauncher)
1. Launcherda Minecraft 1.20.1 uchun Fabric profilini o'rnating.
2. Modrinth'dan "Fabric API" (1.20.1) jar'ini oling.
3. `hackclient-2.0.0.jar` va Fabric API jar'ini profilning `mods` papkasiga qo'ying
   (Pojavda odatda `games/PojavLauncher/.minecraft/mods`, profilingizda boshqa bo'lishi mumkin).
4. Taxminan 2 GB RAM bering, o'yinni oching.

## Boshqarish
- GUI: o'ng Shift (Controls -> HackClient'da o'zgartiriladi) yoki chatga `.gui`.
- Telefonda: Pojav control tahrirlagichida ekranga tugma qo'shib, unga Right Shift ni bog'lang.
- Modulni yoqish: ustiga bosing. "+" sozlamalarni ochadi. Sozlamalar ichida "Bind" tugmasi.
- Chat buyruqlari: `.help`, `.toggle <modul>`, `.bind <modul> <tugma|none>`, `.friend add|remove|list <ism>`.
- Sozlamalar `config/hackclient.json` ga saqlanadi.
