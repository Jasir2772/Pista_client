package dev.hackclient.gui;

import dev.hackclient.Config;
import dev.hackclient.HackClient;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.ModuleManager;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.module.setting.Setting;
import dev.hackclient.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * One panel per category. Tap a module to toggle it, tap "+" to open its settings.
 * Drawn with plain DrawContext calls only (no custom shaders), and hit regions are pooled so a frame allocates nothing.
 */
public final class ClickGuiScreen extends Screen {
    private static final int HEADER_H = 22;
    private static final int ROW_H = 18;
    private static final int SET_H = 16;
    private static final int GAP = 6;

    private static final int HIT_HEADER = 0;
    private static final int HIT_TOGGLE = 1;
    private static final int HIT_EXPAND = 2;
    private static final int HIT_BOOL = 3;
    private static final int HIT_NUMBER = 4;
    private static final int HIT_MODE = 5;
    private static final int HIT_BIND = 6;

    private static final Map<Category, float[]> SAVED_POSITIONS = new EnumMap<>(Category.class);

    private static final class Panel {
        final Category category;
        final List<Module> modules;
        float x;
        float y;
        float scroll;
        float maxScroll;

        Panel(Category category, List<Module> modules) {
            this.category = category;
            this.modules = modules;
        }
    }

    private static final class Hit {
        int x1;
        int y1;
        int x2;
        int y2;
        int type;
        Panel panel;
        Module module;
        Setting setting;
    }

    private final ModuleManager manager;
    private final List<Panel> panels = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private int hitCount;
    private int panelW = 110;

    private Panel dragPanel;
    private float dragOffX;
    private float dragOffY;
    private NumberSetting dragNumber;
    private int dragX1;
    private int dragX2;
    private Module bindTarget;

    public ClickGuiScreen(ModuleManager manager) {
        super(Text.literal("HackClient"));
        this.manager = manager;
        for (Category c : Category.values()) {
            panels.add(new Panel(c, manager.inCategory(c)));
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        int n = panels.size();
        panelW = MathHelper.clamp((width - 12 - GAP * (n - 1)) / n, 92, 124);
        int totalW = panelW * n + GAP * (n - 1);
        int startX = Math.max(4, (width - totalW) / 2);
        for (int i = 0; i < n; i++) {
            Panel p = panels.get(i);
            float[] saved = SAVED_POSITIONS.get(p.category);
            if (saved != null) {
                p.x = saved[0];
                p.y = saved[1];
            } else {
                p.x = startX + i * (panelW + GAP);
                p.y = 26;
            }
        }
    }

    @Override
    public void removed() {
        Config.save(manager);
    }

    private Hit hit(int x1, int y1, int x2, int y2, int type) {
        Hit h;
        if (hitCount < hits.size()) {
            h = hits.get(hitCount);
        } else {
            h = new Hit();
            hits.add(h);
        }
        hitCount++;
        h.x1 = x1;
        h.y1 = y1;
        h.x2 = x2;
        h.y2 = y2;
        h.type = type;
        h.panel = null;
        h.module = null;
        h.setting = null;
        return h;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        hitCount = 0;
        ctx.fill(0, 0, width, height, 0x66000000);
        for (Panel p : panels) {
            renderPanel(ctx, p, mouseX, mouseY);
        }
        ctx.drawCenteredTextWithShadow(textRenderer,
                "Tap: toggle   +: settings   Drag header: move   Chat: .help", width / 2, height - 12, 0x99FFFFFF);
    }

    private void renderPanel(DrawContext ctx, Panel p, int mx, int my) {
        int x1 = Math.round(p.x);
        int y1 = Math.round(p.y);
        int x2 = x1 + panelW;

        int contentH = 0;
        for (Module m : p.modules) {
            contentH += ROW_H;
            if (m.isExpanded()) {
                contentH += (m.settings().size() + 1) * SET_H;
            }
        }
        int viewH = Math.min(contentH, Math.max(ROW_H, height - 8 - (y1 + HEADER_H)));
        p.maxScroll = Math.max(0, contentH - viewH);
        p.scroll = MathHelper.clamp(p.scroll, 0.0f, p.maxScroll);

        int bodyTop = y1 + HEADER_H;
        int bodyBottom = bodyTop + viewH;

        ctx.fill(x1, y1, x2, bodyTop, Theme.PANEL_HEADER);
        ctx.fill(x1, bodyTop - 1, x2, bodyTop, (Theme.ACCENT & 0x00FFFFFF) | 0x80000000);
        ctx.drawCenteredTextWithShadow(textRenderer, p.category.label, (x1 + x2) / 2, y1 + 7, 0xFFFFFFFF);
        hit(x1, y1, x2, bodyTop, HIT_HEADER).panel = p;

        ctx.fillGradient(x1, bodyTop, x2, bodyBottom + 4, Theme.PANEL_TOP, Theme.PANEL_BOTTOM);
        ctx.enableScissor(x1, bodyTop, x2, bodyBottom);

        int y = bodyTop - Math.round(p.scroll);
        for (Module m : p.modules) {
            int rowBottom = y + ROW_H;
            if (rowBottom > bodyTop && y < bodyBottom) {
                int vy1 = Math.max(y, bodyTop);
                int vy2 = Math.min(rowBottom, bodyBottom);
                boolean hover = mx >= x1 && mx < x2 && my >= vy1 && my < vy2;
                if (m.isEnabled()) {
                    ctx.fill(x1 + 2, y + 1, x2 - 2, rowBottom - 1, 0x407AA2FF);
                } else if (hover) {
                    ctx.fill(x1 + 2, y + 1, x2 - 2, rowBottom - 1, 0x22FFFFFF);
                }
                ctx.drawText(textRenderer, m.getName(), x1 + 8, y + 5, m.isEnabled() ? Theme.ACCENT : Theme.TEXT, false);
                ctx.drawText(textRenderer, m.isExpanded() ? "-" : "+", x2 - 11, y + 5, Theme.TEXT_DIM, false);
                hit(x1, vy1, x2 - 18, vy2, HIT_TOGGLE).module = m;
                hit(x2 - 18, vy1, x2, vy2, HIT_EXPAND).module = m;
            }
            y += ROW_H;
            if (m.isExpanded()) {
                for (Setting s : m.settings()) {
                    renderSetting(ctx, m, s, x1, x2, y, bodyTop, bodyBottom, mx, my);
                    y += SET_H;
                }
                renderBind(ctx, m, x1, x2, y, bodyTop, bodyBottom, mx, my);
                y += SET_H;
            }
        }
        ctx.disableScissor();
    }

    private void renderSetting(DrawContext ctx, Module m, Setting s, int x1, int x2, int top,
                               int visTop, int visBottom, int mx, int my) {
        int bottom = top + SET_H;
        if (bottom <= visTop || top >= visBottom) {
            return;
        }
        int rx1 = x1 + 4;
        int rx2 = x2 - 4;
        int vy1 = Math.max(top, visTop);
        int vy2 = Math.min(bottom, visBottom);
        boolean hover = mx >= rx1 && mx < rx2 && my >= vy1 && my < vy2;
        int ty = top + 4;
        int type;
        if (s instanceof BoolSetting b) {
            type = HIT_BOOL;
            if (hover) {
                ctx.fill(rx1, top, rx2, bottom - 1, 0x18FFFFFF);
            }
            ctx.drawText(textRenderer, b.name, rx1 + 3, ty, Theme.TEXT, false);
            drawPill(ctx, rx2 - 22, top + 4, b.get());
        } else if (s instanceof NumberSetting n) {
            type = HIT_NUMBER;
            ctx.fill(rx1, top, rx2, bottom - 1, 0x22000000);
            ctx.fill(rx1, top, rx1 + (int) ((rx2 - rx1) * n.fraction()), bottom - 1, 0x557AA2FF);
            ctx.drawText(textRenderer, n.name, rx1 + 3, ty, Theme.TEXT, false);
            String v = n.display();
            ctx.drawText(textRenderer, v, rx2 - 3 - textRenderer.getWidth(v), ty, Theme.TEXT_DIM, false);
        } else if (s instanceof ModeSetting ms) {
            type = HIT_MODE;
            if (hover) {
                ctx.fill(rx1, top, rx2, bottom - 1, 0x18FFFFFF);
            }
            ctx.drawText(textRenderer, ms.name, rx1 + 3, ty, Theme.TEXT, false);
            String v = ms.get();
            ctx.drawText(textRenderer, v, rx2 - 3 - textRenderer.getWidth(v), ty, Theme.ACCENT, false);
        } else {
            return;
        }
        Hit h = hit(rx1, vy1, rx2, vy2, type);
        h.module = m;
        h.setting = s;
    }

    private void renderBind(DrawContext ctx, Module m, int x1, int x2, int top, int visTop, int visBottom, int mx, int my) {
        int bottom = top + SET_H;
        if (bottom <= visTop || top >= visBottom) {
            return;
        }
        int rx1 = x1 + 4;
        int rx2 = x2 - 4;
        int vy1 = Math.max(top, visTop);
        int vy2 = Math.min(bottom, visBottom);
        if (mx >= rx1 && mx < rx2 && my >= vy1 && my < vy2) {
            ctx.fill(rx1, top, rx2, bottom - 1, 0x18FFFFFF);
        }
        String label;
        if (bindTarget == m) {
            label = "Press a key...";
        } else if (m.getKey() < 0) {
            label = "Bind: None";
        } else {
            label = "Bind: " + InputUtil.fromKeyCode(m.getKey(), -1).getLocalizedText().getString();
        }
        ctx.drawText(textRenderer, label, rx1 + 3, top + 4, bindTarget == m ? Theme.ACCENT : Theme.TEXT_DIM, false);
        hit(rx1, vy1, rx2, vy2, HIT_BIND).module = m;
    }

    private static void drawPill(DrawContext ctx, int x, int y, boolean on) {
        ctx.fill(x, y, x + 18, y + 8, on ? Theme.ACCENT : 0xFF3A4150);
        int knobX = on ? x + 10 : x + 1;
        ctx.fill(knobX, y + 1, knobX + 7, y + 7, 0xFFFFFFFF);
    }

    private void updateSlider(double mouseX) {
        if (dragNumber != null && dragX2 > dragX1) {
            dragNumber.setFromFraction((mouseX - dragX1) / (double) (dragX2 - dragX1));
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = 0; i < hitCount; i++) {
            Hit h = hits.get(i);
            if (mx < h.x1 || mx >= h.x2 || my < h.y1 || my >= h.y2) {
                continue;
            }
            switch (h.type) {
                case HIT_HEADER -> {
                    dragPanel = h.panel;
                    dragOffX = (float) (mx - h.panel.x);
                    dragOffY = (float) (my - h.panel.y);
                }
                case HIT_TOGGLE -> {
                    if (button == 1) {
                        h.module.setExpanded(!h.module.isExpanded());
                    } else {
                        h.module.toggle();
                    }
                }
                case HIT_EXPAND -> h.module.setExpanded(!h.module.isExpanded());
                case HIT_BOOL -> ((BoolSetting) h.setting).toggle();
                case HIT_MODE -> {
                    ModeSetting ms = (ModeSetting) h.setting;
                    if (button == 1) {
                        ms.prev();
                    } else {
                        ms.next();
                    }
                }
                case HIT_NUMBER -> {
                    dragNumber = (NumberSetting) h.setting;
                    dragX1 = h.x1;
                    dragX2 = h.x2;
                    updateSlider(mx);
                }
                case HIT_BIND -> bindTarget = bindTarget == h.module ? null : h.module;
                default -> {
                }
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragPanel != null) {
            dragPanel.x = MathHelper.clamp((float) (mx - dragOffX), 0.0f, Math.max(0, width - panelW));
            dragPanel.y = MathHelper.clamp((float) (my - dragOffY), 0.0f, Math.max(0, height - HEADER_H));
            return true;
        }
        if (dragNumber != null) {
            updateSlider(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragPanel != null) {
            SAVED_POSITIONS.put(dragPanel.category, new float[]{dragPanel.x, dragPanel.y});
        }
        dragPanel = null;
        dragNumber = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        for (Panel p : panels) {
            if (mx >= p.x && mx < p.x + panelW && my >= p.y && p.maxScroll > 0) {
                p.scroll = MathHelper.clamp(p.scroll - (float) amount * 14.0f, 0.0f, p.maxScroll);
                return true;
            }
        }
        return super.mouseScrolled(mx, my, amount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindTarget != null) {
            boolean clear = keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_BACKSPACE
                    || keyCode == GLFW.GLFW_KEY_DELETE;
            bindTarget.setKey(clear ? -1 : keyCode);
            bindTarget = null;
            return true;
        }
        if (HackClient.guiKey().matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
