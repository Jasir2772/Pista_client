package dev.hackclient.util;

public final class Theme {
    public static final int ACCENT = 0xFF7AA2FF;
    public static final int TEXT = 0xFFC9CFDA;
    public static final int TEXT_DIM = 0xFF8790A0;
    public static final int PANEL_HEADER = 0xF0262C3A;
    public static final int PANEL_TOP = 0xE02E3646;
    public static final int PANEL_BOTTOM = 0xD01C221E;
    public static final int HUD_BG = 0x99101418;

    private Theme() {
    }
}
