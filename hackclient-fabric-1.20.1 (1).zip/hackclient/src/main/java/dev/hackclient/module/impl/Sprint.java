package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public final class Sprint extends Module {
    private static final int MIN_FOOD_TO_SPRINT = 7;

    public Sprint() {
        super("Sprint", Category.MOVEMENT, "Sprints while you move forward");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        boolean forward = player.input.movementForward > 0.0f;
        boolean allowed = !player.isSneaking()
                && !player.isUsingItem()
                && !player.horizontalCollision
                && player.getHungerManager().getFoodLevel() >= MIN_FOOD_TO_SPRINT;
        if (forward && allowed) {
            player.setSprinting(true);
        }
    }
}
