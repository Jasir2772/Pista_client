package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Attacks with vanilla-style behaviour: reach measured to the hitbox, attack cooldown respected,
 * rotation turned gradually in mouse-sized steps, attack only while the crosshair is on the target.
 * Nothing here is tuned against a particular server's anti-cheat.
 */
public final class KillAura extends Module {
    private final NumberSetting range = number("Range", 3.0, 2.0, 6.0, 0.1);
    private final NumberSetting fov = number("FOV", 180, 30, 360, 5);
    private final ModeSetting sort = mode("Sort", "Distance", "Distance", "Health", "Angle");
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting hostiles = bool("Hostiles", true);
    private final BoolSetting passives = bool("Passives", false);
    private final BoolSetting invisible = bool("Invisible", false);
    private final BoolSetting wallCheck = bool("WallCheck", true);
    private final BoolSetting rayCheck = bool("RayCheck", true);
    private final BoolSetting onlyWeapon = bool("OnlyWeapon", true);
    private final BoolSetting noUseItem = bool("NoUseItem", true);
    private final NumberSetting turnSpeed = number("TurnSpeed", 30, 5, 180, 1);
    private final BoolSetting mouseGcd = bool("MouseGCD", true);
    private final NumberSetting minCooldown = number("MinCooldown", 0.92, 0.5, 1.0, 0.01);

    private LivingEntity target;
    private float requiredCooldown = 1.0f;

    public KillAura() {
        super("KillAura", Category.COMBAT, "Attacks nearby entities");
    }

    @Override
    protected void onDisable() {
        target = null;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (player == null || world == null || mc.interactionManager == null
                || mc.currentScreen != null || !player.isAlive()) {
            target = null;
            return;
        }
        if (onlyWeapon.get() && !Targets.isHoldingWeapon(player)) {
            target = null;
            return;
        }

        Vec3d eye = player.getEyePos();
        if (target == null || !isValid(player, target, eye)) {
            target = findTarget(player, world, eye);
        }
        if (target == null) {
            return;
        }

        Box box = target.getBoundingBox();
        rotateToward(mc, player, eye, Targets.aimPoint(eye, box));

        if (noUseItem.get() && player.isUsingItem()) {
            return;
        }
        if (player.getAttackCooldownProgress(0.5f) < requiredCooldown) {
            return;
        }
        if (rayCheck.get() && !lookingAt(player, eye, box)) {
            return;
        }

        mc.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        float min = minCooldown.getFloat();
        requiredCooldown = min + ThreadLocalRandom.current().nextFloat() * (1.0f - min);
    }

    private boolean isValid(ClientPlayerEntity player, Entity e, Vec3d eye) {
        if (!Targets.isAttackable(e, players.get(), hostiles.get(), passives.get(), invisible.get())) {
            return false;
        }
        Box box = e.getBoundingBox();
        if (Targets.distanceToBox(eye, box) > range.get()) {
            return false;
        }
        if (fov.get() < 360.0) {
            float yawDiff = Math.abs(MathHelper.wrapDegrees(Targets.yawTo(eye, Targets.aimPoint(eye, box)) - player.getYaw()));
            if (yawDiff > fov.get() / 2.0) {
                return false;
            }
        }
        return !wallCheck.get() || player.canSee(e);
    }

    private LivingEntity findTarget(ClientPlayerEntity player, ClientWorld world, Vec3d eye) {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : world.getEntities()) {
            if (!(e instanceof LivingEntity living) || !isValid(player, e, eye)) {
                continue;
            }
            double score;
            if (sort.is("Health")) {
                score = living.getHealth();
            } else if (sort.is("Angle")) {
                score = Math.abs(MathHelper.wrapDegrees(Targets.yawTo(eye, Targets.aimPoint(eye, e.getBoundingBox())) - player.getYaw()));
            } else {
                score = Targets.distanceToBox(eye, e.getBoundingBox());
            }
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }

    private boolean lookingAt(ClientPlayerEntity player, Vec3d eye, Box box) {
        if (box.contains(eye)) {
            return true;
        }
        Vec3d end = eye.add(player.getRotationVec(1.0f).multiply(range.get() + 0.5));
        return box.raycast(eye, end).isPresent();
    }

    private void rotateToward(MinecraftClient mc, ClientPlayerEntity player, Vec3d eye, Vec3d aim) {
        float yawErr = MathHelper.wrapDegrees(Targets.yawTo(eye, aim) - player.getYaw());
        float pitchErr = Targets.pitchTo(eye, aim) - player.getPitch();
        float err = (float) Math.hypot(yawErr, pitchErr);
        if (err < 0.01f) {
            return;
        }
        float maxStep = turnSpeed.getFloat() * (0.8f + ThreadLocalRandom.current().nextFloat() * 0.4f);
        float scale = err > maxStep ? maxStep / err : 1.0f;
        float dYaw = yawErr * scale;
        float dPitch = pitchErr * scale;
        if (mouseGcd.get()) {
            float step = mouseStep(mc);
            dYaw = Math.round(dYaw / step) * step;
            dPitch = Math.round(dPitch / step) * step;
        }
        if (dYaw == 0.0f && dPitch == 0.0f) {
            return;
        }
        float oldPitch = player.getPitch();
        float newPitch = MathHelper.clamp(oldPitch + dPitch, -90.0f, 90.0f);
        player.setYaw(player.getYaw() + dYaw);
        player.setPitch(newPitch);
        player.prevYaw += dYaw;
        player.prevPitch += newPitch - oldPitch;
    }

    /** Smallest rotation a real mouse can produce at the current sensitivity (vanilla: (s*0.6+0.2)^3 * 8 * 0.15). */
    private static float mouseStep(MinecraftClient mc) {
        double f = mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }
}
