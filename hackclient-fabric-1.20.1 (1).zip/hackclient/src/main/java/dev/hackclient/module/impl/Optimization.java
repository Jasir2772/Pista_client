package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/**
 * Lowers vanilla video options while enabled and restores the previous values on disable.
 * It only touches options the game already has; it cannot replace a rendering optimisation mod.
 */
public final class Optimization extends Module {
    private final NumberSetting renderDistance = number("RenderDistance", 6, 2, 12, 1);
    private final NumberSetting simulationDistance = number("SimDistance", 5, 5, 12, 1);
    private final BoolSetting minimalParticles = bool("MinimalParticles", true);
    private final BoolSetting fastGraphics = bool("FastGraphics", true);
    private final BoolSetting noClouds = bool("NoClouds", true);
    private final BoolSetting noEntityShadows = bool("NoEntityShadows", true);
    private final BoolSetting noBiomeBlend = bool("NoBiomeBlend", true);

    private boolean saved;
    private int oldView;
    private int oldSim;
    private int oldBlend;
    private ParticlesMode oldParticles;
    private GraphicsMode oldGraphics;
    private CloudRenderMode oldClouds;
    private boolean oldShadows;

    public Optimization() {
        super("Optimization", Category.UTILS, "Lower video options for more FPS");
    }

    @Override
    protected void onEnable() {
        GameOptions o = MinecraftClient.getInstance().options;
        if (o == null) {
            return;
        }
        oldView = o.getViewDistance().getValue();
        oldSim = o.getSimulationDistance().getValue();
        oldBlend = o.getBiomeBlendRadius().getValue();
        oldParticles = o.getParticles().getValue();
        oldGraphics = o.getGraphicsMode().getValue();
        oldClouds = o.getCloudRenderMode().getValue();
        oldShadows = o.getEntityShadows().getValue();
        saved = true;
        apply(o);
    }

    @Override
    protected void onDisable() {
        GameOptions o = MinecraftClient.getInstance().options;
        if (!saved || o == null) {
            return;
        }
        o.getViewDistance().setValue(oldView);
        o.getSimulationDistance().setValue(oldSim);
        o.getBiomeBlendRadius().setValue(oldBlend);
        o.getParticles().setValue(oldParticles);
        o.getGraphicsMode().setValue(oldGraphics);
        o.getCloudRenderMode().setValue(oldClouds);
        o.getEntityShadows().setValue(oldShadows);
        saved = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (saved && mc.options != null && mc.player != null && mc.player.age % 20 == 0) {
            apply(mc.options);
        }
    }

    private void apply(GameOptions o) {
        if (o.getViewDistance().getValue() != renderDistance.getInt()) {
            o.getViewDistance().setValue(renderDistance.getInt());
        }
        if (o.getSimulationDistance().getValue() != simulationDistance.getInt()) {
            o.getSimulationDistance().setValue(simulationDistance.getInt());
        }
        if (minimalParticles.get()) {
            o.getParticles().setValue(ParticlesMode.MINIMAL);
        }
        if (fastGraphics.get()) {
            o.getGraphicsMode().setValue(GraphicsMode.FAST);
        }
        if (noClouds.get()) {
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        }
        if (noEntityShadows.get()) {
            o.getEntityShadows().setValue(false);
        }
        if (noBiomeBlend.get()) {
            o.getBiomeBlendRadius().setValue(0);
        }
    }
}
