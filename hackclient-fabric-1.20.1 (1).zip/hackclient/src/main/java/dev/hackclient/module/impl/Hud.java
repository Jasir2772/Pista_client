package dev.hackclient.module.impl;

import dev.hackclient.HackClient;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Hud extends Module {
    private final BoolSetting watermark = bool("Watermark", true);
    private final BoolSetting coords = bool("Coords", true);
    private final BoolSetting moduleList = bool("ModuleList", true);

    public Hud() {
        super("HUD", Category.RENDER, "Watermark, coordinates and module list");
    }

    @Override
    public boolean showInList() {
        return false;
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.options.debugEnabled) {
            return;
        }
        TextRenderer tr = mc.textRenderer;
        int y = 3;
        if (watermark.get()) {
            String s = "HackClient | " + mc.getCurrentFps() + " FPS";
            ctx.fill(2, y - 1, tr.getWidth(s) + 10, y + 10, Theme.HUD_BG);
            ctx.fill(2, y - 1, 4, y + 10, Theme.ACCENT);
            ctx.drawTextWithShadow(tr, s, 7, y + 1, 0xFFFFFFFF);
            y += 14;
        }
        if (coords.get()) {
            String s = "XYZ " + (int) Math.floor(mc.player.getX()) + " "
                    + (int) Math.floor(mc.player.getY()) + " " + (int) Math.floor(mc.player.getZ());
            ctx.fill(2, y - 1, tr.getWidth(s) + 10, y + 10, Theme.HUD_BG);
            ctx.drawTextWithShadow(tr, s, 6, y + 1, 0xFFC9CFDA);
        }
        if (moduleList.get()) {
            int right = mc.getWindow().getScaledWidth() - 2;
            int ly = 3;
            for (Module m : HackClient.modules().listedByWidth(tr)) {
                int w = tr.getWidth(m.getName());
                ctx.fill(right - w - 6, ly - 1, right, ly + 10, Theme.HUD_BG);
                ctx.fill(right - 2, ly - 1, right, ly + 10, Theme.ACCENT);
                ctx.drawTextWithShadow(tr, m.getName(), right - w - 4, ly + 1, Theme.ACCENT);
                ly += 11;
            }
        }
    }
}
