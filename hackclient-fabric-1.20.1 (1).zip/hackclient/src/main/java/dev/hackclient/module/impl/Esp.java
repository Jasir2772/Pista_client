package dev.hackclient.module.impl;

import dev.hackclient.FriendManager;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** 2D box ESP drawn from projected hitbox corners. Alignment with the real entities has to be confirmed in game. */
public final class Esp extends Module {
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting hostiles = bool("Hostiles", false);
    private final BoolSetting passives = bool("Passives", false);
    private final BoolSetting items = bool("Items", false);
    private final BoolSetting boxes = bool("Boxes", true);
    private final BoolSetting health = bool("Health", true);
    private final BoolSetting names = bool("Names", true);
    private final BoolSetting distance = bool("Distance", false);
    private final NumberSetting range = number("Range", 64, 16, 128, 4);
    private final float[] rect = new float[4];

    public Esp() {
        super("ESP", Category.RENDER, "Boxes, health and names through walls");
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity self = mc.player;
        ClientWorld world = mc.world;
        if (self == null || world == null || !RenderUtil.isReady()) {
            return;
        }
        double maxSq = range.get() * range.get();
        float td = RenderUtil.tickDelta();
        for (Entity e : world.getEntities()) {
            if (e == self || e.squaredDistanceTo(self) > maxSq) {
                continue;
            }
            int color = colorFor(e);
            if (color == 0) {
                continue;
            }
            Vec3d lerped = e.getLerpedPos(td);
            double ox = lerped.x - e.getX();
            double oy = lerped.y - e.getY();
            double oz = lerped.z - e.getZ();
            Box b = e.getBoundingBox();
            if (!RenderUtil.projectBox(b.minX + ox, b.minY + oy, b.minZ + oz, b.maxX + ox, b.maxY + oy, b.maxZ + oz, rect)) {
                continue;
            }
            float x1 = rect[0];
            float y1 = rect[1];
            float x2 = rect[2];
            float y2 = rect[3];
            if (x2 - x1 > 3000.0f || y2 - y1 > 3000.0f) {
                continue;
            }
            if (boxes.get()) {
                RenderUtil.outline(ctx, x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xAA000000);
                RenderUtil.outline(ctx, x1, y1, x2, y2, color);
            }
            if (health.get() && e instanceof LivingEntity living) {
                float frac = MathHelper.clamp(living.getHealth() / Math.max(1.0f, living.getMaxHealth()), 0.0f, 1.0f);
                float top = y2 - (y2 - y1) * frac;
                RenderUtil.fillHalf(ctx, x1 - 4, y1 - 1, x1 - 2, y2 + 1, 0xAA000000);
                RenderUtil.fillHalf(ctx, x1 - 3.5f, top, x1 - 2.5f, y2, healthColor(frac));
            }
            float cx = (x1 + x2) * 0.5f;
            if (names.get()) {
                RenderUtil.text(ctx, e.getName().getString(), cx, y1 - 8, 0xFFFFFFFF, 0.7f);
            }
            if (distance.get()) {
                RenderUtil.text(ctx, ((int) Math.sqrt(e.squaredDistanceTo(self))) + "m", cx, y2 + 2, 0xFFC9CFDA, 0.7f);
            }
        }
    }

    private int colorFor(Entity e) {
        if (e instanceof ItemEntity) {
            return items.get() ? 0xFFFFFF55 : 0;
        }
        if (!(e instanceof LivingEntity living) || !living.isAlive() || e instanceof ArmorStandEntity) {
            return 0;
        }
        if (e instanceof PlayerEntity player) {
            if (!players.get()) {
                return 0;
            }
            return FriendManager.isFriend(player.getEntityName()) ? 0xFF55FF55 : 0xFFFF5555;
        }
        if (e instanceof Monster) {
            return hostiles.get() ? 0xFFFFAA00 : 0;
        }
        return passives.get() ? 0xFF55FFFF : 0;
    }

    private static int healthColor(float frac) {
        int r = (int) (255 * (1.0f - frac));
        int g = (int) (255 * frac);
        return 0xFF000000 | (r << 16) | (g << 8) | 0x30;
    }
}
