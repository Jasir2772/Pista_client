package dev.hackclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class ModeSetting extends Setting {
    private final String[] modes;
    private int index;

    public ModeSetting(String name, String defaultMode, String... modes) {
        super(name);
        this.modes = modes;
        this.index = Math.max(0, indexOf(defaultMode));
    }

    private int indexOf(String mode) {
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(mode)) {
                return i;
            }
        }
        return -1;
    }

    public String get() {
        return modes[index];
    }

    public boolean is(String mode) {
        return modes[index].equalsIgnoreCase(mode);
    }

    public void next() {
        index = (index + 1) % modes.length;
    }

    public void prev() {
        index = (index - 1 + modes.length) % modes.length;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(get());
    }

    @Override
    public void load(JsonElement element) {
        if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
            int i = indexOf(element.getAsString());
            if (i >= 0) {
                index = i;
            }
        }
    }
}
