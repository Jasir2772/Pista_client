# Pista Client 2.4 (Fabric 1.20.1)

44 modul, ikki til, ClickGUI. Bu versiyani ham o'zim kompilyatsiya qilib ko'rmaganman: avval GitHub'da build qiling.

## Bu safargi o'zgarishlar
- **16 ta yangi modul** (hammasi shu jar ichida, alohida `pista-addons` jari endi KERAK EMAS, uni o'chiring):
  - Combat: Velocity, Criticals, AutoArmor
  - Movement: NoSlow, NoWeb, Blink, HighJump, Flight
  - Render: Trails, Predictions (pearl/potion/XP/o'q yo'li), Removals (hurt tilt, olov/suv overlay), ThirdPerson
  - Player: NoPush, DeathCoords, ClickPearl (tugmaga bog'lang)
  - Utils: ClientSounds (modul yoqilganda/o'chganda bosish ovozi)
- **Optimization qayta yozildi:** Balanced / Aggressive / Extreme presetlari; uzoq mob, o'yinchi va particle'larni
  chizmaslik; yomg'ir/qorni o'chirish; EntityScale; Adaptive (FPS maqsadga yetmasa render distance'ni o'zi
  tushiradi, FPS yaxshi bo'lsa qaytaradi); ShowStats (FPS va nechta mob/particle o'tkazib yuborilgani).
  O'yin yopilganda sozlamalar asl holiga qaytariladi. Sodium kabi render dvigatelini almashtirmaydi.
- **KillAura / TriggerBot "insoniy" sozlamalar** (KillAura'da Advanced ichida): Smoothing (Ease/Linear), AimPoint
  (Closest/Random), ReactionTicks, Wobble, Hesitation. Legit/Normal/Rage presetlari shularni ham to'ldiradi.
- Preset endi har ishga tushganda config'dagi qiymatlaringizni bosib yubormaydi.
- Xavfsizlik: yangi mixin'lar alohida `hackclient.extras.mixins.json` da va `required: false`. Biror target
  1.20.1 da boshqacha chiqsa, o'sha modul ishlamaydi, lekin o'yin yiqilmaydi. `logs/latest.log` da `hackclient` ni qidiring.

## Bypass haqida ochiq gap
Yuqoridagi "insoniy" sozlamalar faqat kirish qanday ko'rinishini o'zgartiradi (silliq burilish, tasodifiy nishon
nuqtasi, reaksiya kechikishi, kichik og'ish, ikkilanish). Ular hech bir anticheat'ga qarshi sinalmagan va
hech qaysi tizimga moslab yozilmagan. Aniq anticheat'ni yengish uchun maxsus rejimlar qo'shmaganman.
Velocity, Criticals, NoSlow, Blink, Flight kabi modullarni ko'p serverlar to'g'ridan-to'g'ri taniydi.

## Kompilyatsiya xavfi bo'lgan joylar (xotiradan yozilgan 1.20.1 Yarn nomlari)
`EntityVelocityUpdateS2CPacket.getVelocityX()` (int), `Entity.slowMovement`, `Entity.pushAwayFrom`,
`ClientPlayerEntity.pushOutOfBlocks`, `ClientConnection.send(Packet, PacketCallbacks)`, `Camera.clipToSpace`,
`GameRenderer.tiltViewWhenHurt`, `InGameOverlayRenderer.renderFireOverlay/renderUnderwaterOverlay`,
`EntityRenderDispatcher.shouldRender`, `WorldRenderer.renderWeather`, `ParticleManager.addParticle`,
`GameOptions.getEntityDistanceScaling`, `ArmorItem.getSlotType`, `EnchantmentHelper.hasBindingCurse`,
`BowItem.getPullProgress`, `LivingEntity.getItemUseTime`.
Build xato bersa, xato matnini yuboring, tuzataman.

## Yangilash (GitHub'da)
Eski zip ustiga shu nomdagi yangisini yuklang, commit qiling. Yangi jar: `hackclient-2.4.0.jar`.
Mods papkasida eski `hackclient-2.3.0.jar` va `pista-addons-*.jar` bo'lmasin.

## Boshqarish
- GUI: o'ng Shift yoki chatga `.gui`. Til: Utils -> Language, yoki `.lang uz` / `.lang en`.
- Chat: `.help`, `.lang en|uz`, `.toggle <modul>`, `.bind <modul> <tugma|none>`, `.friend add|remove|list <ism>`.
