package dev.hackclient.mixin;

import dev.hackclient.module.impl.Removals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void hackclient$noFire(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        if (Removals.fire()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void hackclient$noWater(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        if (Removals.water()) {
            ci.cancel();
        }
    }
}
