package dev.hackclient.mixin;

import dev.hackclient.module.impl.NoPush;
import dev.hackclient.module.impl.NoWeb;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "slowMovement", at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$noWeb(BlockState state, Vec3d multiplier, CallbackInfo ci) {
        if ((Object) this == MinecraftClient.getInstance().player && NoWeb.ignores(state)) {
            ci.cancel();
        }
    }

    @Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$noPushEntities(Entity other, CallbackInfo ci) {
        if (NoPush.entities() && (Object) this == MinecraftClient.getInstance().player) {
            ci.cancel();
        }
    }
}
