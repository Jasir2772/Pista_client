package dev.hackclient.mixin;

import dev.hackclient.module.impl.Optimization;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    /** x, y, z are the camera position. */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$cull(Entity entity, Frustum frustum, double x, double y, double z,
                                 CallbackInfoReturnable<Boolean> cir) {
        if (Optimization.cullEntity(entity, x, y, z)) {
            cir.setReturnValue(false);
        }
    }
}
