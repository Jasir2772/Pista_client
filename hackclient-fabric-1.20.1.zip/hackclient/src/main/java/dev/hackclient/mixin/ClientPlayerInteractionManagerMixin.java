package dev.hackclient.mixin;

import dev.hackclient.module.impl.Criticals;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Inject(method = "attackEntity", at = @At("HEAD"), require = 0)
    private void hackclient$criticals(PlayerEntity player, Entity target, CallbackInfo ci) {
        if (Criticals.active()) {
            Criticals.beforeAttack(player, target);
        }
    }
}
