package dev.hackclient.mixin;

import dev.hackclient.module.impl.Blink;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientConnection.class)
public abstract class ClientConnectionMixin {
    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$blink(Packet<?> packet, PacketCallbacks callbacks, CallbackInfo ci) {
        if (Blink.active() && Blink.capture(packet)) {
            ci.cancel();
        }
    }
}
