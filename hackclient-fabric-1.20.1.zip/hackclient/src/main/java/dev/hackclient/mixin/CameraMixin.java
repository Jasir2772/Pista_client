package dev.hackclient.mixin;

import dev.hackclient.module.impl.ThirdPerson;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public abstract class CameraMixin {
    /** Without NoClip: keep vanilla wall clipping but start from our distance. */
    @ModifyVariable(method = "clipToSpace", at = @At("HEAD"), argsOnly = true, require = 0)
    private double hackclient$distance(double desired) {
        return ThirdPerson.active() ? ThirdPerson.distance() : desired;
    }

    /** With NoClip: the camera passes through walls and always sits at the full distance. */
    @Inject(method = "clipToSpace", at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$noClip(double desired, CallbackInfoReturnable<Double> cir) {
        if (ThirdPerson.active() && ThirdPerson.noClip()) {
            cir.setReturnValue(ThirdPerson.distance());
        }
    }
}
