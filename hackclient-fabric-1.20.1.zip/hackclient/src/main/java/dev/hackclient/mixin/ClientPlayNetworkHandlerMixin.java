package dev.hackclient.mixin;

import dev.hackclient.module.impl.Velocity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$velocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        if (!Velocity.active()) {
            return;
        }
        // The handler runs once on the network thread (re-queued by forceMainThread) and once on the main thread.
        if (!MinecraftClient.getInstance().isOnThread()) {
            return;
        }
        if (Velocity.consume(packet)) {
            ci.cancel();
        }
    }
}
