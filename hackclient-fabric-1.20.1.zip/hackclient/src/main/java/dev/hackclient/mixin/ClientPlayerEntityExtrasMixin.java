package dev.hackclient.mixin;

import dev.hackclient.module.impl.NoPush;
import dev.hackclient.module.impl.NoSlow;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityExtrasMixin {
    /** NoSlow: tickMovement checks isUsingItem() to scale the input; report "not using" while the module is on. */
    @Redirect(method = "tickMovement",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"),
            require = 0)
    private boolean hackclient$noSlow(ClientPlayerEntity self) {
        return !NoSlow.items() && self.isUsingItem();
    }

    /** NoPush (blocks): skip the nudge out of blocks. */
    @Inject(method = "pushOutOfBlocks", at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$noPushBlocks(double x, double z, CallbackInfo ci) {
        if (NoPush.blocks()) {
            ci.cancel();
        }
    }
}
