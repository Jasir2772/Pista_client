package dev.hackclient.mixin;

import dev.hackclient.module.impl.Optimization;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin {
    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$cullParticle(ParticleEffect parameters, double x, double y, double z,
                                         double velocityX, double velocityY, double velocityZ,
                                         CallbackInfoReturnable<Particle> cir) {
        if (Optimization.cullParticle(x, y, z)) {
            cir.setReturnValue(null);
        }
    }
}
