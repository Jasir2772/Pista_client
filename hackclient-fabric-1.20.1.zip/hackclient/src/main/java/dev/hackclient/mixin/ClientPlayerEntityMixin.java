package dev.hackclient.mixin;

import dev.hackclient.util.SilentRotation;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Silent rotation: while SilentRotation is active, the movement packets of this tick carry the silent yaw/pitch,
 * then the real camera rotation is put back, so the player can keep looking around freely.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Unique
    private float hackclient$realYaw;
    @Unique
    private float hackclient$realPitch;
    @Unique
    private boolean hackclient$swapped;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void hackclient$applySilentRotation(CallbackInfo ci) {
        if (!SilentRotation.isActive()) {
            return;
        }
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        hackclient$realYaw = self.getYaw();
        hackclient$realPitch = self.getPitch();
        self.setYaw(SilentRotation.yaw());
        self.setPitch(SilentRotation.pitch());
        hackclient$swapped = true;
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void hackclient$restoreRotation(CallbackInfo ci) {
        if (!hackclient$swapped) {
            return;
        }
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        self.setYaw(hackclient$realYaw);
        self.setPitch(hackclient$realPitch);
        hackclient$swapped = false;
    }
}
