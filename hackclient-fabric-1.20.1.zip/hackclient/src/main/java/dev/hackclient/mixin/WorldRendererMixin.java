package dev.hackclient.mixin;

import dev.hackclient.module.impl.Optimization;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$noWeather(LightmapTextureManager manager, float tickDelta,
                                      double cameraX, double cameraY, double cameraZ, CallbackInfo ci) {
        if (Optimization.noWeather()) {
            ci.cancel();
        }
    }
}
