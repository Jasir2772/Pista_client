package dev.hackclient.mixin;

import dev.hackclient.module.impl.Optimization;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$noWeather(LightmapTextureManager manager, float tickDelta,
                                      double cameraX, double cameraY, double cameraZ, CallbackInfo ci) {
        if (Optimization.noWeather()) {
            ci.cancel();
        }
    }

    /**
     * Far particles are dropped here. This method returns void, so nothing downstream can end up holding a null
     * particle (ParticleManager.addParticle must never return null: fireworks call setTrail on its result).
     */
    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;ZZDDDDDD)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void hackclient$cullParticle(ParticleEffect parameters, boolean shouldAlwaysSpawn, boolean important,
                                         double x, double y, double z, double velocityX, double velocityY,
                                         double velocityZ, CallbackInfo ci) {
        if (!important && Optimization.cullParticle(x, y, z)) {
            ci.cancel();
        }
    }
}
