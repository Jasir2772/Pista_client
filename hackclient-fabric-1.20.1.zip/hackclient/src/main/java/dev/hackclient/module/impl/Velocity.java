package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;

/** Scales the knockback packets aimed at you. 0 / 0 cancels them; 100 / 100 is vanilla. */
public final class Velocity extends Module {
    private static Velocity instance;

    private final NumberSetting horizontal = number("Horizontal", 0, 0, 100, 1);
    private final NumberSetting vertical = number("Vertical", 0, 0, 100, 1);

    public Velocity() {
        super("Velocity", Category.COMBAT, "Reduces the knockback you take");
        instance = this;
    }

    public static boolean active() {
        return instance != null && instance.isEnabled();
    }

    /** True when the packet was handled here and vanilla handling must be cancelled. */
    public static boolean consume(EntityVelocityUpdateS2CPacket packet) {
        Velocity self = instance;
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (self == null || player == null || packet.getId() != player.getId()) {
            return false;
        }
        double h = self.horizontal.get() / 100.0;
        double v = self.vertical.get() / 100.0;
        if (h >= 1.0 && v >= 1.0) {
            return false;
        }
        player.setVelocityClient(
                packet.getVelocityX() / 8000.0 * h,
                packet.getVelocityY() / 8000.0 * v,
                packet.getVelocityZ() / 8000.0 * h);
        return true;
    }
}
