package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Theme;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;

/** Highlights the block you are looking at with a tinted, outlined box. */
public final class BlockOverlay extends Module {
    private final BoolSetting fill = bool("Fill", true);
    private final BoolSetting rainbow = bool("Rainbow", false);

    private final float[] rect = new float[4];

    public BlockOverlay() {
        super("BlockOverlay", Category.RENDER, "Tinted box on the targeted block");
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.currentScreen != null || !RenderUtil.isReady()
                || !(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            return;
        }
        BlockPos pos = hit.getBlockPos();
        BlockState state = mc.world.getBlockState(pos);
        VoxelShape shape = state.getOutlineShape(mc.world, pos);
        if (shape.isEmpty()) {
            return;
        }
        Box box = shape.getBoundingBox().offset(pos);
        if (!RenderUtil.projectBox(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ, rect)) {
            return;
        }
        int color = rainbow.get() ? Theme.hue((System.currentTimeMillis() % 4000L) / 4000.0f) : Theme.accent();
        if (fill.get()) {
            RenderUtil.fillHalf(ctx, rect[0], rect[1], rect[2], rect[3], Theme.withAlpha(color, 0.18f));
        }
        RenderUtil.outline(ctx, rect[0], rect[1], rect[2], rect[3], color);
    }
}
