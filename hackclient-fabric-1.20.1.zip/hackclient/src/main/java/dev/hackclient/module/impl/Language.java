package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.ModeSetting;

/**
 * Switches the client's own chrome (GUI labels, HUD footer, notifications, chat replies) between English and Uzbek.
 * Module and setting names stay in English, as in every client of this kind, so .bind/.toggle commands keep working either way.
 * This only changes text: it has no on/off effect of its own, so its value is read directly rather than gated on isEnabled().
 */
public final class Language extends Module {
    private static Language instance;

    private final ModeSetting language = mode("Language", "English", "English", "Uzbek");

    public Language() {
        super("Language", Category.UTILS, "English / Uzbek interface");
        instance = this;
    }

    public static boolean isUzbek() {
        return instance != null && instance.language.is("Uzbek");
    }

    @Override
    public boolean showInList() {
        return false;
    }
}
