package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** A ring that spreads out and fades on the ground where you jumped. */
public final class JumpCircles extends Module {
    private static final int SEGMENTS = 28;

    private record Circle(Vec3d pos, long start) {
    }

    private final NumberSetting size = number("Size", 1.5, 0.5, 3.0, 0.1);
    private final NumberSetting duration = number("Duration", 1.0, 0.4, 2.5, 0.1);
    private final BoolSetting rainbow = bool("Rainbow", false);

    private final List<Circle> circles = new ArrayList<>();
    private final float[] prev = new float[2];
    private final float[] cur = new float[2];
    private boolean wasOnGround = true;

    public JumpCircles() {
        super("JumpCircles", Category.RENDER, "Fading ring where you jump");
    }

    @Override
    protected void onDisable() {
        circles.clear();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            circles.clear();
            return;
        }
        boolean ground = player.isOnGround();
        if (wasOnGround && !ground && player.getVelocity().y > 0.1) {
            circles.add(new Circle(player.getPos(), System.currentTimeMillis()));
        }
        wasOnGround = ground;
        long limit = (long) (duration.get() * 1000.0);
        circles.removeIf(c -> System.currentTimeMillis() - c.start() > limit);
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        if (circles.isEmpty() || !RenderUtil.isReady()) {
            return;
        }
        long now = System.currentTimeMillis();
        double total = duration.get() * 1000.0;
        for (Circle circle : circles) {
            double age = Math.min(1.0, (now - circle.start()) / total);
            double radius = 0.25 + age * size.get();
            float alpha = (float) (1.0 - age);
            boolean havePrev = false;
            for (int i = 0; i <= SEGMENTS; i++) {
                double angle = i * (Math.PI * 2.0 / SEGMENTS);
                boolean ok = RenderUtil.project(circle.pos().x + Math.cos(angle) * radius, circle.pos().y + 0.03,
                        circle.pos().z + Math.sin(angle) * radius, cur);
                if (ok && havePrev) {
                    float t = i / (float) SEGMENTS;
                    int base = rainbow.get() ? Theme.hue(t) : Theme.mix(Theme.accent(), Theme.accent2(), t);
                    RenderUtil.line(ctx, prev[0], prev[1], cur[0], cur[1], Theme.withAlpha(base, alpha * 0.2f), 5);
                    RenderUtil.line(ctx, prev[0], prev[1], cur[0], cur[1], Theme.withAlpha(base, alpha), 2);
                }
                havePrev = ok;
                prev[0] = cur[0];
                prev[1] = cur[1];
            }
        }
    }
}
