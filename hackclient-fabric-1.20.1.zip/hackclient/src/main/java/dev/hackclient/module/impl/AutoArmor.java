package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ElytraItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

import java.util.concurrent.ThreadLocalRandom;

/** Equips the best armor found in the inventory using normal shift-clicks, one click per delay. */
public final class AutoArmor extends Module {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private final NumberSetting delay = number("Delay", 4, 0, 20, 1);
    private final BoolSetting onlyInventory = bool("OnlyInventory", true);
    private final BoolSetting replaceWorse = bool("ReplaceWorse", true);
    private final BoolSetting keepElytra = bool("KeepElytra", true);

    private int cooldown;

    public AutoArmor() {
        super("AutoArmor", Category.COMBAT, "Equips the best armor in your inventory");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        ClientPlayerInteractionManager manager = mc.interactionManager;
        if (player == null || manager == null || !player.isAlive() || player.isSpectator()) {
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        boolean inventoryOpen = mc.currentScreen instanceof InventoryScreen;
        if (mc.currentScreen != null && !inventoryOpen) {
            return;
        }
        if (onlyInventory.get() && !inventoryOpen) {
            return;
        }

        PlayerScreenHandler handler = player.playerScreenHandler;
        for (EquipmentSlot equipmentSlot : SLOTS) {
            // PlayerScreenHandler: 5 head, 6 chest, 7 legs, 8 feet; 9..35 inventory, 36..44 hotbar.
            int armorSlotId = 8 - equipmentSlot.getEntitySlotId();
            ItemStack worn = handler.getSlot(armorSlotId).getStack();
            if (keepElytra.get() && equipmentSlot == EquipmentSlot.CHEST && worn.getItem() instanceof ElytraItem) {
                continue;
            }

            int bestSlot = -1;
            double bestScore = worn.isEmpty() ? -1.0 : score(worn, equipmentSlot) + 0.01;
            for (int i = 9; i <= 44; i++) {
                double candidate = score(handler.getSlot(i).getStack(), equipmentSlot);
                if (candidate > bestScore) {
                    bestScore = candidate;
                    bestSlot = i;
                }
            }
            if (bestSlot < 0) {
                continue;
            }

            if (worn.isEmpty()) {
                click(manager, handler, player, bestSlot);
                cooldown = nextDelay();
                return;
            }
            if (!replaceWorse.get() || EnchantmentHelper.hasBindingCurse(worn)) {
                continue;
            }
            if (player.getInventory().getEmptySlot() < 0) {
                continue;
            }
            click(manager, handler, player, armorSlotId);
            cooldown = nextDelay();
            return;
        }
    }

    private static void click(ClientPlayerInteractionManager manager, PlayerScreenHandler handler,
                              ClientPlayerEntity player, int slotId) {
        manager.clickSlot(handler.syncId, slotId, 0, SlotActionType.QUICK_MOVE, player);
    }

    private int nextDelay() {
        return delay.getInt() + ThreadLocalRandom.current().nextInt(0, 3);
    }

    /** Heuristic: protection + half toughness + 0.75 per Protection level. -1 means "not usable here". */
    private static double score(ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem armor) || armor.getSlotType() != slot) {
            return -1.0;
        }
        if (stack.isDamageable() && stack.getMaxDamage() - stack.getDamage() <= 1) {
            return -1.0;
        }
        return armor.getProtection()
                + armor.getToughness() * 0.5
                + EnchantmentHelper.getLevel(Enchantments.PROTECTION, stack) * 0.75;
    }
}
