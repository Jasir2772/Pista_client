package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;

/** A fading line behind you, drawn with the same screen-space projection as ESP and Tracers. */
public final class Trails extends Module {
    private final NumberSetting length = number("Length", 60, 10, 200, 5);
    private final NumberSetting thickness = number("Thickness", 2, 1, 6, 1);
    private final ModeSetting color = mode("Color", "Accent", "Accent", "Rainbow");

    private final ArrayDeque<Vec3d> points = new ArrayDeque<>();
    private float[] prev = new float[2];
    private float[] cur = new float[2];

    public Trails() {
        super("Trails", Category.RENDER, "Fading line behind you");
    }

    @Override
    protected void onDisable() {
        points.clear();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            points.clear();
            return;
        }
        Vec3d pos = player.getPos();
        if (points.isEmpty() || points.peekLast().squaredDistanceTo(pos) > 0.0004) {
            points.addLast(pos);
        }
        while (points.size() > length.getInt()) {
            points.removeFirst();
        }
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || !RenderUtil.isReady() || points.size() < 2) {
            return;
        }
        int n = points.size();
        int i = 0;
        boolean havePrev = false;
        for (Vec3d p : points) {
            boolean ok = RenderUtil.project(p.x, p.y + 0.05, p.z, cur);
            if (ok && havePrev) {
                RenderUtil.line(ctx, prev[0], prev[1], cur[0], cur[1], colorAt(i, n), thickness.getInt());
            }
            havePrev = ok;
            float[] tmp = prev;
            prev = cur;
            cur = tmp;
            i++;
        }
        Vec3d live = player.getLerpedPos(RenderUtil.tickDelta());
        if (havePrev && RenderUtil.project(live.x, live.y + 0.05, live.z, cur)) {
            RenderUtil.line(ctx, prev[0], prev[1], cur[0], cur[1], colorAt(n, n), thickness.getInt());
        }
    }

    private int colorAt(int index, int total) {
        float fade = 0.15f + 0.85f * (index / (float) Math.max(1, total));
        int base = color.is("Rainbow")
                ? hue((index * 5 + (System.currentTimeMillis() / 20)) % 360 / 360.0f)
                : Theme.accent();
        return Theme.withAlpha(base, fade);
    }

    /** Hue 0..1 to opaque ARGB (saturation 0.65, value 1). */
    private static int hue(float h) {
        float s = 0.65f;
        float v = 1.0f;
        float scaled = (h - (float) Math.floor(h)) * 6.0f;
        int sector = (int) scaled;
        float f = scaled - sector;
        float p = v * (1.0f - s);
        float q = v * (1.0f - s * f);
        float t = v * (1.0f - s * (1.0f - f));
        float r;
        float g;
        float b;
        if (sector == 0) {
            r = v; g = t; b = p;
        } else if (sector == 1) {
            r = q; g = v; b = p;
        } else if (sector == 2) {
            r = p; g = v; b = t;
        } else if (sector == 3) {
            r = p; g = q; b = v;
        } else if (sector == 4) {
            r = t; g = p; b = v;
        } else {
            r = v; g = p; b = q;
        }
        return 0xFF000000 | (Math.round(r * 255.0f) << 16) | (Math.round(g * 255.0f) << 8) | Math.round(b * 255.0f);
    }
}
