package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;

/** Camera distance (and optional wall pass-through) for the third-person view. Applied by a Camera mixin. */
public final class ThirdPerson extends Module {
    private static ThirdPerson instance;

    private final NumberSetting distance = number("Distance", 4.0, 1.0, 20.0, 0.5);
    private final BoolSetting noClip = bool("NoClip", true);

    public ThirdPerson() {
        super("ThirdPerson", Category.RENDER, "Camera distance in third person");
        instance = this;
    }

    public static boolean active() {
        return instance != null && instance.isEnabled();
    }

    public static double distance() {
        return instance == null ? 4.0 : instance.distance.get();
    }

    public static boolean noClip() {
        return instance != null && instance.noClip.get();
    }
}
