package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.util.Chat;
import dev.hackclient.util.Lang;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** One-shot module: bind it to a key. Each press throws an ender pearl, then the module switches itself off. */
public final class ClickPearl extends Module {
    private final BoolSetting swapBack = bool("SwapBack", true);
    private boolean pending;

    public ClickPearl() {
        super("ClickPearl", Category.PLAYER, "Bind a key: throws an ender pearl");
    }

    @Override
    public boolean showInList() {
        return false;
    }

    @Override
    protected void onEnable() {
        pending = true;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (!pending) {
            setEnabled(false);
            return;
        }
        pending = false;
        ClientPlayerEntity player = mc.player;
        // Switched on from the ClickGUI (a screen is open) or without a world: do nothing.
        if (player == null || mc.interactionManager == null || mc.currentScreen != null) {
            setEnabled(false);
            return;
        }

        if (player.getOffHandStack().isOf(Items.ENDER_PEARL)) {
            mc.interactionManager.interactItem(player, Hand.OFF_HAND);
        } else {
            int slot = -1;
            for (int i = 0; i < 9; i++) {
                if (player.getInventory().getStack(i).isOf(Items.ENDER_PEARL)) {
                    slot = i;
                    break;
                }
            }
            if (slot < 0) {
                Chat.say(Lang.t("No ender pearl in the hotbar", "Hotbarda ender pearl yo'q"));
            } else {
                int previous = player.getInventory().selectedSlot;
                player.getInventory().selectedSlot = slot;
                mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
                if (swapBack.get()) {
                    player.getInventory().selectedSlot = previous;
                }
            }
        }
        setEnabled(false);
    }
}
