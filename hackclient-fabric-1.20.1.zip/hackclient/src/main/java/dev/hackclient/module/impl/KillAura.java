package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.SilentRotation;
import dev.hackclient.util.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Rotation is decided at the start of the tick (so the movement packet of that tick carries it), the attack happens at the end.
 * Rotation "Silent" leaves your camera alone, "Visible" turns the camera, "Assist" turns the camera while you hold
 * the attack key (never attacks by itself), "Off" never rotates.
 * Humanization options (Ease smoothing, random aim point, reaction delay, wobble, hesitation) only change how the input
 * looks. Nothing here is tuned against, or tested on, any particular anti-cheat.
 */
public final class KillAura extends Module {
    private static LivingEntity currentTarget;
    private static boolean suppressSprint;

    private final ModeSetting preset = mode("Preset", "Normal", "Legit", "Normal", "Rage");
    private final NumberSetting range = number("Range", 3.0, 2.0, 6.0, 0.1);
    private final ModeSetting rotation = mode("Rotation", "Silent", "Silent", "Visible", "Assist", "Off");
    private final BoolSetting onlyCrits = bool("OnlyCrits", false);
    private final BoolSetting critJump = bool("CritJump", false);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting hostiles = bool("Hostiles", true);
    private final BoolSetting passives = bool("Passives", false);
    private final BoolSetting advanced = bool("Advanced", false);
    private final NumberSetting fov = number("FOV", 180, 30, 360, 5);
    private final ModeSetting sort = mode("Sort", "Distance", "Distance", "Health", "Angle", "Smart");
    private final BoolSetting invisible = bool("Invisible", false);
    private final BoolSetting wallCheck = bool("WallCheck", true);
    private final BoolSetting rayCheck = bool("RayCheck", true);
    private final BoolSetting onlyWeapon = bool("OnlyWeapon", true);
    private final BoolSetting noUseItem = bool("NoUseItem", true);
    private final NumberSetting turnSpeed = number("TurnSpeed", 30, 5, 180, 1);
    private final BoolSetting mouseGcd = bool("MouseGCD", true);
    private final NumberSetting minCooldown = number("MinCooldown", 0.92, 0.5, 1.0, 0.01);
    private final ModeSetting smoothing = mode("Smoothing", "Ease", "Ease", "Linear");
    private final ModeSetting aimPoint = mode("AimPoint", "Closest", "Closest", "Random");
    private final NumberSetting reaction = number("ReactionTicks", 1, 0, 8, 1);
    private final NumberSetting wobble = number("Wobble", 0.25, 0.0, 2.0, 0.05);
    private final NumberSetting hesitation = number("Hesitation", 3, 0, 25, 1);
    private final NumberSetting preRange = number("PreRange", 0.0, 0.0, 3.0, 0.1);
    private final NumberSetting predict = number("PredictTicks", 0, 0, 6, 1);
    private final NumberSetting assistSpeed = number("AssistSpeed", 6, 1, 30, 1);

    private LivingEntity target;
    private float requiredCooldown = 1.0f;
    private float silentYaw;
    private float silentPitch;
    private boolean hasSilent;
    private boolean jumpHeld;
    private float stepYaw;
    private float stepPitch;

    private LivingEntity lastAimTarget;
    private boolean holding;
    private int reactionLeft;
    private int ticksOnTarget;
    private int attackDelay;
    private int age;
    private int nextGoalTick;
    private Vec3d aimOffset = new Vec3d(0.0, 0.6, 0.0);
    private Vec3d aimGoal = new Vec3d(0.0, 0.6, 0.0);
    private final double[] phase = new double[4];

    public KillAura() {
        super("KillAura", Category.COMBAT, "Attacks nearby entities");
        critJump.setVisibility(onlyCrits::get);
        for (var s : new dev.hackclient.module.setting.Setting[]{fov, sort, invisible, wallCheck, rayCheck,
                onlyWeapon, noUseItem, turnSpeed, mouseGcd, minCooldown, smoothing, aimPoint, reaction, wobble,
                hesitation, preRange, predict}) {
            s.setVisibility(advanced::get);
        }
        assistSpeed.setVisibility(() -> rotation.is("Assist"));
        for (int i = 0; i < phase.length; i++) {
            phase[i] = ThreadLocalRandom.current().nextDouble() * Math.PI * 2.0;
        }
        applyPreset();
    }

    /**
     * Presets fill in range, FOV, turn speed, cooldown spread and the humanization options below.
     * "Legit" is slower and narrower with more human-looking aim, "Rage" is faster, wider and plain.
     */
    private void applyPreset() {
        switch (preset.get()) {
            case "Legit" -> {
                range.set(3.2);
                fov.set(60);
                turnSpeed.set(14);
                minCooldown.set(0.97);
                onlyCrits.set(true);
                pick(smoothing, "Ease");
                pick(aimPoint, "Random");
                reaction.set(3);
                wobble.set(0.6);
                hesitation.set(6);
                preRange.set(0.0);
                predict.set(0);
            }
            case "Rage" -> {
                range.set(4.2);
                fov.set(360);
                turnSpeed.set(60);
                minCooldown.set(0.75);
                onlyCrits.set(false);
                pick(smoothing, "Linear");
                pick(aimPoint, "Closest");
                reaction.set(0);
                wobble.set(0.0);
                hesitation.set(0);
                preRange.set(1.0);
                predict.set(2);
            }
            default -> {
                range.set(3.5);
                fov.set(180);
                turnSpeed.set(30);
                minCooldown.set(0.9);
                pick(smoothing, "Ease");
                pick(aimPoint, "Closest");
                reaction.set(1);
                wobble.set(0.25);
                hesitation.set(3);
                preRange.set(0.5);
                predict.set(0);
            }
        }
    }

    public static LivingEntity target() {
        return currentTarget;
    }

    public static boolean suppressSprint() {
        return suppressSprint;
    }

    @Override
    protected void onDisable() {
        reset();
    }

    private void reset() {
        target = null;
        currentTarget = null;
        suppressSprint = false;
        hasSilent = false;
        SilentRotation.clear();
        if (jumpHeld) {
            MinecraftClient.getInstance().options.jumpKey.setPressed(false);
            jumpHeld = false;
        }
    }

    private boolean canRun(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        return player != null && mc.world != null && mc.interactionManager != null
                && mc.currentScreen == null && player.isAlive()
                && (!onlyWeapon.get() || Targets.isHoldingWeapon(player));
    }

    private int lastPresetIndex = -1;

    private static void pick(ModeSetting setting, String mode) {
        for (int i = 0; i < 8 && !setting.is(mode); i++) {
            setting.next();
        }
    }

    @Override
    public void onPreTick(MinecraftClient mc) {
        // The first tick only remembers the loaded preset, so values saved in the config are not overwritten.
        if (lastPresetIndex < 0) {
            lastPresetIndex = preset.index();
        } else if (preset.index() != lastPresetIndex) {
            lastPresetIndex = preset.index();
            applyPreset();
        }
        holding = false;
        age++;
        if (!canRun(mc)) {
            reset();
            return;
        }
        ClientPlayerEntity player = mc.player;
        Vec3d eye = player.getEyePos();
        if (target == null || !isValid(player, target, eye)) {
            target = findTarget(player, mc.world, eye);
        }
        currentTarget = target;
        if (target != lastAimTarget) {
            lastAimTarget = target;
            ticksOnTarget = 0;
            int maxReaction = reaction.getInt();
            reactionLeft = target == null || maxReaction <= 0 ? 0 : ThreadLocalRandom.current().nextInt(maxReaction + 1);
            if (target != null) {
                pickAimGoal(true);
            }
        }
        if (target == null || rotation.is("Off") || (rotation.is("Assist") && !mc.options.attackKey.isPressed())) {
            releaseRotation(mc, player);
            return;
        }
        ticksOnTarget++;
        if (reactionLeft > 0) {
            // Reaction delay: a new target is noticed a few ticks late, so neither rotation nor attack starts at once.
            reactionLeft--;
            holding = true;
            if (rotation.is("Silent") && hasSilent) {
                SilentRotation.set(silentYaw, silentPitch);
            }
            return;
        }

        Vec3d aim = aimPointFor(eye, target);
        float targetYaw = Targets.yawTo(eye, aim) + wobbleYaw();
        float targetPitch = MathHelper.clamp(Targets.pitchTo(eye, aim) + wobblePitch(), -90.0f, 90.0f);
        if (rotation.is("Silent")) {
            if (!hasSilent) {
                silentYaw = player.getYaw();
                silentPitch = player.getPitch();
                hasSilent = true;
            }
            stepToward(mc, silentYaw, silentPitch, targetYaw, targetPitch, true);
            silentYaw += stepYaw;
            silentPitch = MathHelper.clamp(silentPitch + stepPitch, -90.0f, 90.0f);
            SilentRotation.set(silentYaw, silentPitch);
        } else {
            hasSilent = false;
            SilentRotation.clear();
            stepToward(mc, player.getYaw(), player.getPitch(), targetYaw, targetPitch, true);
            if (stepYaw != 0.0f || stepPitch != 0.0f) {
                float oldPitch = player.getPitch();
                float newPitch = MathHelper.clamp(oldPitch + stepPitch, -90.0f, 90.0f);
                player.setYaw(player.getYaw() + stepYaw);
                player.setPitch(newPitch);
                player.prevYaw += stepYaw;
                player.prevPitch += newPitch - oldPitch;
            }
        }
    }

    /** After the target is gone, eases the silent rotation back to the camera so the server never sees a snap. */
    private void releaseRotation(MinecraftClient mc, ClientPlayerEntity player) {
        if (!hasSilent) {
            SilentRotation.clear();
            return;
        }
        stepToward(mc, silentYaw, silentPitch, player.getYaw(), player.getPitch(), false);
        silentYaw += stepYaw;
        silentPitch = MathHelper.clamp(silentPitch + stepPitch, -90.0f, 90.0f);
        float err = (float) Math.hypot(MathHelper.wrapDegrees(player.getYaw() - silentYaw), player.getPitch() - silentPitch);
        if (err < 1.0f) {
            hasSilent = false;
            SilentRotation.clear();
        } else {
            SilentRotation.set(silentYaw, silentPitch);
        }
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (jumpHeld) {
            mc.options.jumpKey.setPressed(false);
            jumpHeld = false;
        }
        suppressSprint = false;
        if (player == null || target == null || !canRun(mc) || holding || rotation.is("Assist")) {
            return;
        }
        suppressSprint = onlyCrits.get();
        if (noUseItem.get() && player.isUsingItem()) {
            return;
        }
        if (attackDelay > 0) {
            attackDelay--;
            return;
        }
        if (player.getAttackCooldownProgress(0.5f) < requiredCooldown) {
            return;
        }
        if (onlyCrits.get() && !Targets.canCrit(player)) {
            if (player.isSprinting() && !player.isOnGround()) {
                player.setSprinting(false);
            } else if (critJump.get() && player.isOnGround() && !player.isTouchingWater()) {
                mc.options.jumpKey.setPressed(true);
                jumpHeld = true;
            }
            return;
        }
        Vec3d eye = player.getEyePos();
        if (Targets.distanceToBox(eye, target.getBoundingBox()) > range.get()) {
            return;
        }
        if (rayCheck.get() && !lookingAt(player, eye, target.getBoundingBox())) {
            return;
        }
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        if (hesitation.getInt() > 0 && rng.nextInt(100) < hesitation.getInt()) {
            attackDelay = 1 + rng.nextInt(3);
            return;
        }
        mc.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        float min = minCooldown.getFloat();
        requiredCooldown = min + ThreadLocalRandom.current().nextFloat() * (1.0f - min);
    }

    private boolean isValid(ClientPlayerEntity player, Entity e, Vec3d eye) {
        if (!Targets.isAttackable(e, players.get(), hostiles.get(), passives.get(), invisible.get())) {
            return false;
        }
        Box box = e.getBoundingBox();
        if (Targets.distanceToBox(eye, box) > range.get() + preRange.get()) {
            return false;
        }
        if (fov.get() < 360.0) {
            float yawDiff = Math.abs(MathHelper.wrapDegrees(Targets.yawTo(eye, Targets.aimPoint(eye, box)) - player.getYaw()));
            if (yawDiff > fov.get() / 2.0) {
                return false;
            }
        }
        return !wallCheck.get() || player.canSee(e);
    }

    private LivingEntity findTarget(ClientPlayerEntity player, ClientWorld world, Vec3d eye) {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : world.getEntities()) {
            if (!(e instanceof LivingEntity living) || !isValid(player, e, eye)) {
                continue;
            }
            double score;
            if (sort.is("Health")) {
                score = living.getHealth();
            } else if (sort.is("Angle")) {
                score = Math.abs(MathHelper.wrapDegrees(Targets.yawTo(eye, Targets.aimPoint(eye, e.getBoundingBox())) - player.getYaw()));
            } else if (sort.is("Smart")) {
                // Own heuristic: close, in front of you and low on health scores best.
                double yawDiff = Math.abs(MathHelper.wrapDegrees(Targets.yawTo(eye, Targets.aimPoint(eye, e.getBoundingBox())) - player.getYaw()));
                score = Targets.distanceToBox(eye, e.getBoundingBox()) + yawDiff / 45.0 + living.getHealth() / 10.0;
            } else {
                score = Targets.distanceToBox(eye, e.getBoundingBox());
            }
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }

    private boolean lookingAt(ClientPlayerEntity player, Vec3d eye, Box box) {
        if (box.contains(eye)) {
            return true;
        }
        Vec3d look = SilentRotation.isActive()
                ? Vec3d.fromPolar(SilentRotation.pitch(), SilentRotation.yaw())
                : player.getRotationVec(1.0f);
        return box.raycast(eye, eye.add(look.multiply(range.get() + 0.5))).isPresent();
    }

    /** Computes the next rotation step (stepYaw/stepPitch) from the current angles toward the target angles. */
    private void stepToward(MinecraftClient mc, float curYaw, float curPitch, float targetYaw, float targetPitch,
                            boolean ramped) {
        stepYaw = 0.0f;
        stepPitch = 0.0f;
        float yawErr = MathHelper.wrapDegrees(targetYaw - curYaw);
        float pitchErr = targetPitch - curPitch;
        float err = (float) Math.hypot(yawErr, pitchErr);
        if (err < 0.01f) {
            return;
        }
        // After a target is acquired the turn speed ramps up over the first ticks instead of starting at full speed.
        float ramp = ramped ? Math.min(1.0f, 0.4f + 0.2f * ticksOnTarget) : 1.0f;
        float baseSpeed = rotation.is("Assist") ? assistSpeed.getFloat() : turnSpeed.getFloat();
        float maxStep = baseSpeed * ramp * (0.8f + ThreadLocalRandom.current().nextFloat() * 0.4f);
        float desired;
        if (smoothing.is("Ease")) {
            // Decelerates near the target (about 45% of the remaining error per tick) instead of a constant step.
            desired = Math.min(err, Math.min(maxStep, Math.max(err * 0.45f, Math.min(err, 0.9f))));
        } else {
            desired = Math.min(err, maxStep);
        }
        float scale = desired / err;
        float dYaw = yawErr * scale;
        float dPitch = pitchErr * scale;
        if (mouseGcd.get()) {
            float step = mouseStep(mc);
            dYaw = Math.round(dYaw / step) * step;
            dPitch = Math.round(dPitch / step) * step;
        }
        stepYaw = dYaw;
        stepPitch = dPitch;
    }

    /** Closest point of the hitbox, or a slowly drifting point inside it (kept relative to the box, so it follows the target). */
    private Vec3d aimPointFor(Vec3d eye, LivingEntity entity) {
        Vec3d point = rawAimPoint(eye, entity);
        int ticks = predict.getInt();
        if (ticks <= 0) {
            return point;
        }
        // Horizontal lead only: where the target will be in a few ticks, from its last-tick movement.
        return point.add((entity.getX() - entity.prevX) * ticks, 0.0, (entity.getZ() - entity.prevZ) * ticks);
    }

    private Vec3d rawAimPoint(Vec3d eye, LivingEntity entity) {
        Box box = entity.getBoundingBox();
        if (aimPoint.is("Closest")) {
            return Targets.aimPoint(eye, box);
        }
        if (age >= nextGoalTick) {
            pickAimGoal(false);
        }
        aimOffset = new Vec3d(
                aimOffset.x + (aimGoal.x - aimOffset.x) * 0.2,
                aimOffset.y + (aimGoal.y - aimOffset.y) * 0.2,
                aimOffset.z + (aimGoal.z - aimOffset.z) * 0.2);
        double halfWidth = (box.maxX - box.minX) / 2.0;
        return new Vec3d(
                (box.minX + box.maxX) / 2.0 + aimOffset.x * halfWidth,
                box.minY + aimOffset.y * (box.maxY - box.minY),
                (box.minZ + box.maxZ) / 2.0 + aimOffset.z * halfWidth);
    }

    private void pickAimGoal(boolean snap) {
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        aimGoal = new Vec3d(rng.nextDouble(-0.55, 0.55), rng.nextDouble(0.35, 0.9), rng.nextDouble(-0.55, 0.55));
        nextGoalTick = age + 8 + rng.nextInt(14);
        if (snap) {
            aimOffset = aimGoal;
        }
    }

    /** Slow, small drift (degrees) added to the aim so the error is never exactly zero for many ticks in a row. */
    private float wobbleYaw() {
        double w = wobble.get();
        return w <= 0.0 ? 0.0f : (float) (w * (Math.sin(age * 0.11 + phase[0]) + 0.5 * Math.sin(age * 0.27 + phase[1])) / 1.5);
    }

    private float wobblePitch() {
        double w = wobble.get();
        return w <= 0.0 ? 0.0f : (float) (w * 0.6 * (Math.sin(age * 0.09 + phase[2]) + 0.5 * Math.sin(age * 0.23 + phase[3])) / 1.5);
    }

    /** Smallest rotation a real mouse can produce at the current sensitivity (vanilla: (s*0.6+0.2)^3 * 8 * 0.15). */
    private static float mouseStep(MinecraftClient mc) {
        double f = mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }
}
