package dev.hackclient.module.impl;

import dev.hackclient.mixin.MinecraftClientAccessor;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Shortens the delay between item uses (block placing, throwing XP bottles). */
public final class FastPlace extends Module {
    private final ModeSetting items = mode("Items", "All", "All", "Blocks", "Exp");
    private final NumberSetting delay = number("Delay", 0, 0, 4, 1);

    public FastPlace() {
        super("FastPlace", Category.PLAYER, "No delay when placing or throwing");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.currentScreen != null) {
            return;
        }
        ItemStack stack = mc.player.getMainHandStack();
        boolean applies = items.is("All")
                || (items.is("Blocks") && stack.getItem() instanceof BlockItem)
                || (items.is("Exp") && stack.isOf(Items.EXPERIENCE_BOTTLE));
        if (!applies) {
            return;
        }
        MinecraftClientAccessor accessor = (MinecraftClientAccessor) mc;
        if (accessor.getItemUseCooldown() > delay.getInt()) {
            accessor.setItemUseCooldown(delay.getInt());
        }
    }
}
