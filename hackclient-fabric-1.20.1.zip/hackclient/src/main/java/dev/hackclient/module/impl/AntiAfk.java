package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.concurrent.ThreadLocalRandom;

/** Every so often, either jumps or nudges the view a few degrees. */
public final class AntiAfk extends Module {
    private final NumberSetting intervalSeconds = number("IntervalSec", 30, 10, 120, 5);
    private int ticks;
    private int nextAction;
    private boolean jumpHeld;

    public AntiAfk() {
        super("AntiAFK", Category.MOVEMENT, "Small periodic actions so you are not kicked for idling");
    }

    @Override
    protected void onEnable() {
        ticks = 0;
        nextAction = schedule();
    }

    @Override
    protected void onDisable() {
        releaseJump();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        if (jumpHeld) {
            releaseJump();
        }
        if (mc.currentScreen != null || ++ticks < nextAction) {
            return;
        }
        ticks = 0;
        nextAction = schedule();
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        if (rng.nextBoolean()) {
            mc.options.jumpKey.setPressed(true);
            jumpHeld = true;
        } else {
            float delta = (rng.nextFloat() - 0.5f) * 30.0f;
            player.setYaw(player.getYaw() + delta);
            player.prevYaw += delta;
        }
    }

    private int schedule() {
        double base = intervalSeconds.get() * 20.0;
        return (int) (base * (0.7 + ThreadLocalRandom.current().nextDouble() * 0.6));
    }

    private void releaseJump() {
        if (jumpHeld) {
            MinecraftClient.getInstance().options.jumpKey.setPressed(false);
            jumpHeld = false;
        }
    }
}
