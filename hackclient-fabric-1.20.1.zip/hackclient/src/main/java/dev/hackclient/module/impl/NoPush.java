package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;

public final class NoPush extends Module {
    private static NoPush instance;

    private final BoolSetting entities = bool("Entities", true);
    private final BoolSetting blocks = bool("Blocks", true);

    public NoPush() {
        super("NoPush", Category.PLAYER, "Entities and blocks cannot push you");
        instance = this;
    }

    public static boolean entities() {
        return instance != null && instance.isEnabled() && instance.entities.get();
    }

    public static boolean blocks() {
        return instance != null && instance.isEnabled() && instance.blocks.get();
    }
}
