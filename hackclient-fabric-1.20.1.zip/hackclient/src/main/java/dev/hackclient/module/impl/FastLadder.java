package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Faster upward climbing on ladders and vines while the jump key is held (vanilla is 0.2). */
public final class FastLadder extends Module {
    private final NumberSetting speed = number("Speed", 0.3, 0.2, 0.6, 0.02);

    public FastLadder() {
        super("FastLadder", Category.MOVEMENT, "Climb ladders faster");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || !player.isClimbing() || !mc.options.jumpKey.isPressed()) {
            return;
        }
        Vec3d v = player.getVelocity();
        player.setVelocity(v.x, speed.get(), v.z);
    }
}
