package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/** Scans a cube around the player at a fixed interval and outlines selected blocks. The scan is capped to keep frame time flat. */
public final class BlockEsp extends Module {
    private static final int SCAN_CAP = 4096;

    private record Found(BlockPos pos, int color, int distSq) {
    }

    private final NumberSetting radius = number("Radius", 14, 6, 24, 1);
    private final NumberSetting interval = number("ScanTicks", 20, 5, 100, 5);
    private final NumberSetting maxBoxes = number("MaxBoxes", 120, 20, 300, 10);
    private final BoolSetting diamond = bool("Diamond", true);
    private final BoolSetting emerald = bool("Emerald", true);
    private final BoolSetting gold = bool("Gold", false);
    private final BoolSetting iron = bool("Iron", false);
    private final BoolSetting debris = bool("AncientDebris", true);
    private final BoolSetting chests = bool("Chests", false);
    private final BoolSetting spawners = bool("Spawners", false);

    private List<Found> found = new ArrayList<>();
    private int counter;
    private final float[] rect = new float[4];

    public BlockEsp() {
        super("BlockESP", Category.RENDER, "Outlines ores and containers nearby");
    }

    @Override
    protected void onEnable() {
        counter = Integer.MAX_VALUE / 2;
    }

    @Override
    protected void onDisable() {
        found = new ArrayList<>();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (player == null || world == null) {
            return;
        }
        if (++counter >= interval.getInt()) {
            counter = 0;
            scan(world, player);
        }
    }

    private Map<Block, Integer> buildColors() {
        Map<Block, Integer> map = new IdentityHashMap<>();
        if (diamond.get()) {
            map.put(Blocks.DIAMOND_ORE, 0xFF55FFFF);
            map.put(Blocks.DEEPSLATE_DIAMOND_ORE, 0xFF55FFFF);
        }
        if (emerald.get()) {
            map.put(Blocks.EMERALD_ORE, 0xFF55FF55);
            map.put(Blocks.DEEPSLATE_EMERALD_ORE, 0xFF55FF55);
        }
        if (gold.get()) {
            map.put(Blocks.GOLD_ORE, 0xFFFFD700);
            map.put(Blocks.DEEPSLATE_GOLD_ORE, 0xFFFFD700);
        }
        if (iron.get()) {
            map.put(Blocks.IRON_ORE, 0xFFD8AF93);
            map.put(Blocks.DEEPSLATE_IRON_ORE, 0xFFD8AF93);
        }
        if (debris.get()) {
            map.put(Blocks.ANCIENT_DEBRIS, 0xFFB5651D);
        }
        if (chests.get()) {
            map.put(Blocks.CHEST, 0xFFFFAA00);
            map.put(Blocks.TRAPPED_CHEST, 0xFFFF5555);
        }
        if (spawners.get()) {
            map.put(Blocks.SPAWNER, 0xFFAA55FF);
        }
        return map;
    }

    private void scan(ClientWorld world, ClientPlayerEntity player) {
        Map<Block, Integer> colors = buildColors();
        List<Found> next = new ArrayList<>();
        if (!colors.isEmpty()) {
            int r = radius.getInt();
            BlockPos origin = player.getBlockPos();
            int minY = Math.max(world.getBottomY(), origin.getY() - r);
            int maxY = Math.min(world.getTopY() - 1, origin.getY() + r);
            BlockPos.Mutable cursor = new BlockPos.Mutable();
            scan:
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    for (int y = minY; y <= maxY; y++) {
                        cursor.set(origin.getX() + dx, y, origin.getZ() + dz);
                        BlockState state = world.getBlockState(cursor);
                        if (state.isAir()) {
                            continue;
                        }
                        Integer color = colors.get(state.getBlock());
                        if (color == null) {
                            continue;
                        }
                        int dy = y - origin.getY();
                        next.add(new Found(cursor.toImmutable(), color, dx * dx + dy * dy + dz * dz));
                        if (next.size() >= SCAN_CAP) {
                            break scan;
                        }
                    }
                }
            }
            next.sort(Comparator.comparingInt(Found::distSq));
        }
        found = next;
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        if (!RenderUtil.isReady()) {
            return;
        }
        int limit = Math.min(found.size(), maxBoxes.getInt());
        for (int i = 0; i < limit; i++) {
            Found f = found.get(i);
            BlockPos p = f.pos();
            if (!RenderUtil.projectBox(p.getX(), p.getY(), p.getZ(), p.getX() + 1.0, p.getY() + 1.0, p.getZ() + 1.0, rect)) {
                continue;
            }
            RenderUtil.outline(ctx, rect[0], rect[1], rect[2], rect[3], f.color());
        }
    }
}
