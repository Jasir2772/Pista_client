package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Two layers of savings.
 * 1) Vanilla video options (render/simulation distance, particles, graphics, clouds, shadows, biome blend, entity
 *    distance scaling) are lowered while the module is on and put back when it is switched off or the game closes.
 * 2) Small render mixins skip far entities, far particles and weather. An optional adaptive mode raises or lowers the
 *    render distance to chase a target FPS.
 * It cannot replace a rendering-engine mod (Sodium and friends), it only removes work vanilla would do anyway.
 */
public final class Optimization extends Module {
    private static final double OFF_DISTANCE = 192.0;

    private static Optimization instance;
    private static int culledEntities;
    private static int skippedParticles;

    private final ModeSetting preset = mode("Preset", "Aggressive", "Balanced", "Aggressive", "Extreme");
    private final NumberSetting renderDistance = number("RenderDistance", 6, 2, 16, 1);
    private final NumberSetting simulationDistance = number("SimDistance", 5, 5, 12, 1);
    private final NumberSetting entityDistance = number("EntityDistance", 64, 16, 192, 4);
    private final NumberSetting playerDistance = number("PlayerDistance", 96, 16, 192, 4);
    private final NumberSetting particleDistance = number("ParticleDistance", 24, 8, 96, 4);
    private final ModeSetting particles = mode("Particles", "Minimal", "All", "Decreased", "Minimal");
    private final BoolSetting fastGraphics = bool("FastGraphics", true);
    private final BoolSetting noClouds = bool("NoClouds", true);
    private final BoolSetting noEntityShadows = bool("NoEntityShadows", true);
    private final BoolSetting noBiomeBlend = bool("NoBiomeBlend", true);
    private final BoolSetting noWeather = bool("NoWeather", false);
    private final NumberSetting entityScale = number("EntityScale", 0.75, 0.5, 1.0, 0.05);
    private final BoolSetting adaptive = bool("Adaptive", false);
    private final NumberSetting targetFps = number("TargetFps", 60, 30, 144, 5);
    private final BoolSetting showStats = bool("ShowStats", false);

    private boolean saved;
    private int oldView;
    private int oldSim;
    private int oldBlend;
    private ParticlesMode oldParticles;
    private GraphicsMode oldGraphics;
    private CloudRenderMode oldClouds;
    private boolean oldShadows;
    private double oldScale;

    private int lastPresetIndex = -1;
    private int currentView;
    private long lastSecond;
    private long lastAdapt;
    private int frames;
    private int fps;
    private double emaFps;
    private int shownCulled;
    private int shownSkipped;

    public Optimization() {
        super("Optimization", Category.UTILS, "Lower video options and skip far rendering for more FPS");
        instance = this;
        targetFps.setVisibility(adaptive::get);
    }

    // ---- hooks used by the mixins ----------------------------------------------------------------------------

    /** True when this entity is beyond its cull distance and should not be rendered this frame. */
    public static boolean cullEntity(Entity entity, double camX, double camY, double camZ) {
        Optimization self = instance;
        if (self == null || !self.isEnabled()) {
            return false;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || entity == mc.player || entity == mc.getCameraEntity()
                || entity == mc.player.getVehicle() || entity == KillAura.target()) {
            return false;
        }
        double limit = entity instanceof PlayerEntity ? self.playerDistance.get() : self.entityDistance.get();
        if (limit >= OFF_DISTANCE) {
            return false;
        }
        double dx = entity.getX() - camX;
        double dy = entity.getY() - camY;
        double dz = entity.getZ() - camZ;
        if (dx * dx + dy * dy + dz * dz > limit * limit) {
            culledEntities++;
            return true;
        }
        return false;
    }

    /** True when a particle spawned at this position is too far away to be worth creating. */
    public static boolean cullParticle(double x, double y, double z) {
        Optimization self = instance;
        if (self == null || !self.isEnabled()) {
            return false;
        }
        Entity camera = MinecraftClient.getInstance().getCameraEntity();
        if (camera == null) {
            return false;
        }
        double limit = self.particleDistance.get();
        double dx = x - camera.getX();
        double dy = y - camera.getY();
        double dz = z - camera.getZ();
        if (dx * dx + dy * dy + dz * dz > limit * limit) {
            skippedParticles++;
            return true;
        }
        return false;
    }

    public static boolean noWeather() {
        return instance != null && instance.isEnabled() && instance.noWeather.get();
    }

    /** Called when the game is closing: put the vanilla options back before the game writes them to disk. */
    public static void restoreOnShutdown() {
        Optimization self = instance;
        GameOptions o = MinecraftClient.getInstance().options;
        if (self != null && self.saved && o != null) {
            self.restore(o);
            o.write();
        }
    }

    // ---- module lifecycle ------------------------------------------------------------------------------------

    @Override
    protected void onEnable() {
        GameOptions o = MinecraftClient.getInstance().options;
        if (o == null) {
            return;
        }
        oldView = o.getViewDistance().getValue();
        oldSim = o.getSimulationDistance().getValue();
        oldBlend = o.getBiomeBlendRadius().getValue();
        oldParticles = o.getParticles().getValue();
        oldGraphics = o.getGraphicsMode().getValue();
        oldClouds = o.getCloudRenderMode().getValue();
        oldShadows = o.getEntityShadows().getValue();
        oldScale = o.getEntityDistanceScaling().getValue();
        saved = true;
        currentView = renderDistance.getInt();
        lastAdapt = System.nanoTime();
        apply(o);
    }

    @Override
    protected void onDisable() {
        GameOptions o = MinecraftClient.getInstance().options;
        if (saved && o != null) {
            restore(o);
        }
        culledEntities = 0;
        skippedParticles = 0;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (!saved || mc.options == null) {
            return;
        }
        // The first tick only remembers the loaded preset so values saved in the config are not overwritten.
        if (lastPresetIndex < 0) {
            lastPresetIndex = preset.index();
        } else if (preset.index() != lastPresetIndex) {
            lastPresetIndex = preset.index();
            applyPreset();
            currentView = renderDistance.getInt();
        }
        if (mc.player != null && mc.player.age % 20 == 0) {
            apply(mc.options);
        }
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        frames++;
        if (now - lastSecond >= 1_000_000_000L) {
            fps = frames;
            frames = 0;
            lastSecond = now;
            emaFps = emaFps == 0.0 ? fps : emaFps * 0.6 + fps * 0.4;
            shownCulled = culledEntities;
            shownSkipped = skippedParticles;
            culledEntities = 0;
            skippedParticles = 0;
            if (adaptive.get() && saved) {
                adapt(now);
            }
        }
        if (showStats.get() && mc.textRenderer != null) {
            String text = "FPS " + fps + "  |  culled entities/s " + shownCulled + "  |  skipped particles/s " + shownSkipped
                    + (adaptive.get() ? "  |  view " + effectiveView() : "");
            ctx.drawTextWithShadow(mc.textRenderer, text, 4, ctx.getScaledWindowHeight() - 12, 0xFFAAAAAA);
        }
    }

    // ---- internals -------------------------------------------------------------------------------------------

    private void applyPreset() {
        switch (preset.get()) {
            case "Balanced" -> {
                renderDistance.set(8);
                simulationDistance.set(6);
                entityDistance.set(96);
                playerDistance.set(128);
                particleDistance.set(40);
                setParticles("Decreased");
                noWeather.set(false);
                entityScale.set(1.0);
                adaptive.set(false);
            }
            case "Extreme" -> {
                renderDistance.set(4);
                simulationDistance.set(5);
                entityDistance.set(40);
                playerDistance.set(64);
                particleDistance.set(12);
                setParticles("Minimal");
                noWeather.set(true);
                entityScale.set(0.5);
                adaptive.set(true);
                targetFps.set(60);
            }
            default -> {
                renderDistance.set(6);
                simulationDistance.set(5);
                entityDistance.set(64);
                playerDistance.set(96);
                particleDistance.set(24);
                setParticles("Minimal");
                noWeather.set(false);
                entityScale.set(0.75);
                adaptive.set(false);
            }
        }
    }

    private void setParticles(String mode) {
        while (!particles.is(mode)) {
            particles.next();
        }
    }

    private int effectiveView() {
        return adaptive.get() ? Math.min(currentView, renderDistance.getInt()) : renderDistance.getInt();
    }

    /** Lowers the render distance when the smoothed FPS is under target, raises it again (up to the cap) when well over. */
    private void adapt(long now) {
        if (now - lastAdapt < 10_000_000_000L || MinecraftClient.getInstance().world == null) {
            return;
        }
        int cap = renderDistance.getInt();
        currentView = Math.min(currentView, cap);
        if (emaFps < targetFps.get() * 0.85 && currentView > 3) {
            currentView--;
            lastAdapt = now;
        } else if (emaFps > targetFps.get() * 1.4 && currentView < cap) {
            currentView++;
            lastAdapt = now;
        }
    }

    private void apply(GameOptions o) {
        int view = effectiveView();
        if (o.getViewDistance().getValue() != view) {
            o.getViewDistance().setValue(view);
        }
        if (o.getSimulationDistance().getValue() != simulationDistance.getInt()) {
            o.getSimulationDistance().setValue(simulationDistance.getInt());
        }
        ParticlesMode wanted = particles.is("All") ? ParticlesMode.ALL
                : particles.is("Decreased") ? ParticlesMode.DECREASED : ParticlesMode.MINIMAL;
        o.getParticles().setValue(wanted);
        if (fastGraphics.get()) {
            o.getGraphicsMode().setValue(GraphicsMode.FAST);
        }
        if (noClouds.get()) {
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        }
        if (noEntityShadows.get()) {
            o.getEntityShadows().setValue(false);
        }
        if (noBiomeBlend.get()) {
            o.getBiomeBlendRadius().setValue(0);
        }
        o.getEntityDistanceScaling().setValue(entityScale.get());
    }

    private void restore(GameOptions o) {
        o.getViewDistance().setValue(oldView);
        o.getSimulationDistance().setValue(oldSim);
        o.getBiomeBlendRadius().setValue(oldBlend);
        o.getParticles().setValue(oldParticles);
        o.getGraphicsMode().setValue(oldGraphics);
        o.getCloudRenderMode().setValue(oldClouds);
        o.getEntityShadows().setValue(oldShadows);
        o.getEntityDistanceScaling().setValue(oldScale);
        saved = false;
    }
}
