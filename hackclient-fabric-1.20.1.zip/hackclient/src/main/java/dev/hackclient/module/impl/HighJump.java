package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class HighJump extends Module {
    // Vanilla jump velocity is 0.42.
    private final NumberSetting height = number("Height", 0.6, 0.42, 2.0, 0.01);
    private boolean wasOnGround;

    public HighJump() {
        super("HighJump", Category.MOVEMENT, "Jump higher than vanilla");
    }

    @Override
    protected void onEnable() {
        wasOnGround = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        Vec3d velocity = player.getVelocity();
        // End of tick: the vanilla jump already happened if we just left the ground going up.
        if (wasOnGround && !player.isOnGround() && velocity.y > 0.0 && !player.isTouchingWater()
                && !player.isInLava() && !player.isClimbing()) {
            player.setVelocity(velocity.x, height.get(), velocity.z);
        }
        wasOnGround = player.isOnGround();
    }
}
