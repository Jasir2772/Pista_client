package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Makes other entities slightly easier to hit by widening the box your crosshair ray tests against (vanilla's own
 * "targeting margin" hook). The margin is only applied while the entity is within OnlyWithin blocks, so it never
 * extends how far you can hit, only how forgiving the aim is. Nothing here is tuned against any particular
 * anti-cheat and larger values are easier to notice.
 */
public final class Hitbox extends Module {
    private static Hitbox instance;

    private final NumberSetting expand = number("Expand", 0.1, 0.0, 0.6, 0.02);
    private final NumberSetting onlyWithin = number("OnlyWithin", 3.4, 2.0, 6.0, 0.1);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Mobs", false);

    public Hitbox() {
        super("Hitbox", Category.COMBAT, "Slightly larger target boxes for your crosshair");
        instance = this;
    }

    /** Extra margin in blocks to add around this entity's box (0 when the module is off or does not apply). */
    public static float margin(Entity entity) {
        Hitbox self = instance;
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (self == null || !self.isEnabled() || player == null || entity == player || !(entity instanceof LivingEntity)) {
            return 0.0f;
        }
        if (entity instanceof PlayerEntity ? !self.players.get() : !self.mobs.get()) {
            return 0.0f;
        }
        if (player.distanceTo(entity) > self.onlyWithin.get()) {
            return 0.0f;
        }
        return (float) self.expand.get();
    }
}
