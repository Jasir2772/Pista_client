package dev.hackclient.module.impl;

import dev.hackclient.HackClient;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.Brand;
import dev.hackclient.util.Notifications;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.TargetHudRenderer;
import dev.hackclient.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Hud extends Module {
    private static final String[] COLOR_NAMES = {"Blue", "Purple", "Pink", "Green", "Orange", "Red"};
    private static final int[] COLORS = {0xFF6C9BFF, 0xFFA66CFF, 0xFFFF6CB4, 0xFF4CE0A0, 0xFFFFA24C, 0xFFFF5C5C};
    private static Hud instance;

    private final ModeSetting color = mode("Accent", "Purple", COLOR_NAMES);
    private final BoolSetting watermark = bool("Watermark", true);
    private final BoolSetting infoChips = bool("InfoChips", true);
    private final BoolSetting serverIp = bool("ServerIP", false);
    private final BoolSetting info = bool("Coords+Speed", true);
    private final BoolSetting moduleList = bool("ModuleList", true);
    private final NumberSetting listOffsetY = number("ListOffsetY", 4, 0, 160, 2);
    private final BoolSetting potions = bool("Potions", true);
    private final BoolSetting keybinds = bool("Keybinds", false);
    private final BoolSetting armorHud = bool("ArmorHud", true);
    private final BoolSetting totems = bool("Totems", true);
    private final BoolSetting targetHud = bool("TargetHUD", true);
    private final ModeSetting targetStyle = mode("TargetStyle", "Card", TargetHudRenderer.STYLES);
    private final NumberSetting targetX = number("TargetX", 24, -300, 300, 2);
    private final NumberSetting targetY = number("TargetY", 24, -300, 300, 2);
    private final BoolSetting notifications = bool("Notifications", true);

    private double speed;

    public Hud() {
        super("HUD", Category.RENDER, "Watermark, info chips, potions, armor, keybinds, module list, target card");
        instance = this;
        infoChips.setVisibility(watermark::get);
        serverIp.setVisibility(() -> watermark.get() && infoChips.get());
        targetStyle.setVisibility(targetHud::get);
        targetX.setVisibility(targetHud::get);
        targetY.setVisibility(targetHud::get);
    }

    /** Accent colour used by the HUD and the ClickGUI. Works even while the HUD module is off. */
    public static int accent() {
        Hud h = instance;
        return h == null ? COLORS[1] : COLORS[h.color.index()];
    }

    @Override
    public boolean showInList() {
        return false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            return;
        }
        double dx = p.getX() - p.prevX;
        double dz = p.getZ() - p.prevZ;
        speed += (Math.sqrt(dx * dx + dz * dz) * 20.0 - speed) * 0.2;
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.options.hudHidden || mc.options.debugEnabled) {
            return;
        }
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int accent = accent();
        int accent2 = Theme.accent2();

        int leftY = 4;
        if (watermark.get()) {
            drawWatermark(ctx, tr, mc, player, accent, accent2);
            leftY = 29;
        }
        if (potions.get()) {
            leftY = drawPotions(ctx, tr, player, leftY);
        }
        if (keybinds.get()) {
            drawKeybinds(ctx, tr, leftY, accent);
        }

        if (info.get()) {
            String coords = (int) Math.floor(player.getX()) + " " + (int) Math.floor(player.getY()) + " "
                    + (int) Math.floor(player.getZ());
            String bps = String.format(Locale.ROOT, "%.1f", speed);
            int w = 8 + tr.getWidth("XYZ") + 4 + tr.getWidth(coords) + 8 + tr.getWidth(bps) + 3 + tr.getWidth("b/s") + 8;
            int y2 = sh - 4;
            RenderUtil.roundRect(ctx, 3, y2 - 17, 5 + w, y2 + 1, 7, 0x30000000);
            RenderUtil.roundRect(ctx, 4, y2 - 16, 4 + w, y2, 6, Theme.HUD_BG);
            int cx = 12;
            ctx.drawTextWithShadow(tr, "XYZ", cx, y2 - 12, accent);
            cx += tr.getWidth("XYZ") + 4;
            ctx.drawTextWithShadow(tr, coords, cx, y2 - 12, Theme.TEXT);
            cx += tr.getWidth(coords) + 4;
            ctx.fill(cx, y2 - 12, cx + 1, y2 - 4, 0x33FFFFFF);
            cx += 5;
            ctx.drawTextWithShadow(tr, bps, cx, y2 - 12, Theme.TEXT);
            ctx.drawTextWithShadow(tr, "b/s", cx + tr.getWidth(bps) + 3, y2 - 12, Theme.TEXT_DIM);
        }

        if (moduleList.get()) {
            int right = sw - 4;
            int y = listOffsetY.getInt();
            List<Module> listed = HackClient.modules().listedByWidth(tr);
            int index = 0;
            for (Module m : listed) {
                int w = tr.getWidth(m.getName());
                float t = listed.size() <= 1 ? 0.0f : index / (float) (listed.size() - 1);
                int c = Theme.mix(accent, accent2, t);
                RenderUtil.roundRect(ctx, right - w - 11, y - 1, right + 1, y + 14, 5, 0x22000000);
                RenderUtil.roundRect(ctx, right - w - 10, y, right, y + 13, 4, Theme.HUD_BG);
                RenderUtil.roundRect(ctx, right - 3, y + 2, right - 1, y + 11, 1, c);
                ctx.drawTextWithShadow(tr, m.getName(), right - w - 6, y + 3, Theme.mix(c, 0xFFFFFFFF, 0.35f));
                y += 15;
                index++;
            }
        }

        if (armorHud.get() || totems.get()) {
            drawArmorRow(ctx, tr, player, sw, sh, accent);
        }

        if (targetHud.get()) {
            LivingEntity target = KillAura.target();
            if (target != null && target.isAlive()) {
                TargetHudRenderer.render(ctx, tr, target, sw / 2 + targetX.getInt(), sh / 2 + targetY.getInt(),
                        targetStyle.get(), accent);
            }
        }

        if (notifications.get()) {
            Notifications.render(ctx, tr, sw, sh);
        }
    }

    private void drawWatermark(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ClientPlayerEntity player,
                               int accent, int accent2) {
        List<String[]> chips = new ArrayList<>();
        if (infoChips.get()) {
            chips.add(new String[] {"", player.getEntityName()});
            chips.add(new String[] {"FPS", String.valueOf(mc.getCurrentFps())});
            PlayerListEntry entry = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
            if (entry != null) {
                chips.add(new String[] {"PING", entry.getLatency() + "ms"});
            }
            LocalTime now = LocalTime.now();
            chips.add(new String[] {"", String.format(Locale.ROOT, "%02d:%02d", now.getHour(), now.getMinute())});
            ServerInfo server = mc.getCurrentServerEntry();
            if (serverIp.get() && server != null) {
                chips.add(new String[] {"", server.address});
            }
        }

        String brand = "PISTA";
        int x = 4;
        int y = 4;
        int h = 20;
        int w = 6 + 14 + 5 + tr.getWidth(brand) + 6;
        for (String[] chip : chips) {
            w += 9 + (chip[0].isEmpty() ? 0 : tr.getWidth(chip[0]) + 3) + tr.getWidth(chip[1]);
        }
        w += 4;

        RenderUtil.roundRect(ctx, x - 1, y - 1, x + w + 1, y + h + 2, 8, 0x30000000);
        RenderUtil.roundRect(ctx, x, y, x + w, y + h, 7, Theme.HUD_BG);
        int segments = 20;
        for (int i = 0; i < segments; i++) {
            int sx1 = x + 7 + (w - 14) * i / segments;
            int sx2 = x + 7 + (w - 14) * (i + 1) / segments;
            ctx.fill(sx1, y + h - 1, sx2, y + h, Theme.withAlpha(Theme.mix(accent, accent2, i / (float) (segments - 1)), 0.9f));
        }
        Brand.logo(ctx, x + 4, y + 3, 14);
        Brand.gradientText(ctx, tr, brand, x + 23, y + 6, accent, accent2);
        int cx = x + 6 + 14 + 5 + tr.getWidth(brand) + 6;
        for (String[] chip : chips) {
            ctx.fill(cx, y + 5, cx + 1, y + h - 6, 0x33FFFFFF);
            cx += 6;
            if (!chip[0].isEmpty()) {
                ctx.drawTextWithShadow(tr, chip[0], cx, y + 6, accent);
                cx += tr.getWidth(chip[0]) + 3;
            }
            ctx.drawTextWithShadow(tr, chip[1], cx, y + 6, Theme.TEXT);
            cx += tr.getWidth(chip[1]) + 3;
        }
    }

    /** Active status effects as small pills; returns the next free y. */
    private int drawPotions(DrawContext ctx, TextRenderer tr, ClientPlayerEntity player, int startY) {
        int y = startY;
        for (StatusEffectInstance effect : player.getStatusEffects()) {
            String name = effect.getEffectType().getName().getString();
            if (effect.getAmplifier() > 0) {
                name += " " + (effect.getAmplifier() + 1);
            }
            String time;
            if (effect.getDuration() < 0) {
                time = "inf";
            } else {
                int seconds = effect.getDuration() / 20;
                time = (seconds / 60) + ":" + String.format(Locale.ROOT, "%02d", seconds % 60);
            }
            int w = 8 + 6 + 4 + tr.getWidth(name) + 6 + tr.getWidth(time) + 6;
            RenderUtil.roundRect(ctx, 4, y, 4 + w, y + 14, 5, Theme.HUD_BG);
            RenderUtil.roundRect(ctx, 8, y + 4, 14, y + 10, 3, 0xFF000000 | effect.getEffectType().getColor());
            ctx.drawTextWithShadow(tr, name, 18, y + 3, Theme.TEXT);
            ctx.drawTextWithShadow(tr, time, 4 + w - 6 - tr.getWidth(time), y + 3, Theme.TEXT_DIM);
            y += 16;
        }
        return y;
    }

    /** Modules that have a key bound, enabled ones highlighted. */
    private void drawKeybinds(DrawContext ctx, TextRenderer tr, int startY, int accent) {
        int y = startY;
        for (Module m : HackClient.modules().all()) {
            if (m.getKey() < 0) {
                continue;
            }
            String key = InputUtil.fromKeyCode(m.getKey(), -1).getLocalizedText().getString();
            int w = 8 + tr.getWidth(m.getName()) + 8 + tr.getWidth(key) + 8;
            RenderUtil.roundRect(ctx, 4, y, 4 + w, y + 14, 5, Theme.HUD_BG);
            ctx.drawTextWithShadow(tr, m.getName(), 12, y + 3, m.isEnabled() ? accent : Theme.TEXT_DIM);
            ctx.drawTextWithShadow(tr, key, 4 + w - 8 - tr.getWidth(key), y + 3, Theme.TEXT);
            y += 16;
        }
    }

    /** Armor icons with durability bars above the hotbar, plus a totem counter. */
    private void drawArmorRow(DrawContext ctx, TextRenderer tr, ClientPlayerEntity player, int sw, int sh, int accent) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int totemCount = 0;
        if (totems.get()) {
            for (int i = 0; i < player.getInventory().size(); i++) {
                ItemStack stack = player.getInventory().getStack(i);
                if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                    totemCount += stack.getCount();
                }
            }
        }
        int cells = (armorHud.get() ? 4 : 0) + (totems.get() && totemCount > 0 ? 1 : 0);
        if (cells == 0) {
            return;
        }
        int w = cells * 20 + 6;
        int x = sw / 2 - w / 2;
        int y = sh - 78;
        RenderUtil.roundRect(ctx, x, y, x + w, y + 24, 6, Theme.HUD_BG);
        int cx = x + 5;
        if (armorHud.get()) {
            for (EquipmentSlot slot : slots) {
                ItemStack stack = player.getEquippedStack(slot);
                if (!stack.isEmpty()) {
                    ctx.drawItem(stack, cx, y + 2);
                    if (stack.isItemBarVisible()) {
                        int step = stack.getItemBarStep();
                        ctx.fill(cx + 1, y + 19, cx + 14, y + 21, 0xFF000000);
                        ctx.fill(cx + 1, y + 19, cx + 1 + step, y + 20, 0xFF000000 | stack.getItemBarColor());
                    }
                }
                cx += 20;
            }
        }
        if (totems.get() && totemCount > 0) {
            ctx.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), cx, y + 2);
            String count = String.valueOf(totemCount);
            ctx.drawTextWithShadow(tr, count, cx + 16 - tr.getWidth(count), y + 12, 0xFFFFFFFF);
        }
    }
}
