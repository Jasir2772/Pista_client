package dev.hackclient.module.impl;

import dev.hackclient.HackClient;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.Brand;
import dev.hackclient.util.Icons;
import dev.hackclient.util.Notifications;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.TargetHudRenderer;
import dev.hackclient.util.Theme;
import dev.hackclient.util.TpsTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Hud extends Module {
    private static final String[] COLOR_NAMES = {"Blue", "Purple", "Pink", "Green", "Orange", "Red"};
    private static final int[] COLORS = {0xFF6C9BFF, 0xFFA66CFF, 0xFFFF6CB4, 0xFF4CE0A0, 0xFFFFA24C, 0xFFFF5C5C};
    private static Hud instance;

    private final ModeSetting color = mode("Accent", "Purple", COLOR_NAMES);
    private final BoolSetting watermark = bool("Watermark", true);
    private final BoolSetting infoRow = bool("InfoRow", true);
    private final BoolSetting serverIp = bool("ServerIP", false);
    private final BoolSetting moduleList = bool("ModuleList", true);
    private final NumberSetting listOffsetY = number("ListOffsetY", 4, 0, 160, 2);
    private final BoolSetting potions = bool("Potions", true);
    private final BoolSetting keybinds = bool("Keybinds", true);
    private final BoolSetting armorHud = bool("ArmorHud", true);
    private final BoolSetting totems = bool("Totems", true);
    private final BoolSetting targetHud = bool("TargetHUD", true);
    private final ModeSetting targetStyle = mode("TargetStyle", "Card", TargetHudRenderer.STYLES);
    private final NumberSetting targetX = number("TargetX", 24, -300, 300, 2);
    private final NumberSetting targetY = number("TargetY", 24, -300, 300, 2);
    private final BoolSetting notifications = bool("Notifications", true);

    private double speed;

    /** One cell of an info row: a pictogram and a text. */
    private record Cell(int icon, String text) {
    }

    public Hud() {
        super("HUD", Category.RENDER, "Info card, potions, hotkeys, armor, module list, target card");
        instance = this;
        infoRow.setVisibility(watermark::get);
        serverIp.setVisibility(watermark::get);
        targetStyle.setVisibility(targetHud::get);
        targetX.setVisibility(targetHud::get);
        targetY.setVisibility(targetHud::get);
    }

    /** Accent colour used by the HUD and the ClickGUI. Works even while the HUD module is off. */
    public static int accent() {
        Hud h = instance;
        return h == null ? COLORS[1] : COLORS[h.color.index()];
    }

    @Override
    public boolean showInList() {
        return false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            TpsTracker.reset();
            return;
        }
        double dx = p.getX() - p.prevX;
        double dz = p.getZ() - p.prevZ;
        speed += (Math.sqrt(dx * dx + dz * dz) * 20.0 - speed) * 0.2;
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.options.hudHidden || mc.options.debugEnabled) {
            return;
        }
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int accent = accent();
        int accent2 = Theme.accent2();

        int leftY = 4;
        if (watermark.get()) {
            leftY = drawInfoCard(ctx, tr, mc, player, accent, accent2);
        }
        if (potions.get()) {
            leftY = drawPotions(ctx, tr, player, leftY + 4, accent, accent2);
        }
        if (keybinds.get()) {
            drawKeybinds(ctx, tr, leftY + 4, accent, accent2);
        }

        if (moduleList.get()) {
            int right = sw - 4;
            int y = listOffsetY.getInt();
            List<Module> listed = HackClient.modules().listedByWidth(tr);
            int index = 0;
            for (Module m : listed) {
                int w = tr.getWidth(m.getName());
                float t = listed.size() <= 1 ? 0.0f : index / (float) (listed.size() - 1);
                int c = Theme.mix(accent, accent2, t);
                RenderUtil.roundRect(ctx, right - w - 11, y - 1, right + 1, y + 14, 5, 0x22000000);
                RenderUtil.roundRect(ctx, right - w - 10, y, right, y + 13, 4, Theme.HUD_BG);
                RenderUtil.roundRect(ctx, right - 3, y + 2, right - 1, y + 11, 1, c);
                ctx.drawTextWithShadow(tr, m.getName(), right - w - 6, y + 3, Theme.mix(c, 0xFFFFFFFF, 0.35f));
                y += 15;
                index++;
            }
        }

        if (armorHud.get() || totems.get()) {
            drawArmorRow(ctx, tr, player, sw, sh);
        }

        if (targetHud.get()) {
            LivingEntity target = KillAura.target();
            if (target != null && target.isAlive()) {
                TargetHudRenderer.render(ctx, tr, target, sw / 2 + targetX.getInt(), sh / 2 + targetY.getInt(),
                        targetStyle.get(), accent);
            }
        }

        if (notifications.get()) {
            Notifications.render(ctx, tr, sw, sh);
        }
    }

    // ---- info card ------------------------------------------------------------------------------------------

    private static int rowWidth(TextRenderer tr, List<Cell> cells) {
        int w = 0;
        for (Cell c : cells) {
            w += 10 + 4 + tr.getWidth(c.text()) + 9;
        }
        return w;
    }

    private static void drawCells(DrawContext ctx, TextRenderer tr, int x, int y, List<Cell> cells, int accent) {
        int cx = x;
        for (int i = 0; i < cells.size(); i++) {
            Cell c = cells.get(i);
            switch (c.icon()) {
                case 0 -> Icons.user(ctx, cx, y, accent);
                case 1 -> Icons.monitor(ctx, cx, y, accent);
                case 2 -> Icons.clock(ctx, cx, y, accent);
                case 3 -> Icons.pin(ctx, cx, y, accent);
                case 4 -> Icons.ping(ctx, cx, y, accent);
                case 5 -> Icons.gauge(ctx, cx, y, accent);
                default -> Icons.speed(ctx, cx, y, accent);
            }
            ctx.drawTextWithShadow(tr, c.text(), cx + 14, y + 1, Theme.TEXT);
            cx += 14 + tr.getWidth(c.text()) + 5;
            if (i < cells.size() - 1) {
                ctx.fill(cx, y + 1, cx + 1, y + 10, 0x33FFFFFF);
            }
            cx += 4;
        }
    }

    /** Two-row card: brand + name/fps/time on top, coords/ping/ticks/speed below. Returns the next free y. */
    private int drawInfoCard(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ClientPlayerEntity player,
                             int accent, int accent2) {
        LocalTime now = LocalTime.now();
        List<Cell> top = new ArrayList<>();
        top.add(new Cell(0, player.getEntityName()));
        top.add(new Cell(1, mc.getCurrentFps() + " Fps"));
        top.add(new Cell(2, String.format(Locale.ROOT, "%02d:%02d:%02d", now.getHour(), now.getMinute(), now.getSecond())));
        ServerInfo server = mc.getCurrentServerEntry();
        if (serverIp.get() && server != null) {
            top.add(new Cell(3, server.address));
        }

        List<Cell> bottom = new ArrayList<>();
        if (infoRow.get()) {
            bottom.add(new Cell(3, (int) Math.floor(player.getX()) + " " + (int) Math.floor(player.getY()) + " "
                    + (int) Math.floor(player.getZ())));
            PlayerListEntry entry = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
            if (entry != null) {
                bottom.add(new Cell(4, entry.getLatency() + " Ping"));
            }
            bottom.add(new Cell(5, String.format(Locale.ROOT, "%.1f Ticks", TpsTracker.tps())));
            bottom.add(new Cell(6, String.format(Locale.ROOT, "%.1f Bps", speed)));
        }

        String brand = "PISTA CLIENT";
        int brandW = 12 + 4 + tr.getWidth(brand) + 8;
        int topW = brandW + rowWidth(tr, top);
        int bottomW = rowWidth(tr, bottom);
        int w = Math.max(topW, bottomW) + 8;
        int h = bottom.isEmpty() ? 18 : 31;
        int x = 4;
        int y = 4;

        RenderUtil.roundRect(ctx, x - 1, y - 1, x + w + 1, y + h + 2, 8, 0x30000000);
        RenderUtil.roundRect(ctx, x, y, x + w, y + h, 7, Theme.HUD_BG);
        int segments = 20;
        for (int i = 0; i < segments; i++) {
            int sx1 = x + 7 + (w - 14) * i / segments;
            int sx2 = x + 7 + (w - 14) * (i + 1) / segments;
            ctx.fill(sx1, y + h - 1, sx2, y + h, Theme.withAlpha(Theme.mix(accent, accent2, i / (float) (segments - 1)), 0.9f));
        }
        Brand.logo(ctx, x + 5, y + 3, 12);
        Brand.gradientText(ctx, tr, brand, x + 21, y + 5, accent, accent2);
        ctx.fill(x + 4 + brandW - 4, y + 4, x + 4 + brandW - 3, y + 14, 0x33FFFFFF);
        drawCells(ctx, tr, x + 4 + brandW, y + 4, top, accent);
        if (!bottom.isEmpty()) {
            ctx.fill(x + 6, y + 17, x + w - 6, y + 18, 0x1AFFFFFF);
            drawCells(ctx, tr, x + 7, y + 20, bottom, accent);
        }
        return y + h + 2;
    }

    // ---- left panels ------------------------------------------------------------------------------------------

    /** "Active Potions" panel: coloured dot, name with level, remaining time. Returns the next free y. */
    private int drawPotions(DrawContext ctx, TextRenderer tr, ClientPlayerEntity player, int startY, int accent, int accent2) {
        List<StatusEffectInstance> effects = new ArrayList<>(player.getStatusEffects());
        if (effects.isEmpty()) {
            return startY - 4;
        }
        int w = 116;
        int h = 17 + effects.size() * 11 + 3;
        RenderUtil.roundRect(ctx, 3, startY - 1, 5 + w, startY + h + 1, 7, 0x30000000);
        RenderUtil.roundRect(ctx, 4, startY, 4 + w, startY + h, 6, Theme.HUD_BG);
        Icons.potion(ctx, 9, startY + 3, accent);
        Brand.gradientText(ctx, tr, "Active Potions", 23, startY + 4, accent, accent2);
        ctx.fill(8, startY + 15, 4 + w - 4, startY + 16, 0x22FFFFFF);
        int y = startY + 19;
        for (StatusEffectInstance effect : effects) {
            String name = effect.getEffectType().getName().getString();
            if (name.length() > 13) {
                name = name.substring(0, 13);
            }
            if (effect.getAmplifier() > 0) {
                name += " " + (effect.getAmplifier() + 1);
            }
            String time;
            if (effect.getDuration() < 0) {
                time = "inf";
            } else {
                int seconds = effect.getDuration() / 20;
                time = (seconds / 60) + ":" + String.format(Locale.ROOT, "%02d", seconds % 60);
            }
            RenderUtil.roundRect(ctx, 9, y + 2, 13, y + 6, 2, 0xFF000000 | effect.getEffectType().getColor());
            ctx.drawTextWithShadow(tr, name, 17, y, Theme.TEXT);
            ctx.drawTextWithShadow(tr, time, 4 + w - 8 - tr.getWidth(time), y, Theme.TEXT_DIM);
            y += 11;
        }
        return startY + h + 1;
    }

    /** "Hotkeys" panel: modules that have a key bound, enabled ones highlighted. */
    private void drawKeybinds(DrawContext ctx, TextRenderer tr, int startY, int accent, int accent2) {
        List<Module> bound = new ArrayList<>();
        for (Module m : HackClient.modules().all()) {
            if (m.getKey() >= 0) {
                bound.add(m);
            }
        }
        if (bound.isEmpty()) {
            return;
        }
        int w = 116;
        int h = 17 + bound.size() * 11 + 3;
        RenderUtil.roundRect(ctx, 3, startY - 1, 5 + w, startY + h + 1, 7, 0x30000000);
        RenderUtil.roundRect(ctx, 4, startY, 4 + w, startY + h, 6, Theme.HUD_BG);
        Brand.gradientText(ctx, tr, "Hotkeys", 9, startY + 4, accent, accent2);
        ctx.fill(8, startY + 15, 4 + w - 4, startY + 16, 0x22FFFFFF);
        int y = startY + 19;
        for (Module m : bound) {
            String key = InputUtil.fromKeyCode(m.getKey(), -1).getLocalizedText().getString();
            ctx.drawTextWithShadow(tr, m.getName(), 9, y, m.isEnabled() ? accent : Theme.TEXT_DIM);
            ctx.drawTextWithShadow(tr, key, 4 + w - 8 - tr.getWidth(key), y, Theme.TEXT);
            y += 11;
        }
    }

    /** Armor icons with durability bars above the hotbar, plus a totem counter. */
    private void drawArmorRow(DrawContext ctx, TextRenderer tr, ClientPlayerEntity player, int sw, int sh) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int totemCount = 0;
        if (totems.get()) {
            for (int i = 0; i < player.getInventory().size(); i++) {
                ItemStack stack = player.getInventory().getStack(i);
                if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                    totemCount += stack.getCount();
                }
            }
        }
        int cells = (armorHud.get() ? 4 : 0) + (totems.get() && totemCount > 0 ? 1 : 0);
        if (cells == 0) {
            return;
        }
        int w = cells * 20 + 6;
        int x = sw / 2 - w / 2;
        int y = sh - 78;
        RenderUtil.roundRect(ctx, x, y, x + w, y + 24, 6, Theme.HUD_BG);
        int cx = x + 5;
        if (armorHud.get()) {
            for (EquipmentSlot slot : slots) {
                ItemStack stack = player.getEquippedStack(slot);
                if (!stack.isEmpty()) {
                    ctx.drawItem(stack, cx, y + 2);
                    if (stack.isItemBarVisible()) {
                        int step = stack.getItemBarStep();
                        ctx.fill(cx + 1, y + 19, cx + 14, y + 21, 0xFF000000);
                        ctx.fill(cx + 1, y + 19, cx + 1 + step, y + 20, 0xFF000000 | stack.getItemBarColor());
                    }
                }
                cx += 20;
            }
        }
        if (totems.get() && totemCount > 0) {
            ctx.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), cx, y + 2);
            String count = String.valueOf(totemCount);
            ctx.drawTextWithShadow(tr, count, cx + 16 - tr.getWidth(count), y + 12, 0xFFFFFFFF);
        }
    }
}
