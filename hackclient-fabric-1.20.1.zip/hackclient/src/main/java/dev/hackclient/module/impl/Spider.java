package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Climb walls: while pushing into a wall in the air, the vertical speed is held at a small upward value. */
public final class Spider extends Module {
    private final NumberSetting speed = number("Speed", 0.2, 0.1, 0.5, 0.05);

    public Spider() {
        super("Spider", Category.MOVEMENT, "Climb walls while moving into them");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || !player.horizontalCollision || player.isOnGround() || player.isTouchingWater()
                || !mc.options.forwardKey.isPressed()) {
            return;
        }
        Vec3d v = player.getVelocity();
        player.setVelocity(v.x, speed.get(), v.z);
    }
}
