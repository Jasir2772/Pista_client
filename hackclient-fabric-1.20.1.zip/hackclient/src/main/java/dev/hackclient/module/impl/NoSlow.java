package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;

public final class NoSlow extends Module {
    private static NoSlow instance;

    private final BoolSetting items = bool("Items", true);

    public NoSlow() {
        super("NoSlow", Category.MOVEMENT, "No slowdown while using items");
        instance = this;
    }

    public static boolean items() {
        return instance != null && instance.isEnabled() && instance.items.get();
    }
}
