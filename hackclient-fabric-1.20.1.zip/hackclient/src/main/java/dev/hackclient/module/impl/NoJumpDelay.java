package dev.hackclient.module.impl;

import dev.hackclient.mixin.LivingEntityAccessor;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import net.minecraft.client.MinecraftClient;

public final class NoJumpDelay extends Module {
    public NoJumpDelay() {
        super("NoJumpDelay", Category.MOVEMENT, "Jump again the moment you land");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player != null) {
            ((LivingEntityAccessor) mc.player).setJumpingCooldown(0);
        }
    }
}
