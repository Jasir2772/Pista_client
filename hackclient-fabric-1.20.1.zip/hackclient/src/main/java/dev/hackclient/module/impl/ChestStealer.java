package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

import java.util.BitSet;
import java.util.concurrent.ThreadLocalRandom;

/** Shift-clicks items out of an open chest or barrel with a randomised delay. Each slot is tried once, so a full inventory cannot loop. */
public final class ChestStealer extends Module {
    private final NumberSetting minDelay = number("MinDelay", 2, 0, 10, 1);
    private final NumberSetting maxDelay = number("MaxDelay", 5, 1, 20, 1);
    private final BitSet tried = new BitSet();
    private int wait;
    private int lastSyncId = -1;

    public ChestStealer() {
        super("ChestStealer", Category.PLAYER, "Takes everything from an open chest");
    }

    @Override
    protected void onDisable() {
        tried.clear();
        lastSyncId = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.interactionManager == null
                || !(mc.currentScreen instanceof GenericContainerScreen)
                || !(player.currentScreenHandler instanceof GenericContainerScreenHandler handler)) {
            tried.clear();
            lastSyncId = -1;
            return;
        }
        if (handler.syncId != lastSyncId) {
            tried.clear();
            lastSyncId = handler.syncId;
            wait = randomDelay();
        }
        if (wait > 0) {
            wait--;
            return;
        }
        int size = handler.getRows() * 9;
        for (int i = 0; i < size; i++) {
            if (tried.get(i)) {
                continue;
            }
            tried.set(i);
            if (handler.getSlot(i).getStack().isEmpty()) {
                continue;
            }
            mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.QUICK_MOVE, player);
            wait = randomDelay();
            return;
        }
    }

    private int randomDelay() {
        int lo = minDelay.getInt();
        int hi = Math.max(lo, maxDelay.getInt());
        return lo + ThreadLocalRandom.current().nextInt(hi - lo + 1);
    }
}
