package dev.hackclient.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    PLAYER("Player"),
    UTILS("Utils");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
