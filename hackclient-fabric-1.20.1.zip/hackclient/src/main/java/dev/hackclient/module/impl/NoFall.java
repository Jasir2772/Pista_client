package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Zeroes the client-side fall distance so the client never shows fall damage or the landing animation.
 * Purely client-side: a server that computes fall damage itself from position deltas still applies it.
 */
public final class NoFall extends Module {
    public NoFall() {
        super("NoFall", Category.MOVEMENT, "No client-side fall damage");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player != null && mc.player.fallDistance > 0.0f) {
            mc.player.fallDistance = 0.0f;
        }
    }
}
