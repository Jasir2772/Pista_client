package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Draws where a thrown item or a drawn bow will land. Physics follow the vanilla projectile code
 * (velocity * 0.99, then minus gravity, every tick); only blocks stop the path, entities and water are ignored.
 */
public final class Predictions extends Module {
    private record Shot(double speed, double gravity, float pitchOffset) {
    }

    private final BoolSetting throwables = bool("Throwables", true);
    private final BoolSetting bow = bool("Bow", true);
    private final NumberSetting maxTicks = number("MaxTicks", 120, 20, 200, 10);

    private final List<Vec3d> path = new ArrayList<>();
    private final float[] prev = new float[2];
    private final float[] cur = new float[2];

    public Predictions() {
        super("Predictions", Category.RENDER, "Landing path of pearls, potions and arrows");
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (player == null || world == null || mc.currentScreen != null || !RenderUtil.isReady()) {
            return;
        }
        Shot shot = shotFor(player);
        if (shot == null) {
            return;
        }

        double rad = Math.PI / 180.0;
        double yaw = player.getYaw() * rad;
        double pitch = player.getPitch() * rad;
        double dx = -Math.sin(yaw) * Math.cos(pitch);
        double dy = -Math.sin(pitch + shot.pitchOffset() * rad);
        double dz = Math.cos(yaw) * Math.cos(pitch);
        Vec3d velocity = new Vec3d(dx, dy, dz).normalize().multiply(shot.speed());
        Vec3d own = player.getVelocity();
        velocity = velocity.add(own.x, player.isOnGround() ? 0.0 : own.y, own.z);

        Vec3d pos = new Vec3d(player.getX(), player.getEyeY() - 0.1, player.getZ());
        path.clear();
        path.add(pos);
        boolean landed = false;
        for (int i = 0; i < maxTicks.getInt(); i++) {
            Vec3d next = pos.add(velocity);
            BlockHitResult hit = world.raycast(new RaycastContext(pos, next,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
            if (hit.getType() != HitResult.Type.MISS) {
                path.add(hit.getPos());
                landed = true;
                break;
            }
            pos = next;
            path.add(pos);
            velocity = velocity.multiply(0.99).add(0.0, -shot.gravity(), 0.0);
            if (pos.y < world.getBottomY() - 16) {
                break;
            }
        }

        int color = Theme.accent();
        boolean havePrev = false;
        for (int i = 0; i < path.size(); i++) {
            Vec3d p = path.get(i);
            boolean ok = RenderUtil.project(p.x, p.y, p.z, cur);
            if (ok && havePrev) {
                RenderUtil.line(ctx, prev[0], prev[1], cur[0], cur[1], color, 2);
            }
            if (ok && landed && i == path.size() - 1) {
                RenderUtil.outline(ctx, cur[0] - 3.0f, cur[1] - 3.0f, cur[0] + 3.0f, cur[1] + 3.0f, 0xFFFFFFFF);
            }
            havePrev = ok;
            prev[0] = cur[0];
            prev[1] = cur[1];
        }
    }

    private Shot shotFor(ClientPlayerEntity player) {
        if (bow.get() && player.isUsingItem() && player.getActiveItem().getItem() instanceof BowItem) {
            float power = BowItem.getPullProgress(player.getItemUseTime());
            return power < 0.1f ? null : new Shot(power * 3.0, 0.05, 0.0f);
        }
        if (!throwables.get()) {
            return null;
        }
        Shot main = shotForStack(player.getMainHandStack());
        return main != null ? main : shotForStack(player.getOffHandStack());
    }

    private static Shot shotForStack(ItemStack stack) {
        if (stack.isOf(Items.ENDER_PEARL) || stack.isOf(Items.SNOWBALL) || stack.isOf(Items.EGG)) {
            return new Shot(1.5, 0.03, 0.0f);
        }
        if (stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION)) {
            return new Shot(0.5, 0.05, -20.0f);
        }
        if (stack.isOf(Items.EXPERIENCE_BOTTLE)) {
            return new Shot(0.7, 0.07, -20.0f);
        }
        return null;
    }
}
