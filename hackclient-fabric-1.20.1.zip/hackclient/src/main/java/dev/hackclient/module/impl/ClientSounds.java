package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

/** Plays a short click when any module is switched on or off (higher pitch for on). */
public final class ClientSounds extends Module {
    private static ClientSounds instance;

    private final NumberSetting pitch = number("Pitch", 1.0, 0.5, 1.5, 0.1);

    public ClientSounds() {
        super("ClientSounds", Category.UTILS, "Click sound when modules toggle");
        instance = this;
    }

    @Override
    public boolean showInList() {
        return false;
    }

    /** Called from Module.setEnabled. */
    public static void onToggle(boolean on) {
        ClientSounds self = instance;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (self == null || !self.isEnabled() || mc.player == null) {
            return;
        }
        float base = self.pitch.getFloat();
        mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, on ? base * 1.25f : base * 0.8f));
    }
}
