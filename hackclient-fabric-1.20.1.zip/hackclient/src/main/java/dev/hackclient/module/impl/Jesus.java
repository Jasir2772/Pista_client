package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Rises to the water surface and stays there instead of sinking. Hold sneak to dive. */
public final class Jesus extends Module {
    private final NumberSetting lift = number("Lift", 0.11, 0.05, 0.3, 0.01);

    public Jesus() {
        super("Jesus", Category.MOVEMENT, "Stay on top of water");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || !player.isTouchingWater() || player.isSneaking() || player.hasVehicle()) {
            return;
        }
        Vec3d v = player.getVelocity();
        player.setVelocity(v.x, Math.max(v.y, lift.get()), v.z);
    }
}
