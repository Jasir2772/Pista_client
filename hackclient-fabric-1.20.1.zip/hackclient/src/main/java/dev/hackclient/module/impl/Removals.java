package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;

/** Switches off screen effects (hurt tilt, fire and water overlays). The work is done in small mixins. */
public final class Removals extends Module {
    private static Removals instance;

    private final BoolSetting noHurtCam = bool("NoHurtCam", true);
    private final BoolSetting noFire = bool("NoFireOverlay", true);
    private final BoolSetting noWater = bool("NoWaterOverlay", false);

    public Removals() {
        super("Removals", Category.RENDER, "Removes hurt tilt and screen overlays");
        instance = this;
    }

    public static boolean hurtCam() {
        return instance != null && instance.isEnabled() && instance.noHurtCam.get();
    }

    public static boolean fire() {
        return instance != null && instance.isEnabled() && instance.noFire.get();
    }

    public static boolean water() {
        return instance != null && instance.isEnabled() && instance.noWater.get();
    }
}
