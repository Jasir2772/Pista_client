package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.player.PlayerEntity;

import java.util.regex.Pattern;

/** Heuristics only: servers differ in how they implement NPCs, so each check can be switched off. */
public final class AntiBot extends Module {
    private static final Pattern VALID_NAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
    private static AntiBot instance;

    private final BoolSetting tabList = bool("TabListCheck", true);
    private final BoolSetting npcUuid = bool("NpcUuid", true);
    private final BoolSetting validName = bool("ValidName", false);

    public AntiBot() {
        super("AntiBot", Category.COMBAT, "Ignores NPC and fake players");
        instance = this;
    }

    public static boolean isBot(PlayerEntity player) {
        AntiBot self = instance;
        if (self == null || !self.isEnabled()) {
            return false;
        }
        ClientPlayNetworkHandler handler = MinecraftClient.getInstance().getNetworkHandler();
        if (self.tabList.get() && handler != null && handler.getPlayerListEntry(player.getUuid()) == null) {
            return true;
        }
        if (self.npcUuid.get() && player.getUuid().version() == 2) {
            return true;
        }
        return self.validName.get() && !VALID_NAME.matcher(player.getEntityName()).matches();
    }
}
