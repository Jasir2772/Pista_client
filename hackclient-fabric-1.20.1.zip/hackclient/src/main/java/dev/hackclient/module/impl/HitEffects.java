package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

import java.util.concurrent.ThreadLocalRandom;

/** Client-side particles that burst out of whatever you hit. Purely visual: nothing is sent to the server. */
public final class HitEffects extends Module {
    private static HitEffects instance;

    private final ModeSetting type = mode("Type", "Crit", "Crit", "Heart", "Flame", "Totem", "Enchant", "EndRod");
    private final NumberSetting amount = number("Amount", 8, 1, 24, 1);

    public HitEffects() {
        super("HitEffects", Category.RENDER, "Particle burst when you hit something");
        instance = this;
    }

    public static boolean active() {
        return instance != null && instance.isEnabled();
    }

    /** Called from the attackEntity mixin. */
    public static void onAttack(Entity target) {
        HitEffects self = instance;
        ClientWorld world = MinecraftClient.getInstance().world;
        if (self == null || !self.isEnabled() || world == null || !(target instanceof LivingEntity)) {
            return;
        }
        ParticleEffect particle;
        if (self.type.is("Heart")) {
            particle = ParticleTypes.HEART;
        } else if (self.type.is("Flame")) {
            particle = ParticleTypes.FLAME;
        } else if (self.type.is("Totem")) {
            particle = ParticleTypes.TOTEM_OF_UNDYING;
        } else if (self.type.is("Enchant")) {
            particle = ParticleTypes.ENCHANTED_HIT;
        } else if (self.type.is("EndRod")) {
            particle = ParticleTypes.END_ROD;
        } else {
            particle = ParticleTypes.CRIT;
        }
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        double halfWidth = target.getWidth() * 0.5;
        for (int i = 0; i < self.amount.getInt(); i++) {
            double x = target.getX() + rng.nextDouble(-halfWidth, halfWidth);
            double y = target.getY() + rng.nextDouble(0.1, Math.max(0.2, target.getHeight()));
            double z = target.getZ() + rng.nextDouble(-halfWidth, halfWidth);
            // "Important" particles are not thinned out by the Minimal particle setting.
            world.addImportantParticle(particle, x, y, z, rng.nextDouble(-0.2, 0.2), rng.nextDouble(0.0, 0.25), rng.nextDouble(-0.2, 0.2));
        }
    }
}
