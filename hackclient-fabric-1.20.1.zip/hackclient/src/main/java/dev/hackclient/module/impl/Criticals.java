package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Sends two small "hop" position packets right before each attack while you stand on the ground. */
public final class Criticals extends Module {
    private static Criticals instance;

    private final NumberSetting height = number("Height", 0.0625, 0.01, 0.2, 0.005);

    public Criticals() {
        super("Criticals", Category.COMBAT, "Fake hop packets before each hit");
        instance = this;
    }

    public static boolean active() {
        return instance != null && instance.isEnabled();
    }

    /** Called from the attackEntity mixin before the attack packet is built. */
    public static void beforeAttack(PlayerEntity attacker, Entity target) {
        Criticals self = instance;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientPlayNetworkHandler network = mc.getNetworkHandler();
        if (self == null || player == null || network == null || attacker != player || !(target instanceof LivingEntity)) {
            return;
        }
        if (!player.isOnGround() || player.isTouchingWater() || player.isInLava() || player.hasVehicle()
                || player.isClimbing() || player.hasStatusEffect(StatusEffects.BLINDNESS)) {
            return;
        }
        double x = player.getX();
        double y = player.getY();
        double z = player.getZ();
        network.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + self.height.get(), z, false));
        network.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false));
    }
}
