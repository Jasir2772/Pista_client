package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;

/** Cancels attacks on friends (.friend add <name>). The check itself lives in the attack event registered in HackClient. */
public final class NoFriendDamage extends Module {
    public NoFriendDamage() {
        super("NoFriendDamage", Category.COMBAT, "Blocks attacks on friends");
    }
}
