package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;

public final class NoWeb extends Module {
    private static NoWeb instance;

    private final BoolSetting berries = bool("Berries", false);

    public NoWeb() {
        super("NoWeb", Category.MOVEMENT, "Cobwebs do not slow you down");
        instance = this;
    }

    public static boolean ignores(BlockState state) {
        NoWeb self = instance;
        if (self == null || !self.isEnabled()) {
            return false;
        }
        return state.isOf(Blocks.COBWEB) || (self.berries.get() && state.isOf(Blocks.SWEET_BERRY_BUSH));
    }
}
