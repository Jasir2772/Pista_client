package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** While you hold the attack key on a block, selects the hotbar slot that mines it fastest. */
public final class AutoTool extends Module {
    public AutoTool() {
        super("AutoTool", Category.PLAYER, "Picks the fastest tool for the block");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.currentScreen != null || !mc.options.attackKey.isPressed()) {
            return;
        }
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            return;
        }
        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        if (state.isAir() || state.getHardness(mc.world, hit.getBlockPos()) < 0.0f) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        int best = inventory.selectedSlot;
        float bestSpeed = inventory.main.get(best).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            float speed = inventory.main.get(i).getMiningSpeedMultiplier(state);
            if (speed > bestSpeed + 0.01f) {
                best = i;
                bestSpeed = speed;
            }
        }
        if (best != inventory.selectedSlot) {
            inventory.selectedSlot = best;
        }
    }
}
