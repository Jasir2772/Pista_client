package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

import java.util.ArrayList;
import java.util.List;

/** Holds movement packets back and releases them in order. Other packets (keep-alive, chat, ...) are untouched. */
public final class Blink extends Module {
    private static Blink instance;

    private final NumberSetting maxTicks = number("MaxTicks", 40, 5, 200, 1);
    private final BoolSetting pulse = bool("Pulse", true);

    private final List<Packet<?>> queue = new ArrayList<>();
    private boolean flushing;
    private int ticks;

    public Blink() {
        super("Blink", Category.MOVEMENT, "Holds movement packets, then sends them at once");
        instance = this;
    }

    public static boolean active() {
        return instance != null && instance.isEnabled();
    }

    /** Called from the ClientConnection.send mixin. True means the packet was queued and must not be sent now. */
    public static boolean capture(Packet<?> packet) {
        Blink self = instance;
        if (self == null || !self.isEnabled() || self.flushing || !(packet instanceof PlayerMoveC2SPacket)) {
            return false;
        }
        if (!MinecraftClient.getInstance().isOnThread()) {
            return false;
        }
        self.queue.add(packet);
        return true;
    }

    @Override
    protected void onEnable() {
        queue.clear();
        ticks = 0;
    }

    @Override
    protected void onDisable() {
        flush();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.getNetworkHandler() == null) {
            queue.clear();
            setEnabled(false);
            return;
        }
        if (++ticks >= maxTicks.getInt()) {
            flush();
            ticks = 0;
            if (!pulse.get()) {
                setEnabled(false);
            }
        }
    }

    private void flush() {
        ClientPlayNetworkHandler network = MinecraftClient.getInstance().getNetworkHandler();
        if (network == null) {
            queue.clear();
            return;
        }
        flushing = true;
        try {
            for (Packet<?> packet : new ArrayList<>(queue)) {
                network.sendPacket(packet);
            }
        } finally {
            flushing = false;
            queue.clear();
        }
    }
}
