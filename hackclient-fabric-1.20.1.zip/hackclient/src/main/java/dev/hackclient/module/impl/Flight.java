package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.util.math.Vec3d;

/** Vanilla: turns on the creative-style flying ability client side. Glide: caps the fall speed. Servers may reject both. */
public final class Flight extends Module {
    private final ModeSetting mode = mode("Mode", "Vanilla", "Vanilla", "Glide");
    private final NumberSetting speed = number("Speed", 1.0, 0.1, 5.0, 0.1);
    private final NumberSetting glideFall = number("GlideFall", 0.05, 0.005, 0.2, 0.005);

    public Flight() {
        super("Flight", Category.MOVEMENT, "Client-side flight, servers may reject it");
        speed.setVisibility(() -> mode.is("Vanilla"));
        glideFall.setVisibility(() -> mode.is("Glide"));
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player != null) {
            restore(player);
        }
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        if (mode.is("Vanilla")) {
            PlayerAbilities abilities = player.getAbilities();
            abilities.allowFlying = true;
            abilities.flying = true;
            abilities.setFlySpeed((float) (speed.get() * 0.05));
        } else {
            restore(player);
            Vec3d velocity = player.getVelocity();
            double limit = -glideFall.get();
            if (!player.isOnGround() && velocity.y < limit) {
                player.setVelocity(velocity.x, limit, velocity.z);
            }
        }
    }

    private static void restore(ClientPlayerEntity player) {
        PlayerAbilities abilities = player.getAbilities();
        abilities.setFlySpeed(0.05f);
        if (!player.isCreative() && !player.isSpectator()) {
            abilities.allowFlying = false;
            abilities.flying = false;
        }
    }
}
