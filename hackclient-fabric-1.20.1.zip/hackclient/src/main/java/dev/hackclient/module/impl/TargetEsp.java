package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Effects around whatever KillAura is locked onto: Ring (rising rings), Ghosts (orbiting glowing orbs with trails),
 * Crystals (orbiting diamonds), Cubes (orbiting squares) or the plain Box with a health bar.
 * Everything is drawn with the same screen-space projection as ESP, so it works with ESP switched off.
 */
public final class TargetEsp extends Module {
    private static final int RING_SEGMENTS = 36;

    private final ModeSetting mode = mode("Mode", "Ring", "Ring", "Ghosts", "Crystals", "Cubes", "Mark", "Box");
    private final NumberSetting speed = number("Speed", 1.0, 0.3, 3.0, 0.1);
    private final NumberSetting size = number("Size", 1.0, 0.5, 2.0, 0.1);
    private final BoolSetting rainbow = bool("Rainbow", false);
    private final BoolSetting redOnHit = bool("RedOnHit", true);
    private final BoolSetting throughWalls = bool("ThroughWalls", true);
    private final BoolSetting name = bool("Name", true);
    private final BoolSetting health = bool("Health", true);

    private final float[] rect = new float[4];
    private final float[] prev = new float[2];
    private final float[] cur = new float[2];
    private double time;

    public TargetEsp() {
        super("TargetESP", Category.RENDER, "Effect around the entity KillAura is locked onto");
        name.setVisibility(() -> mode.is("Box"));
        health.setVisibility(() -> mode.is("Box"));
        speed.setVisibility(() -> !mode.is("Box"));
        size.setVisibility(() -> !mode.is("Box"));
        rainbow.setVisibility(() -> !mode.is("Box"));
    }

    private static LivingEntity currentTarget() {
        LivingEntity t = KillAura.target();
        return t != null && t.isAlive() ? t : null;
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        LivingEntity target = currentTarget();
        if (player == null || target == null || !RenderUtil.isReady()) {
            return;
        }
        if (!throughWalls.get() && !player.canSee(target)) {
            return;
        }
        if (mode.is("Box")) {
            drawBox(ctx, target);
            return;
        }

        time = (System.currentTimeMillis() % 1_000_000L) / 1000.0 * speed.get();
        Vec3d center = target.getLerpedPos(RenderUtil.tickDelta());
        float dist = Math.max(1.0f, player.distanceTo(target));
        if (mode.is("Ring")) {
            drawRing(ctx, target, center);
        } else if (mode.is("Ghosts")) {
            drawGhosts(ctx, target, center, dist);
        } else if (mode.is("Crystals")) {
            drawCrystals(ctx, target, center, dist);
        } else if (mode.is("Mark")) {
            drawMark(ctx, target, center, dist);
        } else {
            drawCubes(ctx, target, center, dist);
        }
    }

    /** Base colour for part {@code index} of {@code count}: accent or rainbow, flashing red while the target is hurt. */
    private int color(int index, int count, LivingEntity target) {
        int base = rainbow.get()
                ? Theme.hue((float) ((time * 0.15 + index / (double) Math.max(1, count)) % 1.0))
                : Theme.accent();
        if (redOnHit.get() && target.hurtTime > 0) {
            base = Theme.mix(base, 0xFFFF3030, Math.min(1.0f, target.hurtTime / 8.0f));
        }
        return base;
    }

    private void drawRing(DrawContext ctx, LivingEntity target, Vec3d c) {
        double radius = (target.getWidth() * 0.5 + 0.3) * size.get();
        double height = target.getHeight();
        for (int layer = 0; layer < 4; layer++) {
            double yOffset = height * (0.5 + 0.5 * Math.sin(time * 2.0 - layer * 0.4));
            float alpha = 1.0f - layer * 0.27f;
            boolean havePrev = false;
            for (int i = 0; i <= RING_SEGMENTS; i++) {
                double angle = i * (Math.PI * 2.0 / RING_SEGMENTS);
                boolean ok = RenderUtil.project(c.x + Math.cos(angle) * radius, c.y + yOffset, c.z + Math.sin(angle) * radius, cur);
                if (ok && havePrev) {
                    int col = color(i, RING_SEGMENTS, target);
                    if (layer == 0) {
                        RenderUtil.line(ctx, prev[0], prev[1], cur[0], cur[1], Theme.withAlpha(col, 0.16f), 5);
                    }
                    RenderUtil.line(ctx, prev[0], prev[1], cur[0], cur[1], Theme.withAlpha(col, alpha), layer == 0 ? 2 : 1);
                }
                havePrev = ok;
                prev[0] = cur[0];
                prev[1] = cur[1];
            }
        }
    }

    private void drawGhosts(DrawContext ctx, LivingEntity target, Vec3d c, float dist) {
        double height = target.getHeight();
        double radius = (target.getWidth() * 0.5 + 0.5) * size.get();
        for (int g = 0; g < 3; g++) {
            double base = time * 1.8 + g * (Math.PI * 2.0 / 3.0);
            for (int k = 11; k >= 0; k--) {
                double angle = base - k * 0.14;
                double t = time - k * 0.035;
                double yOffset = height * (0.5 + 0.38 * Math.sin(t * 1.3 + g * 2.1));
                if (!RenderUtil.project(c.x + Math.cos(angle) * radius, c.y + yOffset, c.z + Math.sin(angle) * radius, cur)) {
                    continue;
                }
                float fade = 1.0f - k / 12.0f;
                float r = MathHelper.clamp(14.0f / dist, 1.2f, 6.0f) * size.getFloat() * (0.45f + 0.55f * fade);
                int col = color(g, 3, target);
                dot(ctx, cur[0], cur[1], r * 2.0f, Theme.withAlpha(col, 0.12f * fade));
                dot(ctx, cur[0], cur[1], r * 1.4f, Theme.withAlpha(col, 0.30f * fade));
                dot(ctx, cur[0], cur[1], r * 0.8f, Theme.withAlpha(col, 0.90f * fade));
            }
        }
    }

    private void drawCrystals(DrawContext ctx, LivingEntity target, Vec3d c, float dist) {
        double height = target.getHeight();
        double radius = (target.getWidth() * 0.5 + 0.55) * size.get();
        float s = MathHelper.clamp(22.0f / dist, 3.0f, 11.0f) * size.getFloat();
        for (int i = 0; i < 4; i++) {
            double angle = time * 1.2 + i * (Math.PI / 2.0);
            double yOffset = height * (0.5 + 0.3 * Math.sin(time * 1.5 + i * 1.7));
            if (!RenderUtil.project(c.x + Math.cos(angle) * radius, c.y + yOffset, c.z + Math.sin(angle) * radius, cur)) {
                continue;
            }
            int col = color(i, 4, target);
            float x = cur[0];
            float y = cur[1];
            RenderUtil.line(ctx, x, y - s, x + s * 0.6f, y, col, 1);
            RenderUtil.line(ctx, x + s * 0.6f, y, x, y + s, col, 1);
            RenderUtil.line(ctx, x, y + s, x - s * 0.6f, y, col, 1);
            RenderUtil.line(ctx, x - s * 0.6f, y, x, y - s, col, 1);
            dot(ctx, x, y, s * 0.35f, Theme.withAlpha(col, 0.8f));
        }
    }

    private void drawCubes(DrawContext ctx, LivingEntity target, Vec3d c, float dist) {
        double height = target.getHeight();
        double radius = (target.getWidth() * 0.5 + 0.5) * size.get();
        float s = MathHelper.clamp(18.0f / dist, 2.0f, 8.0f) * size.getFloat();
        for (int i = 0; i < 6; i++) {
            double angle = time * 1.0 + i * (Math.PI * 2.0 / 6.0);
            double yOffset = height * (0.15 + 0.7 * (0.5 + 0.5 * Math.sin(time * 1.4 + i * 1.1)));
            if (!RenderUtil.project(c.x + Math.cos(angle) * radius, c.y + yOffset, c.z + Math.sin(angle) * radius, cur)) {
                continue;
            }
            int col = color(i, 6, target);
            RenderUtil.fillHalf(ctx, cur[0] - s, cur[1] - s, cur[0] + s, cur[1] + s, Theme.withAlpha(col, 0.45f));
            RenderUtil.outline(ctx, cur[0] - s, cur[1] - s, cur[0] + s, cur[1] + s, col);
        }
    }

    /** A slowly spinning, bobbing diamond (octahedron) above the target's head. */
    private void drawMark(DrawContext ctx, LivingEntity target, Vec3d c, float dist) {
        double cy = c.y + target.getHeight() + 0.45 * size.get() + 0.06 * Math.sin(time * 2.0);
        double half = 0.2 * size.get();
        double wide = 0.13 * size.get();
        // Vertices: 0 = top, 1 = bottom, 2..5 = the ring in the middle.
        double[][] vertices = new double[6][3];
        vertices[0] = new double[] {c.x, cy + half, c.z};
        vertices[1] = new double[] {c.x, cy - half, c.z};
        for (int i = 0; i < 4; i++) {
            double angle = time * 1.6 + i * (Math.PI / 2.0);
            vertices[2 + i] = new double[] {c.x + Math.cos(angle) * wide, cy, c.z + Math.sin(angle) * wide};
        }
        float[][] screen = new float[6][2];
        boolean[] visible = new boolean[6];
        for (int i = 0; i < 6; i++) {
            visible[i] = RenderUtil.project(vertices[i][0], vertices[i][1], vertices[i][2], cur);
            screen[i][0] = cur[0];
            screen[i][1] = cur[1];
        }
        int col = color(0, 1, target);
        for (int i = 2; i < 6; i++) {
            int next = i == 5 ? 2 : i + 1;
            edge(ctx, screen, visible, 0, i, col);
            edge(ctx, screen, visible, 1, i, Theme.withAlpha(col, 0.7f));
            edge(ctx, screen, visible, i, next, Theme.withAlpha(col, 0.85f));
        }
        if (visible[0] && visible[1]) {
            dot(ctx, (screen[0][0] + screen[1][0]) * 0.5f, (screen[0][1] + screen[1][1]) * 0.5f,
                    MathHelper.clamp(10.0f / dist, 1.0f, 4.0f), Theme.withAlpha(col, 0.35f));
        }
    }

    private static void edge(DrawContext ctx, float[][] screen, boolean[] visible, int a, int b, int color) {
        if (visible[a] && visible[b]) {
            RenderUtil.line(ctx, screen[a][0], screen[a][1], screen[b][0], screen[b][1], color, 1);
        }
    }

    private void drawBox(DrawContext ctx, LivingEntity target) {
        Box b = target.getBoundingBox();
        if (!RenderUtil.projectBox(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, rect)) {
            return;
        }
        float x1 = rect[0];
        float y1 = rect[1];
        float x2 = rect[2];
        float y2 = rect[3];
        int col = color(0, 1, target);
        RenderUtil.outline(ctx, x1 - 1.5f, y1 - 1.5f, x2 + 1.5f, y2 + 1.5f, 0xCC000000);
        RenderUtil.outline(ctx, x1, y1, x2, y2, col);
        if (name.get()) {
            RenderUtil.text(ctx, target.getName().getString(), (x1 + x2) * 0.5f, y1 - 9, 0xFFFFFFFF, 0.75f);
        }
        if (health.get()) {
            float frac = MathHelper.clamp(target.getHealth() / Math.max(1.0f, target.getMaxHealth()), 0.0f, 1.0f);
            float barX1 = x1 - 5;
            float barX2 = x1 - 3;
            RenderUtil.fillHalf(ctx, barX1, y1 - 1, barX2, y2 + 1, 0xAA000000);
            float top = y2 - (y2 - y1) * frac;
            RenderUtil.fillHalf(ctx, barX1 + 0.5f, top, barX2 - 0.5f, y2, Theme.mix(0xFFFF5C5C, col, frac));
        }
    }

    /** Filled circle of radius {@code radius} pixels (rounded to whole pixels, at least 1). */
    private static void dot(DrawContext ctx, float x, float y, float radius, int color) {
        int r = Math.max(1, Math.round(radius));
        int cx = Math.round(x);
        int cy = Math.round(y);
        RenderUtil.roundRect(ctx, cx - r, cy - r, cx + r, cy + r, r, color);
    }
}
