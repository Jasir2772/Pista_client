package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

/**
 * Stand-alone box and health bar for whatever KillAura or TriggerBot is currently locked onto.
 * Independent of the ESP module on purpose, so it works even with ESP switched off.
 */
public final class TargetEsp extends Module {
    private final BoolSetting box = bool("Box", true);
    private final BoolSetting name = bool("Name", true);
    private final BoolSetting health = bool("Health", true);
    private final float[] rect = new float[4];

    public TargetEsp() {
        super("TargetESP", Category.RENDER, "Highlights the entity KillAura/TriggerBot is locked onto");
    }

    private static LivingEntity currentTarget() {
        LivingEntity t = KillAura.target();
        return t != null && t.isAlive() ? t : null;
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        LivingEntity target = currentTarget();
        if (target == null || !RenderUtil.isReady()) {
            return;
        }
        Box b = target.getBoundingBox();
        if (!RenderUtil.projectBox(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, rect)) {
            return;
        }
        float x1 = rect[0];
        float y1 = rect[1];
        float x2 = rect[2];
        float y2 = rect[3];
        int accent = Theme.accent();

        if (box.get()) {
            RenderUtil.outline(ctx, x1 - 1.5f, y1 - 1.5f, x2 + 1.5f, y2 + 1.5f, 0xCC000000);
            RenderUtil.outline(ctx, x1, y1, x2, y2, accent);
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        if (name.get()) {
            RenderUtil.text(ctx, target.getName().getString(), (x1 + x2) * 0.5f, y1 - 9, 0xFFFFFFFF, 0.75f);
        }
        if (health.get()) {
            float frac = MathHelper.clamp(target.getHealth() / Math.max(1.0f, target.getMaxHealth()), 0.0f, 1.0f);
            float barX1 = x1 - 5;
            float barX2 = x1 - 3;
            RenderUtil.fillHalf(ctx, barX1, y1 - 1, barX2, y2 + 1, 0xAA000000);
            float top = y2 - (y2 - y1) * frac;
            RenderUtil.fillHalf(ctx, barX1 + 0.5f, top, barX2 - 0.5f, y2, Theme.mix(0xFFFF5C5C, accent, frac));
        }
    }
}
