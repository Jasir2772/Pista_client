package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** A glowing cone hat above your head, drawn in third person only. */
public final class ChinaHat extends Module {
    private static final int SPOKES = 20;

    private final NumberSetting radius = number("Radius", 0.5, 0.3, 0.9, 0.05);
    private final BoolSetting rainbow = bool("Rainbow", false);

    private final float[] apex = new float[2];
    private final float[] a = new float[2];
    private final float[] b = new float[2];

    public ChinaHat() {
        super("ChinaHat", Category.RENDER, "Glowing cone above your head (third person)");
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.options.getPerspective().isFirstPerson() || !RenderUtil.isReady()) {
            return;
        }
        Vec3d pos = player.getLerpedPos(RenderUtil.tickDelta());
        double baseY = pos.y + player.getHeight() + 0.02;
        if (!RenderUtil.project(pos.x, baseY + 0.32, pos.z, apex)) {
            return;
        }
        double r = radius.get();
        boolean havePrev = false;
        for (int i = 0; i <= SPOKES; i++) {
            double angle = i * (Math.PI * 2.0 / SPOKES);
            boolean ok = RenderUtil.project(pos.x + Math.cos(angle) * r, baseY, pos.z + Math.sin(angle) * r, b);
            float t = i / (float) SPOKES;
            int base = rainbow.get() ? Theme.hue(t) : Theme.mix(Theme.accent(), Theme.accent2(), Math.abs(t * 2.0f - 1.0f));
            if (ok) {
                RenderUtil.line(ctx, apex[0], apex[1], b[0], b[1], Theme.withAlpha(base, 0.45f), 1);
                if (havePrev) {
                    RenderUtil.line(ctx, a[0], a[1], b[0], b[1], base, 2);
                }
            }
            havePrev = ok;
            a[0] = b[0];
            a[1] = b[1];
        }
    }
}
