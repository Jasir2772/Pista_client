package dev.hackclient.module.impl;

import dev.hackclient.FriendManager;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.Locale;

/**
 * Sends /tpaccept after a chat line that mentions a teleport request. Message wording differs per server,
 * so the match is deliberately loose; keep OnlyFriends on unless you want to accept anyone.
 */
public final class AutoTpAccept extends Module {
    // "teleport" in Russian, written with escapes to keep the source ASCII.
    private static final String RU_TELEPORT = "\u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442";

    private final BoolSetting onlyFriends = bool("OnlyFriends", true);
    private final NumberSetting delay = number("DelayTicks", 10, 0, 60, 1);
    private int pending = -1;

    public AutoTpAccept() {
        super("AutoTpaccept", Category.PLAYER, "Accepts teleport requests");
    }

    @Override
    protected void onDisable() {
        pending = -1;
    }

    @Override
    public void onGameMessage(String message) {
        String lower = message.toLowerCase(Locale.ROOT);
        if (!(lower.contains("tpa") || lower.contains("teleport") || lower.contains(RU_TELEPORT))) {
            return;
        }
        if (onlyFriends.get() && FriendManager.all().stream().noneMatch(lower::contains)) {
            return;
        }
        pending = delay.getInt();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || pending < 0) {
            return;
        }
        if (pending > 0) {
            pending--;
            return;
        }
        pending = -1;
        player.networkHandler.sendChatCommand("tpaccept");
    }
}
