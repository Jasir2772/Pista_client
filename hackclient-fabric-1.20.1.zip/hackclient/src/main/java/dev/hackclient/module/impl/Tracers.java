package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

public final class Tracers extends Module {
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting hostiles = bool("Hostiles", false);
    private final BoolSetting passives = bool("Passives", false);
    private final ModeSetting origin = mode("From", "Bottom", "Bottom", "Crosshair");
    private final NumberSetting range = number("Range", 96, 16, 128, 4);
    private final float[] point = new float[2];

    public Tracers() {
        super("Tracers", Category.RENDER, "Lines to entities");
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity self = mc.player;
        ClientWorld world = mc.world;
        if (self == null || world == null || !RenderUtil.isReady()) {
            return;
        }
        var window = mc.getWindow();
        float ox = window.getScaledWidth() * 0.5f;
        float oy = origin.is("Bottom") ? window.getScaledHeight() : window.getScaledHeight() * 0.5f;
        double maxSq = range.get() * range.get();
        float td = RenderUtil.tickDelta();
        for (Entity e : world.getEntities()) {
            if (e == self || e.squaredDistanceTo(self) > maxSq) {
                continue;
            }
            int color = Targets.colorFor(e, players.get(), hostiles.get(), passives.get(), false);
            if (color == 0) {
                continue;
            }
            Vec3d p = e.getLerpedPos(td);
            if (RenderUtil.project(p.x, p.y + e.getHeight() * 0.5, p.z, point)) {
                RenderUtil.line(ctx, ox, oy, point[0], point[1], color, 1);
            }
        }
    }
}
