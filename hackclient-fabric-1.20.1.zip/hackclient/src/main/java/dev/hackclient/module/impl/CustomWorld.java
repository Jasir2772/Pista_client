package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;

/** Client-side time of day and weather. The server is not told; its own time packets are overridden every tick. */
public final class CustomWorld extends Module {
    private final NumberSetting time = number("Time", 6000, 0, 24000, 250);
    private final BoolSetting fixedTime = bool("FixedTime", true);
    private final BoolSetting clearWeather = bool("ClearWeather", true);

    public CustomWorld() {
        super("CustomWorld", Category.RENDER, "Own time of day, no rain");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientWorld world = mc.world;
        if (world == null) {
            return;
        }
        if (fixedTime.get()) {
            world.setTimeOfDay(time.getInt());
        }
        if (clearWeather.get()) {
            world.setRainGradient(0.0f);
            world.setThunderGradient(0.0f);
        }
    }
}
