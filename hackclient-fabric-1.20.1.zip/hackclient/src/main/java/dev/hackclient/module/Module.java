package dev.hackclient.module;

import dev.hackclient.HackClient;
import dev.hackclient.module.impl.ClientSounds;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.module.setting.Setting;
import dev.hackclient.util.Notifications;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    private final String name;
    private final Category category;
    private final String description;
    private final List<Setting> settings = new ArrayList<>();
    private final List<Setting> settingsView = Collections.unmodifiableList(settings);
    private boolean enabled;
    private int key = -1;
    private boolean expanded;
    boolean keyWasDown;

    protected Module(String name, Category category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }

    public final String getName() {
        return name;
    }

    public final Category getCategory() {
        return category;
    }

    public final String getDescription() {
        return description;
    }

    public final List<Setting> settings() {
        return settingsView;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final void setEnabled(boolean value) {
        if (value == enabled) {
            return;
        }
        enabled = value;
        HackClient.modules().markDirty();
        Notifications.push(name, value);
        ClientSounds.onToggle(value);
        if (value) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public final void toggle() {
        setEnabled(!enabled);
    }

    /** GLFW key code, or -1 when unbound. */
    public final int getKey() {
        return key;
    }

    public final void setKey(int key) {
        this.key = key;
    }

    public final boolean isExpanded() {
        return expanded;
    }

    public final void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    public boolean showInList() {
        return true;
    }

    protected final BoolSetting bool(String settingName, boolean defaultValue) {
        BoolSetting s = new BoolSetting(settingName, defaultValue);
        settings.add(s);
        return s;
    }

    protected final NumberSetting number(String settingName, double defaultValue, double min, double max, double step) {
        NumberSetting s = new NumberSetting(settingName, defaultValue, min, max, step);
        settings.add(s);
        return s;
    }

    protected final ModeSetting mode(String settingName, String defaultMode, String... modes) {
        ModeSetting s = new ModeSetting(settingName, defaultMode, modes);
        settings.add(s);
        return s;
    }

    /** May run before a world exists (config restore); must not assume mc.player or mc.world. */
    protected void onEnable() {
    }

    protected void onDisable() {
    }

    /** Start of every client tick, before player movement is processed. */
    public void onPreTick(MinecraftClient mc) {
    }

    /** End of every client tick. mc.player / mc.world may be null. */
    public void onTick(MinecraftClient mc) {
    }

    public void onRender2D(DrawContext context, float tickDelta) {
    }

    public void onGameMessage(String message) {
    }
}
