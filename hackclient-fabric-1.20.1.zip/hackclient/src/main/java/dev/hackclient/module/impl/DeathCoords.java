package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.util.Chat;
import dev.hackclient.util.Lang;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.util.math.BlockPos;

public final class DeathCoords extends Module {
    private boolean wasDead;

    public DeathCoords() {
        super("DeathCoords", Category.PLAYER, "Prints your coordinates in chat when you die");
    }

    @Override
    protected void onEnable() {
        wasDead = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        boolean dead = mc.currentScreen instanceof DeathScreen;
        if (dead && !wasDead && mc.player != null && mc.world != null) {
            BlockPos pos = mc.player.getBlockPos();
            String dimension = mc.world.getRegistryKey().getValue().toString();
            Chat.say(Lang.t("Died at ", "O'lgan joy: ")
                    + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " (" + dimension + ")");
        }
        wasDead = dead;
    }
}
