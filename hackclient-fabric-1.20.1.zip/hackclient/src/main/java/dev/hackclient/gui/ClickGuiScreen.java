package dev.hackclient.gui;

import dev.hackclient.Config;
import dev.hackclient.HackClient;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.ModuleManager;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.module.setting.Setting;
import dev.hackclient.util.Brand;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Lang;
import dev.hackclient.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * One rounded panel per category. Tap a module to toggle it, tap "+" to open its settings.
 * The whole UI is drawn at a scale that fits the screen height, so it stays usable on small, high-density phone screens.
 * Plain DrawContext fills only (no shaders); hit regions are pooled so a frame allocates nothing.
 */
public final class ClickGuiScreen extends Screen {
    private static final int HEADER_H = 24;
    private static final int ROW_H = 23;
    private static final int SET_H = 21;
    private static final int GAP = 10;

    private static final int HIT_HEADER = 0;
    private static final int HIT_TOGGLE = 1;
    private static final int HIT_EXPAND = 2;
    private static final int HIT_BOOL = 3;
    private static final int HIT_NUMBER = 4;
    private static final int HIT_MODE = 5;
    private static final int HIT_BIND = 6;

    private final Map<Module, Float> anim = new HashMap<>();
    private float frameDt = 0.016f;
    private long lastFrameNs;

    private static final Map<Category, float[]> SAVED_POSITIONS = new EnumMap<>(Category.class);

    private static final class Panel {
        final Category category;
        final List<Module> modules;
        float x;
        float y;
        float scroll;
        float maxScroll;

        Panel(Category category, List<Module> modules) {
            this.category = category;
            this.modules = modules;
        }
    }

    private static final class Hit {
        int x1;
        int y1;
        int x2;
        int y2;
        int type;
        Panel panel;
        Module module;
        Setting setting;
    }

    private final ModuleManager manager;
    private final List<Panel> panels = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private int hitCount;
    private int panelW = 110;
    private float uiScale = 1.0f;
    private int vw;
    private int vh;

    private Panel dragPanel;
    private float dragOffX;
    private float dragOffY;
    private NumberSetting dragNumber;
    private int dragX1;
    private int dragX2;
    private Module bindTarget;

    public ClickGuiScreen(ModuleManager manager) {
        super(Text.literal("HackClient"));
        this.manager = manager;
        for (Category c : Category.values()) {
            panels.add(new Panel(c, manager.inCategory(c)));
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        uiScale = MathHelper.clamp(height / 270.0f, 0.68f, 1.0f);
        vw = (int) (width / uiScale);
        vh = (int) (height / uiScale);
        int n = panels.size();
        panelW = MathHelper.clamp((vw - 16 - GAP * (n - 1)) / n, 104, 132);
        int totalW = panelW * n + GAP * (n - 1);
        int startX = Math.max(4, (vw - totalW) / 2);
        for (int i = 0; i < n; i++) {
            Panel p = panels.get(i);
            float[] saved = SAVED_POSITIONS.get(p.category);
            if (saved != null) {
                p.x = saved[0];
                p.y = saved[1];
            } else {
                p.x = startX + i * (panelW + GAP);
                p.y = 20;
            }
        }
    }

    @Override
    public void removed() {
        Config.save(manager);
    }

    private Hit hit(int x1, int y1, int x2, int y2, int type) {
        Hit h;
        if (hitCount < hits.size()) {
            h = hits.get(hitCount);
        } else {
            h = new Hit();
            hits.add(h);
        }
        hitCount++;
        h.x1 = x1;
        h.y1 = y1;
        h.x2 = x2;
        h.y2 = y2;
        h.type = type;
        h.panel = null;
        h.module = null;
        h.setting = null;
        return h;
    }

    private static int visibleCount(Module m) {
        int c = 0;
        for (Setting s : m.settings()) {
            if (s.isVisible()) {
                c++;
            }
        }
        return c;
    }

    private float animation(Module m) {
        float goal = m.isEnabled() ? 1.0f : 0.0f;
        float cur = anim.getOrDefault(m, goal);
        cur += (goal - cur) * Math.min(1.0f, frameDt * 12.0f);
        if (Math.abs(goal - cur) < 0.01f) {
            cur = goal;
        }
        anim.put(m, cur);
        return cur;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        frameDt = lastFrameNs == 0L ? 0.016f : MathHelper.clamp((now - lastFrameNs) / 1.0e9f, 0.0f, 0.1f);
        lastFrameNs = now;
        hitCount = 0;
        int accent = Theme.accent();
        int accent2 = Theme.accent2();
        ctx.fillGradient(0, 0, width, height, 0xB0060810, 0x90101830);
        ctx.fillGradient(0, 0, width, height / 3, Theme.withAlpha(accent, 0.12f), 0x00000000);
        int vmx = (int) (mouseX / uiScale);
        int vmy = (int) (mouseY / uiScale);
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.scale(uiScale, uiScale, 1.0f);

        String word = "PISTA";
        String sub = "CLIENT";
        int wordW = textRenderer.getWidth(word);
        int subW = textRenderer.getWidth(sub);
        int bw = 16 + 6 + wordW + 4 + subW + 14;
        int bx = (vw - bw) / 2;
        RenderUtil.roundRect(ctx, bx - 1, 3, bx + bw + 1, 21, 8, Theme.withAlpha(accent, 0.25f));
        RenderUtil.roundRect(ctx, bx, 4, bx + bw, 20, 7, Theme.withAlpha(Theme.PANEL_BG, 1.0f));
        Brand.logo(ctx, bx + 4, 6, 12);
        Brand.gradientText(ctx, textRenderer, word, bx + 22, 8, accent, accent2);
        ctx.drawTextWithShadow(textRenderer, sub, bx + 26 + wordW, 8, Theme.TEXT_DIM);

        for (Panel p : panels) {
            renderPanel(ctx, p, vmx, vmy);
        }
        renderTooltip(ctx, vmx, vmy, accent);
        m.pop();
        String footer = Lang.t("Tap = on/off    + = settings    Chat: .help    .lang en|uz",
                "Bosing = yoqish/o'chirish    + = sozlamalar    Chat: .help    .lang en|uz");
        ctx.drawCenteredTextWithShadow(textRenderer, footer, width / 2, height - 10, 0x66FFFFFF);
    }

    /** Module description next to the cursor while hovering a module row. */
    private void renderTooltip(DrawContext ctx, int mx, int my, int accent) {
        for (int i = 0; i < hitCount; i++) {
            Hit h = hits.get(i);
            if ((h.type != HIT_TOGGLE && h.type != HIT_EXPAND) || h.module == null
                    || mx < h.x1 || mx >= h.x2 || my < h.y1 || my >= h.y2) {
                continue;
            }
            String text = h.module.getDescription();
            if (text == null || text.isEmpty()) {
                return;
            }
            int tw = textRenderer.getWidth(text);
            int x = Math.min(mx + 10, vw - tw - 14);
            int y = Math.min(my + 12, vh - 20);
            RenderUtil.roundRect(ctx, x - 1, y - 1, x + tw + 11, y + 15, 6, Theme.withAlpha(accent, 0.35f));
            RenderUtil.roundRect(ctx, x, y, x + tw + 10, y + 14, 5, Theme.withAlpha(Theme.PANEL_BG, 1.0f));
            ctx.drawText(textRenderer, text, x + 5, y + 3, Theme.TEXT, false);
            return;
        }
    }

    private void renderPanel(DrawContext ctx, Panel p, int mx, int my) {
        int accent = Theme.accent();
        int accent2 = Theme.accent2();
        int x1 = Math.round(p.x);
        int y1 = Math.round(p.y);
        int x2 = x1 + panelW;

        int contentH = 0;
        int enabledCount = 0;
        for (Module m : p.modules) {
            contentH += ROW_H;
            if (m.isEnabled()) {
                enabledCount++;
            }
            if (m.isExpanded()) {
                contentH += (visibleCount(m) + 1) * SET_H;
            }
        }
        int maxView = Math.max(ROW_H, vh - 8 - (y1 + HEADER_H + 2));
        int viewH = Math.min(contentH, maxView);
        p.maxScroll = Math.max(0, contentH - viewH);
        p.scroll = MathHelper.clamp(p.scroll, 0.0f, p.maxScroll);
        int bodyTop = y1 + HEADER_H + 2;
        int bodyBottom = bodyTop + viewH;

        // Soft shadow, then the panel body and a tinted header.
        RenderUtil.roundRect(ctx, x1 - 2, y1 - 1, x2 + 2, bodyBottom + 8, 9, 0x22000000);
        RenderUtil.roundRect(ctx, x1 - 1, y1, x2 + 1, bodyBottom + 6, 8, 0x30000000);
        RenderUtil.roundRect(ctx, x1, y1, x2, bodyBottom + 5, 6, Theme.PANEL_BG);
        RenderUtil.roundRect(ctx, x1, y1, x2, y1 + HEADER_H, 6, Theme.mix(Theme.PANEL_BG, accent, 0.16f));

        // Category badge (initial letter) and gradient title.
        RenderUtil.roundRect(ctx, x1 + 7, y1 + 5, x1 + 21, y1 + 19, 4, accent);
        String initial = p.category.label.isEmpty() ? "?" : p.category.label.substring(0, 1);
        ctx.drawCenteredTextWithShadow(textRenderer, initial, x1 + 14, y1 + 8, 0xFFFFFFFF);
        Brand.gradientText(ctx, textRenderer, p.category.label, x1 + 27, y1 + 8, 0xFFFFFFFF, Theme.mix(0xFFFFFFFF, accent2, 0.6f));
        String counter = enabledCount + "/" + p.modules.size();
        ctx.drawText(textRenderer, counter, x2 - 8 - textRenderer.getWidth(counter), y1 + 8, Theme.TEXT_DIM, false);

        // Gradient line under the header.
        int lineX1 = x1 + 8;
        int lineX2 = x2 - 8;
        int segments = 16;
        for (int i = 0; i < segments; i++) {
            int sx1 = lineX1 + (lineX2 - lineX1) * i / segments;
            int sx2 = lineX1 + (lineX2 - lineX1) * (i + 1) / segments;
            ctx.fill(sx1, y1 + HEADER_H - 1, sx2, y1 + HEADER_H, Theme.withAlpha(Theme.mix(accent, accent2, i / (float) (segments - 1)), 0.95f));
        }
        hit(x1, y1, x2, y1 + HEADER_H, HIT_HEADER).panel = p;

        int y = bodyTop - Math.round(p.scroll);
        for (Module m : p.modules) {
            float a = animation(m);
            if (y >= bodyTop && y + ROW_H <= bodyBottom) {
                boolean hover = mx >= x1 && mx < x2 && my >= y && my < y + ROW_H;
                if (a > 0.01f) {
                    RenderUtil.roundRect(ctx, x1 + 4, y + 1, x2 - 4, y + ROW_H - 1, 4, Theme.withAlpha(accent, 0.30f * a));
                    RenderUtil.roundRect(ctx, x1 + 4, y + 5, x1 + 6, y + ROW_H - 5, 1, Theme.withAlpha(accent, a));
                }
                if (hover) {
                    RenderUtil.roundRect(ctx, x1 + 4, y + 1, x2 - 4, y + ROW_H - 1, 4, 0x1AFFFFFF);
                }
                ctx.drawText(textRenderer, m.getName(), x1 + 11, y + 5, Theme.mix(Theme.TEXT, 0xFFFFFFFF, a), false);
                String arrow = m.isExpanded() ? "v" : ">";
                ctx.drawText(textRenderer, arrow, x2 - 13, y + 5, Theme.mix(Theme.TEXT_DIM, 0xFFFFFFFF, a), false);
                hit(x1, y, x2 - 20, y + ROW_H, HIT_TOGGLE).module = m;
                hit(x2 - 20, y, x2, y + ROW_H, HIT_EXPAND).module = m;
            }
            y += ROW_H;
            if (m.isExpanded()) {
                for (Setting s : m.settings()) {
                    if (!s.isVisible()) {
                        continue;
                    }
                    renderSetting(ctx, m, s, x1, x2, y, bodyTop, bodyBottom, mx, my, accent);
                    y += SET_H;
                }
                renderBind(ctx, m, x1, x2, y, bodyTop, bodyBottom, mx, my);
                y += SET_H;
            }
        }

        if (p.maxScroll > 0.0f) {
            int trackTop = bodyTop;
            int trackH = bodyBottom - bodyTop;
            ctx.fill(x2 - 3, trackTop, x2 - 1, bodyBottom, 0x22FFFFFF);
            int thumbH = Math.max(12, Math.round(trackH * (viewH / (float) contentH)));
            int thumbY = trackTop + Math.round((trackH - thumbH) * (p.scroll / p.maxScroll));
            RenderUtil.roundRect(ctx, x2 - 3, thumbY, x2 - 1, thumbY + thumbH, 1, Theme.withAlpha(accent, 0.9f));
        }
    }

    private void renderSetting(DrawContext ctx, Module m, Setting s, int x1, int x2, int top,
                               int bodyTop, int bodyBottom, int mx, int my, int accent) {
        if (top < bodyTop || top + SET_H > bodyBottom) {
            return;
        }
        int accent2 = Theme.accent2();
        int rx1 = x1 + 8;
        int rx2 = x2 - 8;
        boolean hover = mx >= x1 && mx < x2 && my >= top && my < top + SET_H;
        int type;
        if (s instanceof BoolSetting b) {
            type = HIT_BOOL;
            if (hover) {
                RenderUtil.roundRect(ctx, rx1 - 3, top, rx2 + 3, top + SET_H - 1, 3, 0x18FFFFFF);
            }
            ctx.drawText(textRenderer, b.name, rx1, top + 6, Theme.TEXT, false);
            int px = rx2 - 22;
            RenderUtil.roundRect(ctx, px, top + 4, px + 22, top + 16, 6, b.get() ? Theme.mix(accent, accent2, 0.5f) : 0xFF353B4A);
            int kx = b.get() ? px + 12 : px + 1;
            RenderUtil.roundRect(ctx, kx, top + 5, kx + 9, top + 15, 5, 0xFFFFFFFF);
        } else if (s instanceof NumberSetting n) {
            type = HIT_NUMBER;
            ctx.drawText(textRenderer, n.name, rx1, top + 3, Theme.TEXT, false);
            String v = n.display();
            ctx.drawText(textRenderer, v, rx2 - textRenderer.getWidth(v), top + 3, Theme.TEXT_DIM, false);
            int ty = top + SET_H - 6;
            int fw = (int) ((rx2 - rx1) * n.fraction());
            ctx.fill(rx1, ty, rx2, ty + 2, 0x30FFFFFF);
            int segments = 8;
            for (int i = 0; i < segments; i++) {
                int sx1 = rx1 + fw * i / segments;
                int sx2 = rx1 + fw * (i + 1) / segments;
                if (sx2 > sx1) {
                    ctx.fill(sx1, ty, sx2, ty + 2, Theme.mix(accent, accent2, i / (float) (segments - 1)));
                }
            }
            RenderUtil.roundRect(ctx, rx1 + fw - 4, ty - 4, rx1 + fw + 5, ty + 6, 5, Theme.withAlpha(accent2, 0.30f));
            RenderUtil.roundRect(ctx, rx1 + fw - 2, ty - 2, rx1 + fw + 3, ty + 4, 2, 0xFFFFFFFF);
        } else if (s instanceof ModeSetting ms) {
            type = HIT_MODE;
            if (hover) {
                RenderUtil.roundRect(ctx, rx1 - 3, top, rx2 + 3, top + SET_H - 1, 3, 0x18FFFFFF);
            }
            ctx.drawText(textRenderer, ms.name, rx1, top + 6, Theme.TEXT, false);
            String v = ms.get();
            int vw2 = textRenderer.getWidth(v);
            RenderUtil.roundRect(ctx, rx2 - vw2 - 6, top + 3, rx2 + 2, top + SET_H - 4, 4, Theme.withAlpha(accent, 0.20f));
            ctx.drawText(textRenderer, v, rx2 - vw2 - 2, top + 6, accent, false);
        } else {
            return;
        }
        Hit h = hit(x1, top, x2, top + SET_H, type);
        h.module = m;
        h.setting = s;
        if (type == HIT_NUMBER) {
            h.x1 = rx1;
            h.x2 = rx2;
        }
    }

    private void renderBind(DrawContext ctx, Module m, int x1, int x2, int top, int bodyTop, int bodyBottom, int mx, int my) {
        if (top < bodyTop || top + SET_H > bodyBottom) {
            return;
        }
        if (mx >= x1 && mx < x2 && my >= top && my < top + SET_H) {
            RenderUtil.roundRect(ctx, x1 + 5, top, x2 - 5, top + SET_H - 1, 3, 0x18FFFFFF);
        }
        String label;
        if (bindTarget == m) {
            label = Lang.t("Press a key...", "Tugmani bosing...");
        } else if (m.getKey() < 0) {
            label = Lang.t("Bind: None", "Bog'lanish: Yo'q");
        } else {
            label = Lang.t("Bind: ", "Bog'lanish: ") + InputUtil.fromKeyCode(m.getKey(), -1).getLocalizedText().getString();
        }
        ctx.drawText(textRenderer, label, x1 + 8, top + 6, bindTarget == m ? Theme.accent() : Theme.TEXT_DIM, false);
        hit(x1, top, x2, top + SET_H, HIT_BIND).module = m;
    }

    private void updateSlider(double virtualX) {
        if (dragNumber != null && dragX2 > dragX1) {
            dragNumber.setFromFraction((virtualX - dragX1) / (double) (dragX2 - dragX1));
        }
    }

    @Override
    public boolean mouseClicked(double screenX, double screenY, int button) {
        double mx = screenX / uiScale;
        double my = screenY / uiScale;
        for (int i = 0; i < hitCount; i++) {
            Hit h = hits.get(i);
            if (mx < h.x1 || mx >= h.x2 || my < h.y1 || my >= h.y2) {
                continue;
            }
            switch (h.type) {
                case HIT_HEADER -> {
                    dragPanel = h.panel;
                    dragOffX = (float) (mx - h.panel.x);
                    dragOffY = (float) (my - h.panel.y);
                }
                case HIT_TOGGLE -> {
                    if (button == 1) {
                        h.module.setExpanded(!h.module.isExpanded());
                    } else {
                        h.module.toggle();
                    }
                }
                case HIT_EXPAND -> h.module.setExpanded(!h.module.isExpanded());
                case HIT_BOOL -> ((BoolSetting) h.setting).toggle();
                case HIT_MODE -> {
                    ModeSetting ms = (ModeSetting) h.setting;
                    if (button == 1) {
                        ms.prev();
                    } else {
                        ms.next();
                    }
                }
                case HIT_NUMBER -> {
                    dragNumber = (NumberSetting) h.setting;
                    dragX1 = h.x1;
                    dragX2 = h.x2;
                    updateSlider(mx);
                }
                case HIT_BIND -> bindTarget = bindTarget == h.module ? null : h.module;
                default -> {
                }
            }
            return true;
        }
        return super.mouseClicked(screenX, screenY, button);
    }

    @Override
    public boolean mouseDragged(double screenX, double screenY, int button, double dx, double dy) {
        double mx = screenX / uiScale;
        double my = screenY / uiScale;
        if (dragPanel != null) {
            dragPanel.x = MathHelper.clamp((float) (mx - dragOffX), 0.0f, Math.max(0, vw - panelW));
            dragPanel.y = MathHelper.clamp((float) (my - dragOffY), 0.0f, Math.max(0, vh - HEADER_H));
            return true;
        }
        if (dragNumber != null) {
            updateSlider(mx);
            return true;
        }
        return super.mouseDragged(screenX, screenY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double screenX, double screenY, int button) {
        if (dragPanel != null) {
            SAVED_POSITIONS.put(dragPanel.category, new float[]{dragPanel.x, dragPanel.y});
        }
        dragPanel = null;
        dragNumber = null;
        return super.mouseReleased(screenX, screenY, button);
    }

    @Override
    public boolean mouseScrolled(double screenX, double screenY, double amount) {
        double mx = screenX / uiScale;
        double my = screenY / uiScale;
        for (Panel p : panels) {
            if (mx >= p.x && mx < p.x + panelW && my >= p.y && p.maxScroll > 0) {
                p.scroll = MathHelper.clamp(p.scroll - (float) amount * SET_H, 0.0f, p.maxScroll);
                return true;
            }
        }
        return super.mouseScrolled(screenX, screenY, amount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindTarget != null) {
            boolean clear = keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_BACKSPACE
                    || keyCode == GLFW.GLFW_KEY_DELETE;
            bindTarget.setKey(clear ? -1 : keyCode);
            bindTarget = null;
            return true;
        }
        if (HackClient.guiKey().matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
