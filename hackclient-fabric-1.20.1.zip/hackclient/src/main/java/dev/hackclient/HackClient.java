package dev.hackclient;

import dev.hackclient.gui.ClickGuiScreen;
import dev.hackclient.module.ModuleManager;
import dev.hackclient.module.impl.AntiAfk;
import dev.hackclient.module.impl.AutoArmor;
import dev.hackclient.module.impl.Blink;
import dev.hackclient.module.impl.ClickPearl;
import dev.hackclient.module.impl.ClientSounds;
import dev.hackclient.module.impl.Criticals;
import dev.hackclient.module.impl.DeathCoords;
import dev.hackclient.module.impl.Flight;
import dev.hackclient.module.impl.Spider;
import dev.hackclient.module.impl.Jesus;
import dev.hackclient.module.impl.FastLadder;
import dev.hackclient.module.impl.HighJump;
import dev.hackclient.module.impl.NoPush;
import dev.hackclient.module.impl.NoSlow;
import dev.hackclient.module.impl.NoWeb;
import dev.hackclient.module.impl.Predictions;
import dev.hackclient.module.impl.Removals;
import dev.hackclient.module.impl.ThirdPerson;
import dev.hackclient.module.impl.Trails;
import dev.hackclient.module.impl.Velocity;
import dev.hackclient.module.impl.AntiBot;
import dev.hackclient.module.impl.AutoLeave;
import dev.hackclient.module.impl.AutoRespawn;
import dev.hackclient.module.impl.AutoTool;
import dev.hackclient.module.impl.AutoTotem;
import dev.hackclient.module.impl.AutoTpAccept;
import dev.hackclient.module.impl.BlockEsp;
import dev.hackclient.module.impl.ChestStealer;
import dev.hackclient.module.impl.CustomWorld;
import dev.hackclient.module.impl.Esp;
import dev.hackclient.module.impl.Fullbright;
import dev.hackclient.module.impl.Hud;
import dev.hackclient.module.impl.InvWalk;
import dev.hackclient.module.impl.KillAura;
import dev.hackclient.module.impl.Language;
import dev.hackclient.module.impl.NoFriendDamage;
import dev.hackclient.module.impl.Optimization;
import dev.hackclient.module.impl.NoFall;
import dev.hackclient.module.impl.NoJumpDelay;
import dev.hackclient.module.impl.Scaffold;
import dev.hackclient.module.impl.Speed;
import dev.hackclient.module.impl.Sprint;
import dev.hackclient.module.impl.TargetEsp;
import dev.hackclient.module.impl.Tracers;
import dev.hackclient.module.impl.AutoEat;
import dev.hackclient.module.impl.FastPlace;
import dev.hackclient.module.impl.TriggerBot;
import dev.hackclient.util.RenderUtil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HackClient implements ClientModInitializer {
    public static final String MOD_ID = "hackclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final ModuleManager MODULES = new ModuleManager();
    private static KeyBinding guiKey;
    private static boolean openGuiPending;

    @Override
    public void onInitializeClient() {
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hackclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.hackclient"));

        NoFriendDamage noFriendDamage = new NoFriendDamage();

        // Combat
        MODULES.register(new KillAura());
        MODULES.register(new TriggerBot());
        MODULES.register(new AntiBot());
        MODULES.register(noFriendDamage);
        MODULES.register(new AutoTotem());
        MODULES.register(new AutoArmor());
        MODULES.register(new Velocity());
        MODULES.register(new Criticals());
        // Movement
        MODULES.register(new Sprint());
        MODULES.register(new InvWalk());
        MODULES.register(new AntiAfk());
        MODULES.register(new AutoLeave());
        MODULES.register(new NoJumpDelay());
        MODULES.register(new Speed());
        MODULES.register(new NoFall());
        MODULES.register(new Scaffold());
        MODULES.register(new NoSlow());
        MODULES.register(new NoWeb());
        MODULES.register(new Blink());
        MODULES.register(new HighJump());
        MODULES.register(new Flight());
        MODULES.register(new Spider());
        MODULES.register(new FastLadder());
        MODULES.register(new Jesus());
        // Render
        MODULES.register(new Hud());
        MODULES.register(new Esp());
        MODULES.register(new Tracers());
        MODULES.register(new TargetEsp());
        MODULES.register(new BlockEsp());
        MODULES.register(new Fullbright());
        MODULES.register(new CustomWorld());
        MODULES.register(new Trails());
        MODULES.register(new Predictions());
        MODULES.register(new Removals());
        MODULES.register(new ThirdPerson());
        // Player
        MODULES.register(new AutoTpAccept());
        MODULES.register(new AutoRespawn());
        MODULES.register(new AutoTool());
        MODULES.register(new ChestStealer());
        MODULES.register(new AutoEat());
        MODULES.register(new FastPlace());
        MODULES.register(new NoPush());
        MODULES.register(new DeathCoords());
        MODULES.register(new ClickPearl());
        // Utils
        MODULES.register(new Optimization());
        MODULES.register(new ClientSounds());
        MODULES.register(new Language());

        Config.load(MODULES);

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> Config.applyEnabled(MODULES));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            Optimization.restoreOnShutdown();
            Config.save(MODULES);
        });
        ClientTickEvents.START_CLIENT_TICK.register(MODULES::preTick);
        ClientTickEvents.END_CLIENT_TICK.register(HackClient::onEndTick);
        HudRenderCallback.EVENT.register(MODULES::render2D);
        WorldRenderEvents.LAST.register(RenderUtil::capture);
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> !Commands.handle(message));
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> MODULES.gameMessage(message.getString()));
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (noFriendDamage.isEnabled() && entity instanceof PlayerEntity target
                    && FriendManager.isFriend(target.getEntityName())) {
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }

    private static void onEndTick(MinecraftClient mc) {
        while (guiKey.wasPressed()) {
            openGuiPending = true;
        }
        if (mc.player == null) {
            openGuiPending = false;
        } else if (openGuiPending && mc.currentScreen == null) {
            openGuiPending = false;
            mc.setScreen(new ClickGuiScreen(MODULES));
        }
        MODULES.tick(mc);
    }

    public static ModuleManager modules() {
        return MODULES;
    }

    public static KeyBinding guiKey() {
        return guiKey;
    }

    /** Opens the ClickGUI on the next tick (a chat screen would otherwise close it again). */
    public static void requestOpenGui() {
        openGuiPending = true;
    }
}
