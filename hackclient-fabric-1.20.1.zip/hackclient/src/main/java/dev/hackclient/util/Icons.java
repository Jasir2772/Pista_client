package dev.hackclient.util;

import net.minecraft.client.gui.DrawContext;

/** Tiny 10x10 pictograms for the HUD, built from rectangles and lines so no image files are needed. */
public final class Icons {
    private Icons() {
    }

    public static void user(DrawContext ctx, int x, int y, int c) {
        RenderUtil.roundRect(ctx, x + 3, y, x + 7, y + 4, 2, c);
        RenderUtil.roundRect(ctx, x + 1, y + 5, x + 9, y + 10, 3, c);
    }

    public static void monitor(DrawContext ctx, int x, int y, int c) {
        RenderUtil.outline(ctx, x, y + 1, x + 10, y + 7, c);
        RenderUtil.fillHalf(ctx, x + 4, y + 7, x + 6, y + 9, c);
        RenderUtil.fillHalf(ctx, x + 2, y + 9, x + 8, y + 10, c);
    }

    public static void clock(DrawContext ctx, int x, int y, int c) {
        RenderUtil.roundRect(ctx, x, y, x + 10, y + 10, 5, Theme.withAlpha(c, 0.35f));
        RenderUtil.fillHalf(ctx, x + 4.5f, y + 2, x + 5.5f, y + 5.5f, c);
        RenderUtil.fillHalf(ctx, x + 4.5f, y + 4.5f, x + 7.5f, y + 5.5f, c);
    }

    public static void pin(DrawContext ctx, int x, int y, int c) {
        RenderUtil.roundRect(ctx, x + 2, y, x + 8, y + 6, 3, c);
        RenderUtil.fillHalf(ctx, x + 4, y + 5, x + 6, y + 10, c);
        RenderUtil.roundRect(ctx, x + 4, y + 2, x + 6, y + 4, 1, 0xFF101018);
    }

    public static void ping(DrawContext ctx, int x, int y, int c) {
        RenderUtil.fillHalf(ctx, x + 1, y + 6, x + 3, y + 10, c);
        RenderUtil.fillHalf(ctx, x + 4, y + 3, x + 6, y + 10, c);
        RenderUtil.fillHalf(ctx, x + 7, y, x + 9, y + 10, c);
    }

    public static void gauge(DrawContext ctx, int x, int y, int c) {
        RenderUtil.roundRect(ctx, x, y + 1, x + 10, y + 9, 3, Theme.withAlpha(c, 0.35f));
        RenderUtil.line(ctx, x + 5, y + 7, x + 8, y + 3, c, 1);
    }

    public static void speed(DrawContext ctx, int x, int y, int c) {
        for (int i = 0; i < 2; i++) {
            int ox = x + i * 4;
            RenderUtil.line(ctx, ox + 1, y + 1, ox + 5, y + 5, c, 1);
            RenderUtil.line(ctx, ox + 5, y + 5, ox + 1, y + 9, c, 1);
        }
    }

    public static void potion(DrawContext ctx, int x, int y, int c) {
        RenderUtil.roundRect(ctx, x + 3, y, x + 7, y + 3, 1, c);
        RenderUtil.roundRect(ctx, x + 1, y + 3, x + 9, y + 10, 3, c);
    }
}
