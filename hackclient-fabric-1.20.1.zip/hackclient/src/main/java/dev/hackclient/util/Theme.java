package dev.hackclient.util;

import dev.hackclient.module.impl.Hud;

public final class Theme {
    public static final int TEXT = 0xFFE3E7F0;
    public static final int TEXT_DIM = 0xFF8D96A8;
    public static final int PANEL_BG = 0xE0141821;
    public static final int HUD_BG = 0xB0121620;

    private Theme() {
    }

    public static int accent() {
        return Hud.accent();
    }

    public static int withAlpha(int color, float factor) {
        int a = Math.min(255, Math.max(0, Math.round(((color >>> 24) & 0xFF) * factor)));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        int r = Math.round(((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = Math.round(((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = Math.round((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Hue 0..1 to opaque ARGB (saturation 0.65, value 1), used for rainbow effects. */
    public static int hue(float h) {
        float s = 0.65f;
        float v = 1.0f;
        float scaled = (h - (float) Math.floor(h)) * 6.0f;
        int sector = (int) scaled;
        float f = scaled - sector;
        float p = v * (1.0f - s);
        float q = v * (1.0f - s * f);
        float t = v * (1.0f - s * (1.0f - f));
        float r;
        float g;
        float b;
        if (sector == 0) {
            r = v; g = t; b = p;
        } else if (sector == 1) {
            r = q; g = v; b = p;
        } else if (sector == 2) {
            r = p; g = v; b = t;
        } else if (sector == 3) {
            r = p; g = q; b = v;
        } else if (sector == 4) {
            r = t; g = p; b = v;
        } else {
            r = v; g = p; b = q;
        }
        return 0xFF000000 | (Math.round(r * 255.0f) << 16) | (Math.round(g * 255.0f) << 8) | Math.round(b * 255.0f);
    }
}
