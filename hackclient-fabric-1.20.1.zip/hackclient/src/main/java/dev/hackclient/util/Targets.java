package dev.hackclient.util;

import dev.hackclient.FriendManager;
import dev.hackclient.module.impl.AntiBot;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.SwordItem;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Targets {
    private Targets() {
    }

    public static boolean isAttackable(Entity e, boolean players, boolean hostiles, boolean passives, boolean invisible) {
        if (!(e instanceof LivingEntity living) || e == MinecraftClient.getInstance().player) {
            return false;
        }
        if (!living.isAlive() || living.isSpectator() || living instanceof ArmorStandEntity) {
            return false;
        }
        if (!invisible && living.isInvisible()) {
            return false;
        }
        if (living instanceof PlayerEntity player) {
            return players
                    && !FriendManager.isFriend(player.getEntityName())
                    && !AntiBot.isBot(player);
        }
        if (living instanceof Monster) {
            return hostiles;
        }
        if (living instanceof PassiveEntity) {
            return passives;
        }
        return false;
    }

    public static boolean isHoldingWeapon(PlayerEntity player) {
        Item item = player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem;
    }

    private static double clampAxis(double v, double min, double max, double margin) {
        double lo = min + margin;
        double hi = max - margin;
        return lo > hi ? (min + max) * 0.5 : MathHelper.clamp(v, lo, hi);
    }

    /** Point of the box closest to the eye, kept slightly inside the hitbox. */
    public static Vec3d aimPoint(Vec3d eye, Box b) {
        double m = 0.08;
        return new Vec3d(
                clampAxis(eye.x, b.minX, b.maxX, m),
                clampAxis(eye.y, b.minY, b.maxY, m),
                clampAxis(eye.z, b.minZ, b.maxZ, m));
    }

    public static double distanceToBox(Vec3d eye, Box b) {
        double dx = eye.x - MathHelper.clamp(eye.x, b.minX, b.maxX);
        double dy = eye.y - MathHelper.clamp(eye.y, b.minY, b.maxY);
        double dz = eye.z - MathHelper.clamp(eye.z, b.minZ, b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static float yawTo(Vec3d from, Vec3d to) {
        return (float) (Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0);
    }

    public static float pitchTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dz = to.z - from.z;
        return (float) -Math.toDegrees(Math.atan2(to.y - from.y, Math.sqrt(dx * dx + dz * dz)));
    }

    /** Vanilla 1.20.1 critical-hit conditions (falling, not sprinting, not in water or on a ladder). */
    public static boolean canCrit(PlayerEntity p) {
        return p.fallDistance > 0.0f
                && !p.isOnGround()
                && !p.isClimbing()
                && !p.isTouchingWater()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && !p.hasVehicle()
                && !p.isSprinting();
    }

    /** ARGB colour for ESP/tracers, or 0 when the entity kind is switched off. */
    public static int colorFor(Entity e, boolean players, boolean hostiles, boolean passives, boolean items) {
        if (e instanceof ItemEntity) {
            return items ? 0xFFFFFF55 : 0;
        }
        if (!(e instanceof LivingEntity living) || !living.isAlive() || e instanceof ArmorStandEntity) {
            return 0;
        }
        if (e instanceof PlayerEntity player) {
            if (!players) {
                return 0;
            }
            return FriendManager.isFriend(player.getEntityName()) ? 0xFF55FF55 : 0xFFFF5555;
        }
        if (e instanceof Monster) {
            return hostiles ? 0xFFFFAA00 : 0;
        }
        return passives ? 0xFF55FFFF : 0;
    }
}
