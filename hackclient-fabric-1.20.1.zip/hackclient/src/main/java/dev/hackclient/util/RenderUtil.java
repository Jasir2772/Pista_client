package dev.hackclient.util;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/**
 * World-to-screen projection. Matrices are captured at the end of world rendering and reused by the HUD pass of the same frame.
 * Convention: clip = Projection * ViewRotation * (worldPos - cameraPos); output is in scaled GUI pixels, origin top-left, y down.
 */
public final class RenderUtil {
    private static final Matrix4f VIEW_PROJ = new Matrix4f();
    private static final Matrix4f VIEW = new Matrix4f();
    private static final Vector4f TMP = new Vector4f();
    private static final float[] POINT = new float[2];
    private static double camX;
    private static double camY;
    private static double camZ;
    private static float tickDelta;
    private static boolean ready;

    private RenderUtil() {
    }

    public static void capture(WorldRenderContext context) {
        VIEW.set(context.matrixStack().peek().getPositionMatrix());
        VIEW_PROJ.set(context.projectionMatrix());
        VIEW_PROJ.mul(VIEW);
        Vec3d cam = context.camera().getPos();
        camX = cam.x;
        camY = cam.y;
        camZ = cam.z;
        tickDelta = context.tickDelta();
        ready = true;
    }

    public static boolean isReady() {
        return ready;
    }

    public static float tickDelta() {
        return tickDelta;
    }

    /** out[0], out[1] = screen x, y. Returns false when the point is behind the camera. */
    public static boolean project(double x, double y, double z, float[] out) {
        if (!ready) {
            return false;
        }
        TMP.set((float) (x - camX), (float) (y - camY), (float) (z - camZ), 1.0f);
        TMP.mul(VIEW_PROJ);
        if (!(TMP.w > 0.05f)) {
            return false;
        }
        float ndcX = TMP.x / TMP.w;
        float ndcY = TMP.y / TMP.w;
        if (Float.isNaN(ndcX) || Float.isNaN(ndcY)) {
            return false;
        }
        var window = MinecraftClient.getInstance().getWindow();
        out[0] = (ndcX * 0.5f + 0.5f) * window.getScaledWidth();
        out[1] = (1.0f - (ndcY * 0.5f + 0.5f)) * window.getScaledHeight();
        return true;
    }

    /** Screen-space bounds of a world box: out = {minX, minY, maxX, maxY}. False if any corner is behind the camera. */
    public static boolean projectBox(double minX, double minY, double minZ,
                                     double maxX, double maxY, double maxZ, float[] out) {
        float sx0 = Float.MAX_VALUE;
        float sy0 = Float.MAX_VALUE;
        float sx1 = -Float.MAX_VALUE;
        float sy1 = -Float.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? minX : maxX;
            double y = (i & 2) == 0 ? minY : maxY;
            double z = (i & 4) == 0 ? minZ : maxZ;
            if (!project(x, y, z, POINT)) {
                return false;
            }
            sx0 = Math.min(sx0, POINT[0]);
            sy0 = Math.min(sy0, POINT[1]);
            sx1 = Math.max(sx1, POINT[0]);
            sy1 = Math.max(sy1, POINT[1]);
        }
        out[0] = sx0;
        out[1] = sy0;
        out[2] = sx1;
        out[3] = sy1;
        return true;
    }

    /** Fills a rectangle in half-pixel units of the scaled GUI, so lines stay thin on high GUI scales. */
    public static void fillHalf(DrawContext ctx, float x1, float y1, float x2, float y2, int color) {
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.scale(0.5f, 0.5f, 1.0f);
        ctx.fill(Math.round(x1 * 2), Math.round(y1 * 2), Math.round(x2 * 2), Math.round(y2 * 2), color);
        m.pop();
    }

    public static void outline(DrawContext ctx, float x1, float y1, float x2, float y2, int color) {
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.scale(0.5f, 0.5f, 1.0f);
        int a = Math.round(x1 * 2);
        int b = Math.round(y1 * 2);
        int c = Math.round(x2 * 2);
        int d = Math.round(y2 * 2);
        ctx.fill(a, b, c, b + 1, color);
        ctx.fill(a, d - 1, c, d, color);
        ctx.fill(a, b + 1, a + 1, d - 1, color);
        ctx.fill(c - 1, b + 1, c, d - 1, color);
        m.pop();
    }

    public static void text(DrawContext ctx, String text, float centerX, float y, int color, float scale) {
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(centerX, y, 0.0f);
        m.scale(scale, scale, 1.0f);
        ctx.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, text, 0, 0, color);
        m.pop();
    }

    private static final int[][] CORNER_INSETS = new int[9][];

    static {
        for (int r = 1; r < CORNER_INSETS.length; r++) {
            int[] insets = new int[r];
            for (int i = 0; i < r; i++) {
                double dy = r - i - 0.5;
                double dx = Math.sqrt(r * (double) r - dy * dy);
                insets[i] = (int) Math.round(r - dx);
            }
            CORNER_INSETS[r] = insets;
        }
    }

    /** Filled rectangle with rounded corners, built from a few plain fills (no shaders). */
    public static void roundRect(DrawContext ctx, int x1, int y1, int x2, int y2, int radius, int color) {
        int r = Math.min(radius, Math.min((x2 - x1) / 2, (y2 - y1) / 2));
        if (r <= 1 || r >= CORNER_INSETS.length) {
            ctx.fill(x1, y1, x2, y2, color);
            return;
        }
        int[] insets = CORNER_INSETS[r];
        ctx.fill(x1, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            ctx.fill(x1 + insets[i], y1 + i, x2 - insets[i], y1 + i + 1, color);
            ctx.fill(x1 + insets[i], y2 - i - 1, x2 - insets[i], y2 - i, color);
        }
    }

    /** Thin line drawn as one rotated rectangle. Thickness is 0.5 GUI pixels times the given factor. */
    public static void line(DrawContext ctx, float x1, float y1, float x2, float y2, int color, int thickness) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.5f || len > 6000.0f) {
            return;
        }
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(x1, y1, 0.0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        m.scale(0.5f, 0.5f, 1.0f);
        ctx.fill(0, 0, Math.round(len * 2.0f), Math.max(1, thickness), color);
        m.pop();
    }
}
