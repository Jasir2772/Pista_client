package dev.hackclient.util;

/** Estimates the server tick rate from how often it sends world-time updates (normally once per 20 ticks). */
public final class TpsTracker {
    private static final long[] INTERVALS = new long[5];
    private static int index;
    private static int count;
    private static long last;
    private static double tps = 20.0;

    private TpsTracker() {
    }

    public static void onTimeUpdate() {
        long now = System.nanoTime();
        if (last != 0L) {
            INTERVALS[index] = now - last;
            index = (index + 1) % INTERVALS.length;
            count = Math.min(count + 1, INTERVALS.length);
            long sum = 0L;
            for (int i = 0; i < count; i++) {
                sum += INTERVALS[i];
            }
            double seconds = sum / (double) count / 1.0e9;
            tps = Math.max(0.0, Math.min(20.0, 20.0 / Math.max(0.05, seconds)));
        }
        last = now;
    }

    public static void reset() {
        last = 0L;
        count = 0;
        index = 0;
        tps = 20.0;
    }

    public static double tps() {
        return tps;
    }
}
