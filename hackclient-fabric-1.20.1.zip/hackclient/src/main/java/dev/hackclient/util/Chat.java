package dev.hackclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Local-only chat line (never sent to the server). */
public final class Chat {
    private Chat() {
    }

    public static void say(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[Pista] ").formatted(Formatting.LIGHT_PURPLE)
                    .append(Text.literal(message).formatted(Formatting.WHITE)));
        }
    }
}
