package dev.hackclient.util;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Logo and gradient text used by the ClickGUI header and the HUD watermark. */
public final class Brand {
    public static final Identifier LOGO = new Identifier("hackclient", "textures/gui/logo.png");

    private Brand() {
    }

    public static void logo(DrawContext ctx, int x, int y, int size) {
        ctx.drawTexture(LOGO, x, y, size, size, 0.0f, 0.0f, 256, 256, 256, 256);
    }

    /** Draws the text one character at a time, blending the colour from {@code from} to {@code to}. */
    public static void gradientText(DrawContext ctx, TextRenderer tr, String text, int x, int y, int from, int to) {
        int cx = x;
        float last = Math.max(1, text.length() - 1);
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            ctx.drawTextWithShadow(tr, ch, cx, y, Theme.mix(from, to, i / last));
            cx += tr.getWidth(ch);
        }
    }
}
