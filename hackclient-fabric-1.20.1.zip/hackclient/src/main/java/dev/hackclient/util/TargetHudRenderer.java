package dev.hackclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;

/**
 * Draws the target card in one of six styles: Card, Compact, Glow, Gradient, Minimal, Items.
 * Health is animated: the fill eases to the real value and a lighter "damage" chip drains behind it.
 */
public final class TargetHudRenderer {
    public static final String[] STYLES = {"Card", "Compact", "Glow", "Gradient", "Minimal", "Items"};

    private static LivingEntity last;
    private static float shown = 1.0f;
    private static float chip = 1.0f;
    private static long lastNs;

    private TargetHudRenderer() {
    }

    public static void render(DrawContext ctx, TextRenderer tr, LivingEntity target, int x, int y, String style, int accent) {
        float maxHp = Math.max(1.0f, target.getMaxHealth());
        float frac = MathHelper.clamp(target.getHealth() / maxHp, 0.0f, 1.0f);

        long now = System.nanoTime();
        float dt = lastNs == 0L ? 0.0f : MathHelper.clamp((now - lastNs) / 1.0e9f, 0.0f, 0.1f);
        lastNs = now;
        if (target != last) {
            last = target;
            shown = frac;
            chip = frac;
        }
        shown += (frac - shown) * Math.min(1.0f, dt * 12.0f);
        chip = chip > shown ? Math.max(shown, chip - dt * 0.35f) : shown;

        int barColor = Theme.mix(0xFFFF5C5C, accent, shown);
        String name = target.getName().getString();
        int maxName = style.equals("Compact") ? 16 : 14;
        if (name.length() > maxName) {
            name = name.substring(0, maxName);
        }
        String hp = String.format(Locale.ROOT, "%.1f", target.getHealth());

        switch (style) {
            case "Compact" -> drawCompact(ctx, tr, x, y, barColor, name, hp);
            case "Minimal" -> drawMinimal(ctx, tr, x, y, accent, barColor, name, hp);
            case "Glow" -> drawCard(ctx, tr, target, x, y, accent, barColor, name, hp, maxHp, true, false, false);
            case "Gradient" -> drawCard(ctx, tr, target, x, y, accent, barColor, name, hp, maxHp, false, true, false);
            case "Items" -> drawCard(ctx, tr, target, x, y, accent, barColor, name, hp, maxHp, false, false, true);
            default -> drawCard(ctx, tr, target, x, y, accent, barColor, name, hp, maxHp, false, false, false);
        }
    }

    private static void drawCard(DrawContext ctx, TextRenderer tr, LivingEntity target, int x, int y, int accent,
                                 int barColor, String name, String hp, float maxHp,
                                 boolean glow, boolean gradient, boolean items) {
        int w = 142;
        int h = items ? 64 : 46;
        if (glow) {
            // Soft halo: a few larger, fainter rounded rectangles behind the card.
            for (int i = 3; i >= 1; i--) {
                RenderUtil.roundRect(ctx, x - i * 2, y - i * 2, x + w + i * 2, y + h + i * 2, 6 + i * 2,
                        Theme.withAlpha(accent, 0.07f * (4 - i)));
            }
        }
        RenderUtil.roundRect(ctx, x, y, x + w, y + h, 6, Theme.HUD_BG);

        int hx = x + 7;
        int hy = y + 7;
        int hs = 32;
        RenderUtil.fillHalf(ctx, hx - 1, hy - 1, hx + hs + 1, hy + hs + 1, Theme.withAlpha(accent, 0.9f));
        if (target instanceof AbstractClientPlayerEntity player) {
            Identifier skin = player.getSkinTexture();
            ctx.drawTexture(skin, hx, hy, hs, hs, 8.0f, 8.0f, 8, 8, 64, 64);
            ctx.drawTexture(skin, hx, hy, hs, hs, 40.0f, 8.0f, 8, 8, 64, 64);
        } else {
            RenderUtil.fillHalf(ctx, hx, hy, hx + hs, hy + hs, 0xFF1B2030);
            String letter = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
            ctx.drawCenteredTextWithShadow(tr, letter, hx + hs / 2, hy + hs / 2 - 4, Theme.TEXT);
        }
        if (target.hurtTime > 0) {
            RenderUtil.fillHalf(ctx, hx, hy, hx + hs, hy + hs, Theme.withAlpha(0xFFFF3030, Math.min(1.0f, target.hurtTime / 10.0f) * 0.45f));
        }

        int tx = x + 46;
        ctx.drawTextWithShadow(tr, name, tx, y + 8, Theme.TEXT);
        String hpText = hp + " / " + Math.round(maxHp);
        ctx.drawTextWithShadow(tr, hpText, tx, y + 20, Theme.TEXT_DIM);
        float absorption = target.getAbsorptionAmount();
        if (absorption > 0.0f) {
            ctx.drawTextWithShadow(tr, "+" + Math.round(absorption), tx + tr.getWidth(hpText) + 4, y + 20, 0xFFFFD34D);
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            String distance = String.format(Locale.ROOT, "%.1fm", mc.player.distanceTo(target));
            ctx.drawTextWithShadow(tr, distance, x + w - 8 - tr.getWidth(distance), y + 8, Theme.TEXT_DIM);
        }

        bar(ctx, tx, y + 32, x + w - 8, y + 37, barColor, gradient ? 0xFFFF5C5C : 0, gradient ? accent : 0);

        if (items) {
            // Held items and armor (12 px icons), plus the armor value on the right.
            ItemStack[] stacks = {
                    target.getMainHandStack(), target.getOffHandStack(),
                    target.getEquippedStack(EquipmentSlot.HEAD), target.getEquippedStack(EquipmentSlot.CHEST),
                    target.getEquippedStack(EquipmentSlot.LEGS), target.getEquippedStack(EquipmentSlot.FEET)};
            for (int i = 0; i < stacks.length; i++) {
                if (stacks[i].isEmpty()) {
                    continue;
                }
                ctx.getMatrices().push();
                ctx.getMatrices().translate(x + 8 + i * 17, y + 44, 0.0);
                ctx.getMatrices().scale(0.85f, 0.85f, 1.0f);
                ctx.drawItem(stacks[i], 0, 0);
                ctx.getMatrices().pop();
            }
            String armor = "Armor " + target.getArmor();
            ctx.drawTextWithShadow(tr, armor, x + w - 8 - tr.getWidth(armor), y + 49, Theme.TEXT_DIM);
        }
    }

    private static void drawCompact(DrawContext ctx, TextRenderer tr, int x, int y, int barColor, String name, String hp) {
        RenderUtil.roundRect(ctx, x, y, x + 112, y + 34, 5, Theme.HUD_BG);
        ctx.drawTextWithShadow(tr, name, x + 8, y + 6, Theme.TEXT);
        ctx.drawTextWithShadow(tr, hp, x + 104 - tr.getWidth(hp), y + 6, Theme.TEXT_DIM);
        bar(ctx, x + 8, y + 21, x + 104, y + 27, barColor, 0, 0);
    }

    private static void drawMinimal(DrawContext ctx, TextRenderer tr, int x, int y, int accent, int barColor, String name, String hp) {
        RenderUtil.roundRect(ctx, x, y, x + 110, y + 26, 4, Theme.HUD_BG);
        RenderUtil.fillHalf(ctx, x + 1, y + 6, x + 3, y + 20, accent);
        ctx.drawTextWithShadow(tr, name, x + 9, y + 5, Theme.TEXT);
        ctx.drawTextWithShadow(tr, hp, x + 102 - tr.getWidth(hp), y + 5, Theme.TEXT_DIM);
        bar(ctx, x + 9, y + 18, x + 102, y + 21, barColor, 0, 0);
    }

    /** Health bar; when {@code from} is not 0 the fill is a left-to-right gradient from {@code from} to {@code to}. */
    private static void bar(DrawContext ctx, int x1, int y1, int x2, int y2, int fillColor, int from, int to) {
        int width = x2 - x1;
        RenderUtil.roundRect(ctx, x1, y1, x2, y2, 2, 0x66000000);
        if (chip > shown + 0.01f) {
            RenderUtil.roundRect(ctx, x1, y1, x1 + Math.max(4, Math.round(width * chip)), y2, 2, 0xAAFFFFFF);
        }
        int fillEnd = x1 + Math.max(4, Math.round(width * shown));
        if (from == 0) {
            RenderUtil.roundRect(ctx, x1, y1, fillEnd, y2, 2, fillColor);
            return;
        }
        int segments = 12;
        int fillWidth = fillEnd - x1;
        for (int i = 0; i < segments; i++) {
            int sx1 = x1 + fillWidth * i / segments;
            int sx2 = x1 + fillWidth * (i + 1) / segments;
            if (sx2 > sx1) {
                RenderUtil.fillHalf(ctx, sx1, y1, sx2, y2, Theme.mix(from, to, i / (float) (segments - 1)));
            }
        }
    }
}
